# MyHeart
Các bạn có Visual Studio thì có thể mở lên chạy ngay\
Còn các bạn sử dụng IDE khác thì phải copy code và file heart.txt sang IDE đó để chạy\
Có thể liên hệ mình tại: https://beacons.ai/ngoctientnt/
