# Thanh xuân vốn dĩ là để bỏ lỡ 🥇
Có thể liên hệ mình tại: https://beacons.ai/ngoctientnt/
