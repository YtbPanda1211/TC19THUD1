window['denylistedDomainsHashedValueListForGpayButtonWithCardInfo'] = [-718583466, -651407173, 1501053020, 1270931793];
window['whitelistedDomainsHashedValueListForGpayButtonWithCardInfo'] = [1432838318];
window['denylistedMerchentIdsHashedValueListForGpayButtonWithCardInfo'] = [1260893, 211376492];
/*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
var a = this || self;
var b = ["google", "payments", "api", "ReadyToPayAdditionalBrowsers"],
    c = window || a;
b[0] in c || "undefined" == typeof c.execScript || c.execScript("var " + b[0]);
for (var d; b.length && (d = b.shift());) b.length ? c = c[d] && c[d] !== Object.prototype[d] ? c[d] : c[d] = {} : c[d] = !0;
/*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
var a = this || self;
var b = ["google", "payments", "api", "PaymentHandlerLaunchPayjs"],
    c = window || a;
b[0] in c || "undefined" == typeof c.execScript || c.execScript("var " + b[0]);
for (var d; b.length && (d = b.shift());) b.length ? c = c[d] && c[d] !== Object.prototype[d] ? c[d] : c[d] = {} : c[d] = !0;
/*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
var a = this || self;
var b = ["google", "payments", "api", "PaymentHandlerDynamicUpdatesLaunchPayjs"],
    c = window || a;
b[0] in c || "undefined" == typeof c.execScript || c.execScript("var " + b[0]);
for (var d; b.length && (d = b.shift());) b.length ? c = c[d] && c[d] !== Object.prototype[d] ? c[d] : c[d] = {} : c[d] = !0;
/*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
var a = this || self;
var b = ["google", "payments", "api", "EnableDynamicGpayButton"],
    c = window || a;
b[0] in c || "undefined" == typeof c.execScript || c.execScript("var " + b[0]);
for (var d; b.length && (d = b.shift());) b.length ? c = c[d] && c[d] !== Object.prototype[d] ? c[d] : c[d] = {} : c[d] = !0;
/*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
var a = this || self;
var b = ["google", "payments", "api", "EnableDynamicUpdateForClank"],
    c = window || a;
b[0] in c || "undefined" == typeof c.execScript || c.execScript("var " + b[0]);
for (var d; b.length && (d = b.shift());) b.length ? c = c[d] && c[d] !== Object.prototype[d] ? c[d] : c[d] = {} : c[d] = !0;
/*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
var a = this || self;
var b = ["google", "payments", "api", "DisableNativeReadyToPayCheckForPaymentHandler"],
    c = window || a;
b[0] in c || "undefined" == typeof c.execScript || c.execScript("var " + b[0]);
for (var d; b.length && (d = b.shift());) b.length ? c = c[d] && c[d] !== Object.prototype[d] ? c[d] : c[d] = {} : c[d] = !0;
/*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
var a = this || self;
var b = ["google", "payments", "api", "DisablePaymentRequest"],
    c = window || a;
b[0] in c || "undefined" == typeof c.execScript || c.execScript("var " + b[0]);
for (var d; b.length && (d = b.shift());) b.length ? c = c[d] && c[d] !== Object.prototype[d] ? c[d] : c[d] = {} : c[d] = !0;
/*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
var a = this || self;
var b = ["google", "payments", "api", "EnablePaymentRequest"],
    c = window || a;
b[0] in c || "undefined" == typeof c.execScript || c.execScript("var " + b[0]);
for (var d; b.length && (d = b.shift());) b.length ? c = c[d] && c[d] !== Object.prototype[d] ? c[d] : c[d] = {} : c[d] = !0;
/*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
var a = this || self;
var b = ["google", "payments", "api", "EnableLoadPaymentDataTimeout"],
    c = window || a;
b[0] in c || "undefined" == typeof c.execScript || c.execScript("var " + b[0]);
for (var d; b.length && (d = b.shift());) b.length ? c = c[d] && c[d] !== Object.prototype[d] ? c[d] : c[d] = {} : c[d] = !0;
/*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
var a = this || self;
var b = ["google", "payments", "api", "EnableOfferCallback"],
    c = window || a;
b[0] in c || "undefined" == typeof c.execScript || c.execScript("var " + b[0]);
for (var d; b.length && (d = b.shift());) b.length ? c = c[d] && c[d] !== Object.prototype[d] ? c[d] : c[d] = {} : c[d] = !0;
/*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
var a = this || self;
var b = ["google", "payments", "api", "EnablePaymentMethodCallback"],
    c = window || a;
b[0] in c || "undefined" == typeof c.execScript || c.execScript("var " + b[0]);
for (var d; b.length && (d = b.shift());) b.length ? c = c[d] && c[d] !== Object.prototype[d] ? c[d] : c[d] = {} : c[d] = !0;
/*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
var a = this || self;
var b = ["google", "payments", "api", "UseCanMakePaymentResultFromPayjs"],
    c = window || a;
b[0] in c || "undefined" == typeof c.execScript || c.execScript("var " + b[0]);
for (var d; b.length && (d = b.shift());) b.length ? c = c[d] && c[d] !== Object.prototype[d] ? c[d] : c[d] = {} : c[d] = !0;
/*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
var a = this || self;
var b = ["google", "payments", "api", "UseCanMakePaymentForFallbackOnMobile"],
    c = window || a;
b[0] in c || "undefined" == typeof c.execScript || c.execScript("var " + b[0]);
for (var d; b.length && (d = b.shift());) b.length ? c = c[d] && c[d] !== Object.prototype[d] ? c[d] : c[d] = {} : c[d] = !0;
(function() {
    /*

     Copyright The Closure Library Authors.
     SPDX-License-Identifier: Apache-2.0
    */
    var m, n, aa = function(a) {
            var b = 0;
            return function() {
                return b < a.length ? {
                    done: !1,
                    value: a[b++]
                } : {
                    done: !0
                }
            }
        },
        ba = "function" == typeof Object.defineProperties ? Object.defineProperty : function(a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a
        },
        ca = function(a) {
            a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
            for (var b = 0; b < a.length; ++b) {
                var c = a[b];
                if (c && c.Math == Math) return c
            }
            throw Error("Cannot find global object");
        },
        p = ca(this),
        da = "function" === typeof Symbol && "symbol" === typeof Symbol("x"),
        r = {},
        ea = {},
        t = function(a, b) {
            var c = ea[b];
            if (null == c) return a[b];
            c = a[c];
            return void 0 !== c ? c : a[b]
        },
        u = function(a, b, c) {
            if (b) a: {
                var d = a.split(".");a = 1 === d.length;
                var e = d[0];e = !a && e in r ? r : p;
                for (var g = 0; g < d.length - 1; g++) {
                    var f = d[g];
                    if (!(f in e)) break a;
                    e = e[f]
                }
                d = d[d.length - 1];c = da && "es6" === c ? e[d] : null;b = b(c);null != b && (a ? ba(r, d, {
                    configurable: !0,
                    writable: !0,
                    value: b
                }) : b !== c && (void 0 === ea[d] && (a = 1E9 * Math.random() >>> 0, ea[d] = da ? p.Symbol(d) :
                    "$jscp$" + a + "$" + d), ba(e, ea[d], {
                    configurable: !0,
                    writable: !0,
                    value: b
                })))
            }
        };
    u("Symbol", function(a) {
        if (a) return a;
        var b = function(g, f) {
            this.Zb = g;
            ba(this, "description", {
                configurable: !0,
                writable: !0,
                value: f
            })
        };
        b.prototype.toString = function() {
            return this.Zb
        };
        var c = "jscomp_symbol_" + (1E9 * Math.random() >>> 0) + "_",
            d = 0,
            e = function(g) {
                if (this instanceof e) throw new TypeError("Symbol is not a constructor");
                return new b(c + (g || "") + "_" + d++, g)
            };
        return e
    }, "es6");
    u("Symbol.iterator", function(a) {
        if (a) return a;
        a = (0, r.Symbol)("Symbol.iterator");
        for (var b = "Array Int8Array Uint8Array Uint8ClampedArray Int16Array Uint16Array Int32Array Uint32Array Float32Array Float64Array".split(" "), c = 0; c < b.length; c++) {
            var d = p[b[c]];
            "function" === typeof d && "function" != typeof d.prototype[a] && ba(d.prototype, a, {
                configurable: !0,
                writable: !0,
                value: function() {
                    return fa(aa(this))
                }
            })
        }
        return a
    }, "es6");
    var fa = function(a) {
            a = {
                next: a
            };
            a[t(r.Symbol, "iterator")] = function() {
                return this
            };
            return a
        },
        ha = function(a) {
            var b = "undefined" != typeof r.Symbol && t(r.Symbol, "iterator") && a[t(r.Symbol, "iterator")];
            return b ? b.call(a) : {
                next: aa(a)
            }
        },
        ja = function(a) {
            if (!(a instanceof Array)) {
                a = ha(a);
                for (var b, c = []; !(b = a.next()).done;) c.push(b.value);
                a = c
            }
            return a
        };
    u("Promise", function(a) {
        function b() {
            this.W = null
        }

        function c(f) {
            return f instanceof e ? f : new e(function(h) {
                h(f)
            })
        }
        if (a) return a;
        b.prototype.Eb = function(f) {
            if (null == this.W) {
                this.W = [];
                var h = this;
                this.Fb(function() {
                    h.kc()
                })
            }
            this.W.push(f)
        };
        var d = p.setTimeout;
        b.prototype.Fb = function(f) {
            d(f, 0)
        };
        b.prototype.kc = function() {
            for (; this.W && this.W.length;) {
                var f = this.W;
                this.W = [];
                for (var h = 0; h < f.length; ++h) {
                    var k = f[h];
                    f[h] = null;
                    try {
                        k()
                    } catch (l) {
                        this.fc(l)
                    }
                }
            }
            this.W = null
        };
        b.prototype.fc = function(f) {
            this.Fb(function() {
                throw f;
            })
        };
        var e = function(f) {
            this.sa = 0;
            this.$ = void 0;
            this.ra = [];
            this.Nb = !1;
            var h = this.gb();
            try {
                f(h.resolve, h.reject)
            } catch (k) {
                h.reject(k)
            }
        };
        e.prototype.gb = function() {
            function f(l) {
                return function(q) {
                    k || (k = !0, l.call(h, q))
                }
            }
            var h = this,
                k = !1;
            return {
                resolve: f(this.xc),
                reject: f(this.ub)
            }
        };
        e.prototype.xc = function(f) {
            if (f === this) this.ub(new TypeError("A Promise cannot resolve to itself"));
            else if (f instanceof e) this.Ac(f);
            else {
                a: switch (typeof f) {
                    case "object":
                        var h = null != f;
                        break a;
                    case "function":
                        h = !0;
                        break a;
                    default:
                        h = !1
                }
                h ? this.wc(f) : this.Lb(f)
            }
        };
        e.prototype.wc = function(f) {
            var h = void 0;
            try {
                h = f.then
            } catch (k) {
                this.ub(k);
                return
            }
            "function" == typeof h ? this.Bc(h, f) : this.Lb(f)
        };
        e.prototype.ub = function(f) {
            this.Yb(2, f)
        };
        e.prototype.Lb = function(f) {
            this.Yb(1, f)
        };
        e.prototype.Yb = function(f, h) {
            if (0 != this.sa) throw Error("Cannot settle(" + f + ", " + h + "): Promise already settled in state" + this.sa);
            this.sa = f;
            this.$ = h;
            2 === this.sa && this.yc();
            this.lc()
        };
        e.prototype.yc = function() {
            var f = this;
            d(function() {
                if (f.pc()) {
                    var h = p.console;
                    "undefined" !==
                    typeof h && h.error(f.$)
                }
            }, 1)
        };
        e.prototype.pc = function() {
            if (this.Nb) return !1;
            var f = p.CustomEvent,
                h = p.Event,
                k = p.dispatchEvent;
            if ("undefined" === typeof k) return !0;
            "function" === typeof f ? f = new f("unhandledrejection", {
                cancelable: !0
            }) : "function" === typeof h ? f = new h("unhandledrejection", {
                cancelable: !0
            }) : (f = p.document.createEvent("CustomEvent"), f.initCustomEvent("unhandledrejection", !1, !0, f));
            f.promise = this;
            f.reason = this.$;
            return k(f)
        };
        e.prototype.lc = function() {
            if (null != this.ra) {
                for (var f = 0; f < this.ra.length; ++f) g.Eb(this.ra[f]);
                this.ra = null
            }
        };
        var g = new b;
        e.prototype.Ac = function(f) {
            var h = this.gb();
            f.Sa(h.resolve, h.reject)
        };
        e.prototype.Bc = function(f, h) {
            var k = this.gb();
            try {
                f.call(h, k.resolve, k.reject)
            } catch (l) {
                k.reject(l)
            }
        };
        e.prototype.then = function(f, h) {
            function k(y, G) {
                return "function" == typeof y ? function(ia) {
                    try {
                        l(y(ia))
                    } catch (S) {
                        q(S)
                    }
                } : G
            }
            var l, q, x = new e(function(y, G) {
                l = y;
                q = G
            });
            this.Sa(k(f, l), k(h, q));
            return x
        };
        e.prototype.catch = function(f) {
            return this.then(void 0, f)
        };
        e.prototype.Sa = function(f, h) {
            function k() {
                switch (l.sa) {
                    case 1:
                        f(l.$);
                        break;
                    case 2:
                        h(l.$);
                        break;
                    default:
                        throw Error("Unexpected state: " + l.sa);
                }
            }
            var l = this;
            null == this.ra ? g.Eb(k) : this.ra.push(k);
            this.Nb = !0
        };
        e.resolve = c;
        e.reject = function(f) {
            return new e(function(h, k) {
                k(f)
            })
        };
        e.race = function(f) {
            return new e(function(h, k) {
                for (var l = ha(f), q = l.next(); !q.done; q = l.next()) c(q.value).Sa(h, k)
            })
        };
        e.all = function(f) {
            var h = ha(f),
                k = h.next();
            return k.done ? c([]) : new e(function(l, q) {
                function x(ia) {
                    return function(S) {
                        y[ia] = S;
                        G--;
                        0 == G && l(y)
                    }
                }
                var y = [],
                    G = 0;
                do y.push(void 0), G++, c(k.value).Sa(x(y.length -
                    1), q), k = h.next(); while (!k.done)
            })
        };
        return e
    }, "es6");
    var v = function(a, b) {
        return Object.prototype.hasOwnProperty.call(a, b)
    };
    u("WeakMap", function(a) {
        function b() {}

        function c(f) {
            var h = typeof f;
            return "object" === h && null !== f || "function" === h
        }
        if (function() {
                if (!a || !Object.seal) return !1;
                try {
                    var f = Object.seal({}),
                        h = Object.seal({}),
                        k = new a([
                            [f, 2],
                            [h, 3]
                        ]);
                    if (2 != k.get(f) || 3 != k.get(h)) return !1;
                    k.delete(f);
                    k.set(h, 4);
                    return !k.has(f) && 4 == k.get(h)
                } catch (l) {
                    return !1
                }
            }()) return a;
        var d = "$jscomp_hidden_" + Math.random(),
            e = 0,
            g = function(f) {
                this.Aa = (e += Math.random() + 1).toString();
                if (f) {
                    f = ha(f);
                    for (var h; !(h = f.next()).done;) h = h.value, this.set(h[0],
                        h[1])
                }
            };
        g.prototype.set = function(f, h) {
            if (!c(f)) throw Error("Invalid WeakMap key");
            if (!v(f, d)) {
                var k = new b;
                ba(f, d, {
                    value: k
                })
            }
            if (!v(f, d)) throw Error("WeakMap key fail: " + f);
            f[d][this.Aa] = h;
            return this
        };
        g.prototype.get = function(f) {
            return c(f) && v(f, d) ? f[d][this.Aa] : void 0
        };
        g.prototype.has = function(f) {
            return c(f) && v(f, d) && v(f[d], this.Aa)
        };
        g.prototype.delete = function(f) {
            return c(f) && v(f, d) && v(f[d], this.Aa) ? delete f[d][this.Aa] : !1
        };
        return g
    }, "es6");
    u("Map", function(a) {
        if (function() {
                if (!a || "function" != typeof a || !a.prototype.entries || "function" != typeof Object.seal) return !1;
                try {
                    var h = Object.seal({
                            x: 4
                        }),
                        k = new a(ha([
                            [h, "s"]
                        ]));
                    if ("s" != k.get(h) || 1 != k.size || k.get({
                            x: 4
                        }) || k.set({
                            x: 4
                        }, "t") != k || 2 != k.size) return !1;
                    var l = k.entries(),
                        q = l.next();
                    if (q.done || q.value[0] != h || "s" != q.value[1]) return !1;
                    q = l.next();
                    return q.done || 4 != q.value[0].x || "t" != q.value[1] || !l.next().done ? !1 : !0
                } catch (x) {
                    return !1
                }
            }()) return a;
        var b = new r.WeakMap,
            c = function(h) {
                this.ha = {};
                this.S =
                    g();
                this.size = 0;
                if (h) {
                    h = ha(h);
                    for (var k; !(k = h.next()).done;) k = k.value, this.set(k[0], k[1])
                }
            };
        c.prototype.set = function(h, k) {
            h = 0 === h ? 0 : h;
            var l = d(this, h);
            l.list || (l.list = this.ha[l.id] = []);
            l.u ? l.u.value = k : (l.u = {
                next: this.S,
                V: this.S.V,
                head: this.S,
                key: h,
                value: k
            }, l.list.push(l.u), this.S.V.next = l.u, this.S.V = l.u, this.size++);
            return this
        };
        c.prototype.delete = function(h) {
            h = d(this, h);
            return h.u && h.list ? (h.list.splice(h.index, 1), h.list.length || delete this.ha[h.id], h.u.V.next = h.u.next, h.u.next.V = h.u.V, h.u.head = null,
                this.size--, !0) : !1
        };
        c.prototype.clear = function() {
            this.ha = {};
            this.S = this.S.V = g();
            this.size = 0
        };
        c.prototype.has = function(h) {
            return !!d(this, h).u
        };
        c.prototype.get = function(h) {
            return (h = d(this, h).u) && h.value
        };
        c.prototype.entries = function() {
            return e(this, function(h) {
                return [h.key, h.value]
            })
        };
        c.prototype.keys = function() {
            return e(this, function(h) {
                return h.key
            })
        };
        c.prototype.values = function() {
            return e(this, function(h) {
                return h.value
            })
        };
        c.prototype.forEach = function(h, k) {
            for (var l = this.entries(), q; !(q = l.next()).done;) q =
                q.value, h.call(k, q[1], q[0], this)
        };
        c.prototype[t(r.Symbol, "iterator")] = c.prototype.entries;
        var d = function(h, k) {
                var l = k && typeof k;
                "object" == l || "function" == l ? b.has(k) ? l = b.get(k) : (l = "" + ++f, b.set(k, l)) : l = "p_" + k;
                var q = h.ha[l];
                if (q && v(h.ha, l))
                    for (h = 0; h < q.length; h++) {
                        var x = q[h];
                        if (k !== k && x.key !== x.key || k === x.key) return {
                            id: l,
                            list: q,
                            index: h,
                            u: x
                        }
                    }
                return {
                    id: l,
                    list: q,
                    index: -1,
                    u: void 0
                }
            },
            e = function(h, k) {
                var l = h.S;
                return fa(function() {
                    if (l) {
                        for (; l.head != h.S;) l = l.V;
                        for (; l.next != l.head;) return l = l.next, {
                            done: !1,
                            value: k(l)
                        };
                        l = null
                    }
                    return {
                        done: !0,
                        value: void 0
                    }
                })
            },
            g = function() {
                var h = {};
                return h.V = h.next = h.head = h
            },
            f = 0;
        return c
    }, "es6");
    var ka = function(a, b) {
        a instanceof String && (a += "");
        var c = 0,
            d = !1,
            e = {
                next: function() {
                    if (!d && c < a.length) {
                        var g = c++;
                        return {
                            value: b(g, a[g]),
                            done: !1
                        }
                    }
                    d = !0;
                    return {
                        done: !0,
                        value: void 0
                    }
                }
            };
        e[t(r.Symbol, "iterator")] = function() {
            return e
        };
        return e
    };
    u("Array.prototype.values", function(a) {
        return a ? a : function() {
            return ka(this, function(b, c) {
                return c
            })
        }
    }, "es8");
    u("Array.prototype.keys", function(a) {
        return a ? a : function() {
            return ka(this, function(b) {
                return b
            })
        }
    }, "es6");
    u("Array.from", function(a) {
        return a ? a : function(b, c, d) {
            c = null != c ? c : function(h) {
                return h
            };
            var e = [],
                g = "undefined" != typeof r.Symbol && t(r.Symbol, "iterator") && b[t(r.Symbol, "iterator")];
            if ("function" == typeof g) {
                b = g.call(b);
                for (var f = 0; !(g = b.next()).done;) e.push(c.call(d, g.value, f++))
            } else
                for (g = b.length, f = 0; f < g; f++) e.push(c.call(d, b[f], f));
            return e
        }
    }, "es6");
    u("Object.values", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) v(b, d) && c.push(b[d]);
            return c
        }
    }, "es8");
    u("Object.is", function(a) {
        return a ? a : function(b, c) {
            return b === c ? 0 !== b || 1 / b === 1 / c : b !== b && c !== c
        }
    }, "es6");
    u("Array.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            var d = this;
            d instanceof String && (d = String(d));
            var e = d.length;
            c = c || 0;
            for (0 > c && (c = Math.max(c + e, 0)); c < e; c++) {
                var g = d[c];
                if (g === b || t(Object, "is").call(Object, g, b)) return !0
            }
            return !1
        }
    }, "es7");
    u("String.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            if (null == this) throw new TypeError("The 'this' value for String.prototype.includes must not be null or undefined");
            if (b instanceof RegExp) throw new TypeError("First argument to String.prototype.includes must not be a regular expression");
            return -1 !== (this + "").indexOf(b, c || 0)
        }
    }, "es6");
    var la = da && "function" == typeof t(Object, "assign") ? t(Object, "assign") : function(a, b) {
        for (var c = 1; c < arguments.length; c++) {
            var d = arguments[c];
            if (d)
                for (var e in d) v(d, e) && (a[e] = d[e])
        }
        return a
    };
    u("Object.assign", function(a) {
        return a || la
    }, "es6");
    var w = this || self,
        ma = function(a, b) {
            a = a.split(".");
            var c = window || w;
            a[0] in c || "undefined" == typeof c.execScript || c.execScript("var " + a[0]);
            for (var d; a.length && (d = a.shift());) a.length || void 0 === b ? c = c[d] && c[d] !== Object.prototype[d] ? c[d] : c[d] = {} : c[d] = b
        },
        na = function() {},
        z = function(a) {
            var b = typeof a;
            return "object" != b ? b : a ? Array.isArray(a) ? "array" : b : "null"
        },
        oa = function(a) {
            var b = z(a);
            return "array" == b || "object" == b && "number" == typeof a.length
        },
        pa = function(a) {
            var b = typeof a;
            return "object" == b && null != a || "function" ==
                b
        },
        qa = function(a, b, c) {
            return a.call.apply(a.bind, arguments)
        },
        ra = function(a, b, c) {
            if (!a) throw Error();
            if (2 < arguments.length) {
                var d = Array.prototype.slice.call(arguments, 2);
                return function() {
                    var e = Array.prototype.slice.call(arguments);
                    Array.prototype.unshift.apply(e, d);
                    return a.apply(b, e)
                }
            }
            return function() {
                return a.apply(b, arguments)
            }
        },
        sa = function(a, b, c) {
            sa = Function.prototype.bind && -1 != Function.prototype.bind.toString().indexOf("native code") ? qa : ra;
            return sa.apply(null, arguments)
        },
        ta = function(a, b) {
            function c() {}
            c.prototype = b.prototype;
            a.Ka = b.prototype;
            a.prototype = new c;
            a.prototype.constructor = a;
            a.nd = function(d, e, g) {
                for (var f = Array(arguments.length - 2), h = 2; h < arguments.length; h++) f[h - 2] = arguments[h];
                return b.prototype[e].apply(d, f)
            }
        },
        ua = function(a) {
            return a
        };

    function va(a) {
        if (Error.captureStackTrace) Error.captureStackTrace(this, va);
        else {
            var b = Error().stack;
            b && (this.stack = b)
        }
        a && (this.message = String(a))
    }
    ta(va, Error);
    va.prototype.name = "CustomError";
    var wa = function(a, b) {
        a = a.split("%s");
        for (var c = "", d = a.length - 1, e = 0; e < d; e++) c += a[e] + (e < b.length ? b[e] : "%s");
        va.call(this, c + a[d])
    };
    ta(wa, va);
    wa.prototype.name = "AssertionError";
    var xa = function(a, b, c, d) {
            var e = "Assertion failed";
            if (c) {
                e += ": " + c;
                var g = d
            } else a && (e += ": " + a, g = b);
            throw new wa("" + e, g || []);
        },
        A = function(a, b, c) {
            a || xa("", null, b, Array.prototype.slice.call(arguments, 2));
            return a
        },
        ya = function(a, b) {
            throw new wa("Failure" + (a ? ": " + a : ""), Array.prototype.slice.call(arguments, 1));
        },
        za = function(a, b, c) {
            "number" !== typeof a && xa("Expected number but got %s: %s.", [z(a), a], b, Array.prototype.slice.call(arguments, 2));
            return a
        },
        Aa = function(a, b, c) {
            "string" !== typeof a && xa("Expected string but got %s: %s.", [z(a), a], b, Array.prototype.slice.call(arguments, 2))
        },
        Ba = function(a, b, c) {
            pa(a) || xa("Expected object but got %s: %s.", [z(a), a], b, Array.prototype.slice.call(arguments, 2))
        };
    var B = function(a, b) {
        this.zb = a === Ca && b || "";
        this.cc = Da
    };
    B.prototype.Ca = !0;
    B.prototype.za = function() {
        return this.zb
    };
    B.prototype.toString = function() {
        return "Const{" + this.zb + "}"
    };
    var C = function(a) {
            if (a instanceof B && a.constructor === B && a.cc === Da) return a.zb;
            ya("expected object of type Const, got '" + a + "'");
            return "type_error:Const"
        },
        D = function(a) {
            return new B(Ca, a)
        },
        Da = {},
        Ca = {};
    var Ea = {
            $b: "PAYMENT_AUTHORIZATION",
            ac: "SHIPPING_ADDRESS",
            bc: "SHIPPING_OPTION",
            hd: "UNKNOWN_INTENT"
        },
        Fa = {
            Ic: "CANARY",
            Sc: "LOCAL",
            $c: "PREPROD",
            ad: "PRODUCTION",
            bd: "SANDBOX",
            ed: "TEST",
            fd: "TIN"
        },
        Ga = {
            Jc: "CARD",
            gd: "TOKENIZED_CARD",
            kd: "UPI"
        },
        Ha = {
            Lc: "CRYPTOGRAM_3DS",
            Xc: "PAN_ONLY"
        },
        Ia = {
            Oc: "ESTIMATED",
            Qc: "FINAL",
            Uc: "NOT_CURRENTLY_KNOWN"
        },
        Ja = {
            SHORT: "short",
            Tc: "long",
            Zc: "plain",
            Hc: "buy",
            Nc: "donate",
            Gc: "book",
            Kc: "checkout",
            Wc: "order",
            Yc: "pay",
            dd: "subscribe"
        },
        Ka = {
            Mc: "default",
            Fc: "black",
            ld: "white"
        },
        La = {
            cd: "static",
            Pc: "fill"
        },
        Ma = {
            buy: {
                en: 152,
                ar: 189,
                bg: 163,
                ca: 182,
                cs: 192,
                da: 154,
                de: 183,
                el: 178,
                es: 183,
                et: 147,
                fi: 148,
                fr: 183,
                hr: 157,
                id: 186,
                it: 182,
                ja: 148,
                ko: 137,
                ms: 186,
                nl: 167,
                no: 158,
                pl: 182,
                pt: 193,
                ru: 206,
                sk: 157,
                sl: 211,
                sr: 146,
                sv: 154,
                th: 146,
                tr: 161,
                uk: 207,
                zh: 156
            },
            book: {
                ar: 205,
                bg: 233,
                ca: 187,
                cs: 213,
                da: 162,
                de: 176,
                el: 180,
                en: 161,
                es: 188,
                et: 186,
                fi: 152,
                fr: 197,
                hr: 198,
                id: 195,
                it: 178,
                ja: 150,
                ko: 150,
                ms: 211,
                nl: 178,
                no: 195,
                pl: 221,
                pt: 208,
                ru: 265,
                sk: 206,
                sl: 266,
                sr: 196,
                sv: 161,
                th: 150,
                tr: 238,
                uk: 248,
                zh: 158
            },
            checkout: {
                ar: 245,
                bg: 200,
                ca: 268,
                cs: 175,
                da: 162,
                de: 188,
                el: 286,
                en: 201,
                es: 188,
                et: 171,
                fi: 158,
                fr: 170,
                hr: 166,
                id: 226,
                it: 256,
                ja: 150,
                ko: 150,
                ms: 291,
                nl: 178,
                no: 230,
                pl: 187,
                pt: 271,
                ru: 283,
                sk: 176,
                sl: 313,
                sr: 153,
                sv: 172,
                th: 168,
                tr: 195,
                uk: 216,
                zh: 158
            },
            donate: {
                ar: 205,
                bg: 205,
                ca: 162,
                cs: 212,
                da: 171,
                de: 186,
                el: 163,
                en: 180,
                es: 165,
                et: 150,
                fi: 171,
                fr: 225,
                hr: 182,
                id: 237,
                it: 157,
                ja: 167,
                ko: 150,
                ms: 201,
                nl: 187,
                no: 171,
                pl: 252,
                pt: 175,
                ru: 342,
                sk: 178,
                sl: 242,
                sr: 171,
                sv: 181,
                th: 158,
                tr: 181,
                uk: 256,
                zh: 158
            },
            order: {
                ar: 198,
                bg: 195,
                ca: 247,
                cs: 198,
                da: 166,
                de: 190,
                el: 208,
                en: 170,
                es: 157,
                et: 150,
                fi: 150,
                fr: 226,
                hr: 201,
                id: 195,
                it: 171,
                ja: 150,
                ko: 150,
                ms: 195,
                nl: 192,
                no: 171,
                pl: 190,
                pt: 177,
                ru: 207,
                sk: 190,
                sl: 240,
                sr: 165,
                sv: 176,
                th: 151,
                tr: 188,
                uk: 216,
                zh: 158
            },
            pay: {
                ar: 202,
                bg: 200,
                ca: 160,
                cs: 183,
                da: 162,
                de: 188,
                el: 185,
                en: 150,
                es: 162,
                et: 150,
                fi: 158,
                fr: 170,
                hr: 172,
                id: 192,
                it: 155,
                ja: 150,
                ko: 150,
                ms: 192,
                nl: 178,
                no: 162,
                pl: 187,
                pt: 182,
                ru: 213,
                sk: 176,
                sl: 225,
                sr: 153,
                sv: 172,
                th: 168,
                tr: 150,
                uk: 216,
                zh: 158
            },
            subscribe: {
                ar: 221,
                bg: 217,
                ca: 226,
                cs: 201,
                da: 192,
                de: 208,
                el: 180,
                en: 202,
                es: 206,
                et: 150,
                fi: 150,
                fr: 206,
                hr: 178,
                id: 260,
                it: 190,
                ja: 150,
                ko: 150,
                ms: 216,
                nl: 208,
                no: 192,
                pl: 221,
                pt: 196,
                ru: 243,
                sk: 193,
                sl: 333,
                sr: 217,
                sv: 228,
                th: 213,
                tr: 173,
                uk: 305,
                zh: 158
            }
        },
        Na = D('<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" direction="ltr" height="36px" width="130px"><style>@import url(//fonts.googleapis.com/css?family=Google+Sans_old:500)</style><line x1="2" y1="10.5" x2="2" y2="29.5" style="stroke: #d9d9d9; stroke-width:2"></line><image x="11" y="6" width="37.5" height="29" preserveAspectRatio="none" xlink:href="https://www.gstatic.com/images/icons/material/system/1x/payment_grey600_36dp.png"></image><text x="52" y="25.5" class="small" style="font: 15px \'Google Sans\', sans-serif; fill: #5F6368">\u2022\u2022\u2022\u2022\u2022\u2022</text></svg>'),
        Oa = D('<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" direction="ltr" height="36px" width="130px"><style>@import url(//fonts.googleapis.com/css?family=Google+Sans_old:500)</style><line x1="2" y1="10.5" x2="2" y2="29.5" style="stroke: #5F6368; stroke-width:2"></line><image x="11" y="6" width="37.5" height="29" preserveAspectRatio="none" xlink:href="https://www.gstatic.com/images/icons/material/system/1x/payment_white_36dp.png"></image><text x="52" y="25.5" class="small" style="font: 15px \'Google Sans\', sans-serif; fill: #FFFFFF">\u2022\u2022\u2022\u2022\u2022\u2022</text></svg>'),
        Pa = D('<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" direction="ltr" viewBox="0 0 130 36"><style>@import url(//fonts.googleapis.com/css?family=Google+Sans_old:500)</style><line x1="8" y1="7" x2="8" y2="26" style="stroke: #d9d9d9; stroke-width:2"></line><image x="16" y="2.5" width="37.5" height="29" preserveAspectRatio="none" xlink:href="https://www.gstatic.com/images/icons/material/system/1x/payment_grey600_36dp.png"></image><text x="57" y="22" class="small" style="font: 15px \'Google Sans\', sans-serif; fill: #5f6368">\u2022\u2022\u2022\u2022\u2022\u2022</text></svg>'),
        Qa = D('<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" direction="ltr" viewBox="0 0 130 36"><style>@import url(//fonts.googleapis.com/css?family=Google+Sans_old:500)</style><line x1="8" y1="7" x2="8" y2="26" style="stroke: #5f6368; stroke-width:2"></line><image x="16" y="2.5" width="37.5" height="29" preserveAspectRatio="none" xlink:href="https://www.gstatic.com/images/icons/material/system/1x/payment_white_36dp.png"></image><text x="57" y="22" class="small" style="font: 15px \'Google Sans\', sans-serif; fill: #fff">\u2022\u2022\u2022\u2022\u2022\u2022</text></svg>');

    function Ra(a, b) {
        b = void 0 === b ? document : b;
        var c = document.createElement("style");
        c.type = "text/css";
        c.textContent = a;
        if (b instanceof HTMLDocument) document.head.appendChild(c);
        else if (b instanceof ShadowRoot) b.appendChild(c);
        else throw Error("Parameter 'buttonRootNode' should be either document or a shadowroot.");
    };
    /*

    Math.uuid.js (v1.4)
    http://www.broofa.com
    mailto:robert@broofa.com
    Copyright (c) 2010 Robert Kieffer
    Dual licensed under the MIT and GPL licenses.
    */
    var Sa = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".split("");

    function Ta(a) {
        for (var b = Array(36), c = 0, d, e = 0; 36 > e; e++) 8 == e || 13 == e || 18 == e || 23 == e ? b[e] = "-" : 14 == e ? b[e] = "4" : (2 >= c && (c = 33554432 + 16777216 * Math.random() | 0), d = c & 15, c >>= 4, b[e] = Sa[19 == e ? d & 3 | 8 : d]);
        return b.join("") + "." + a
    }

    function Ua(a) {
        for (var b = 1; b < arguments.length; b++) a = Va(a, arguments[b]);
        return a
    }

    function Va(a, b) {
        if ("object" !== typeof b || null === b) return a;
        for (var c in b) b.hasOwnProperty(c) && void 0 !== b[c] && (null == b[c] ? a[c] = null : null == a[c] || "object" !== typeof a[c] || "object" !== typeof b[c] || Array.isArray(b[c]) || Array.isArray(a[c]) ? a[c] = b[c] : Va(a[c], b[c]));
        return a
    }

    function Wa(a) {
        var b = 0,
            c;
        if (0 == a.length) return b;
        for (c = 0; c < a.length; c++) {
            var d = a.charCodeAt(c);
            b = (b << 5) - b + d;
            b &= b
        }
        return b
    }

    function E(a) {
        console.error("DEVELOPER_ERROR in " + a.fa + ": " + a.errorMessage)
    };
    var Xa = Array.prototype.indexOf ? function(a, b) {
        A(null != a.length);
        return Array.prototype.indexOf.call(a, b, void 0)
    } : function(a, b) {
        if ("string" === typeof a) return "string" !== typeof b || 1 != b.length ? -1 : a.indexOf(b, 0);
        for (var c = 0; c < a.length; c++)
            if (c in a && a[c] === b) return c;
        return -1
    };
    var Ya = /&/g,
        Za = /</g,
        $a = />/g,
        ab = /"/g,
        bb = /'/g,
        cb = /\x00/g,
        db = /[\x00&<>"']/;

    function eb() {
        var a = w.navigator;
        return a && (a = a.userAgent) ? a : ""
    }

    function F(a) {
        return -1 != eb().indexOf(a)
    };
    var fb = function(a) {
        fb[" "](a);
        return a
    };
    fb[" "] = na;
    var gb = F("Trident") || F("MSIE"),
        hb = F("Gecko") && !(-1 != eb().toLowerCase().indexOf("webkit") && !F("Edge")) && !(F("Trident") || F("MSIE")) && !F("Edge"),
        ib = -1 != eb().toLowerCase().indexOf("webkit") && !F("Edge");

    function jb(a, b) {
        for (var c in a)
            if (b.call(void 0, a[c], c, a)) return !0;
        return !1
    }
    var kb = "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");

    function lb(a, b) {
        for (var c, d, e = 1; e < arguments.length; e++) {
            d = arguments[e];
            for (c in d) a[c] = d[c];
            for (var g = 0; g < kb.length; g++) c = kb[g], Object.prototype.hasOwnProperty.call(d, c) && (a[c] = d[c])
        }
    };
    var mb, nb = function() {
        if (void 0 === mb) {
            var a = null,
                b = w.trustedTypes;
            if (b && b.createPolicy) try {
                a = b.createPolicy("goog#html", {
                    createHTML: ua,
                    createScript: ua,
                    createScriptURL: ua
                })
            } catch (c) {
                w.console && w.console.error(c.message)
            }
            mb = a
        }
        return mb
    };
    var pb = function(a, b) {
        this.sb = b === ob ? a : ""
    };
    m = pb.prototype;
    m.Ca = !0;
    m.za = function() {
        return this.sb.toString()
    };
    m.kb = !0;
    m.ya = function() {
        return 1
    };
    m.toString = function() {
        return this.sb + ""
    };
    var qb = function(a) {
            if (a instanceof pb && a.constructor === pb) return a.sb;
            ya("expected object of type TrustedResourceUrl, got '" + a + "' of type " + z(a));
            return "type_error:TrustedResourceUrl"
        },
        ub = function(a, b) {
            var c = C(a);
            if (!rb.test(c)) throw Error("Invalid TrustedResourceUrl format: " + c);
            a = c.replace(sb, function(d, e) {
                if (!Object.prototype.hasOwnProperty.call(b, e)) throw Error('Found marker, "' + e + '", in format string, "' + c + '", but no valid label mapping found in args: ' + JSON.stringify(b));
                d = b[e];
                return d instanceof
                B ? C(d) : encodeURIComponent(String(d))
            });
            return tb(a)
        },
        sb = /%{(\w+)}/g,
        rb = RegExp("^((https:)?//[0-9a-z.:[\\]-]+/|/[^/\\\\]|[^:/\\\\%]+/|[^:/\\\\%]*[?#]|about:blank#)", "i"),
        ob = {},
        tb = function(a) {
            var b = nb();
            a = b ? b.createScriptURL(a) : a;
            return new pb(a, ob)
        };
    var wb = function(a, b) {
        this.rb = b === vb ? a : ""
    };
    m = wb.prototype;
    m.Ca = !0;
    m.za = function() {
        return this.rb.toString()
    };
    m.kb = !0;
    m.ya = function() {
        return 1
    };
    m.toString = function() {
        return this.rb.toString()
    };
    var xb = function(a) {
            if (a instanceof wb && a.constructor === wb) return a.rb;
            ya("expected object of type SafeUrl, got '" + a + "' of type " + z(a));
            return "type_error:SafeUrl"
        },
        yb = /^(?:(?:https?|mailto|ftp):|[^:/?#]*(?:[/?#]|$))/i,
        vb = {};
    var zb = {},
        H = function(a, b, c) {
            this.qb = c === zb ? a : "";
            this.jc = b;
            this.Ca = this.kb = !0
        };
    H.prototype.ya = function() {
        return this.jc
    };
    H.prototype.za = function() {
        return this.qb.toString()
    };
    H.prototype.toString = function() {
        return this.qb.toString()
    };
    var Ab = function(a) {
            if (a instanceof H && a.constructor === H) return a.qb;
            ya("expected object of type SafeHtml, got '" + a + "' of type " + z(a));
            return "type_error:SafeHtml"
        },
        Cb = function(a) {
            if (a instanceof H) return a;
            var b = "object" == typeof a,
                c = null;
            b && a.kb && (c = a.ya());
            a = b && a.Ca ? a.za() : String(a);
            db.test(a) && (-1 != a.indexOf("&") && (a = a.replace(Ya, "&amp;")), -1 != a.indexOf("<") && (a = a.replace(Za, "&lt;")), -1 != a.indexOf(">") && (a = a.replace($a, "&gt;")), -1 != a.indexOf('"') && (a = a.replace(ab, "&quot;")), -1 != a.indexOf("'") && (a =
                a.replace(bb, "&#39;")), -1 != a.indexOf("\x00") && (a = a.replace(cb, "&#0;")));
            return Bb(a, c)
        },
        Eb = function(a) {
            var b = Cb(Db),
                c = b.ya(),
                d = [],
                e = function(g) {
                    Array.isArray(g) ? g.forEach(e) : (g = Cb(g), d.push(Ab(g).toString()), g = g.ya(), 0 == c ? c = g : 0 != g && c != g && (c = null))
                };
            a.forEach(e);
            return Bb(d.join(Ab(b).toString()), c)
        },
        Fb = function(a) {
            return Eb(Array.prototype.slice.call(arguments))
        },
        Bb = function(a, b) {
            var c = nb();
            a = c ? c.createHTML(a) : a;
            return new H(a, b, zb)
        },
        Db = new H(w.trustedTypes && w.trustedTypes.emptyHTML || "", 0, zb),
        Gb =
        Bb("<br>", 0);
    var Hb = {
            MATH: !0,
            SCRIPT: !0,
            STYLE: !0,
            SVG: !0,
            TEMPLATE: !0
        },
        Ib = function(a) {
            var b = !1,
                c;
            return function() {
                b || (c = a(), b = !0);
                return c
            }
        }(function() {
            if ("undefined" === typeof document) return !1;
            var a = document.createElement("div"),
                b = document.createElement("div");
            b.appendChild(document.createElement("div"));
            a.appendChild(b);
            if (!a.firstChild) return !1;
            b = a.firstChild.firstChild;
            a.innerHTML = Ab(Db);
            return !b.parentElement
        }),
        Jb = function(a, b) {
            if (a.tagName && Hb[a.tagName.toUpperCase()]) throw Error("goog.dom.safe.setInnerHtml cannot be used to set content of " +
                a.tagName + ".");
            if (Ib())
                for (; a.lastChild;) a.removeChild(a.lastChild);
            a.innerHTML = Ab(b)
        },
        Kb = function(a, b, c, d) {
            a instanceof wb || a instanceof wb || (a = "object" == typeof a && a.Ca ? a.za() : String(a), A(yb.test(a), "%s does not match the safe URL pattern", a) || (a = "about:invalid#zClosurez"), a = new wb(a, vb));
            b = b || w;
            c = c instanceof B ? C(c) : c || "";
            return void 0 !== d ? b.open(xb(a), c, d) : b.open(xb(a), c)
        };
    var Lb = function() {
            return "transition".replace(/\-([a-z])/g, function(a, b) {
                return b.toUpperCase()
            })
        },
        Mb = function(a) {
            return a.replace(RegExp("(^|[\\s]+)([a-z])", "g"), function(b, c, d) {
                return c + d.toUpperCase()
            })
        };
    var Nb = function(a) {
        var b = Array.prototype.map.call(arguments, C).join(""),
            c = D("Constant HTML string, that gets turned into a Node later, so it will be automatically balanced.");
        Aa(C(c), "must provide justification");
        A(!/^[\s\xa0]*$/.test(C(c)), "must provide non-empty justification");
        b = Bb(b, null);
        c = document;
        var d = "DIV";
        "application/xhtml+xml" === c.contentType && (d = d.toLowerCase());
        d = c.createElement(d);
        gb ? (Jb(d, Fb(Gb, b)), d.removeChild(A(d.firstChild))) : Jb(d, b);
        if (1 == d.childNodes.length) b = d.removeChild(A(d.firstChild));
        else
            for (b = c.createDocumentFragment(); d.firstChild;) b.appendChild(d.firstChild);
        return b
    };
    var Ob = function(a) {
            if (a.ia && "function" == typeof a.ia) return a.ia();
            if ("undefined" !== typeof r.Map && a instanceof r.Map || "undefined" !== typeof Set && a instanceof Set) return t(Array, "from").call(Array, t(a, "values").call(a));
            if ("string" === typeof a) return a.split("");
            if (oa(a)) {
                for (var b = [], c = a.length, d = 0; d < c; d++) b.push(a[d]);
                return b
            }
            b = [];
            c = 0;
            for (d in a) b[c++] = a[d];
            return b
        },
        Pb = function(a) {
            if (a.hb && "function" == typeof a.hb) return a.hb();
            if (!a.ia || "function" != typeof a.ia) {
                if ("undefined" !== typeof r.Map && a instanceof r.Map) return t(Array, "from").call(Array, t(a, "keys").call(a));
                if (!("undefined" !== typeof Set && a instanceof Set)) {
                    if (oa(a) || "string" === typeof a) {
                        var b = [];
                        a = a.length;
                        for (var c = 0; c < a; c++) b.push(c);
                        return b
                    }
                    b = [];
                    c = 0;
                    for (var d in a) b[c++] = d;
                    return b
                }
            }
        },
        Qb = function(a, b, c) {
            if (a.forEach && "function" == typeof a.forEach) a.forEach(b, c);
            else if (oa(a) || "string" === typeof a) Array.prototype.forEach.call(a, b, c);
            else
                for (var d = Pb(a), e = Ob(a), g = e.length, f = 0; f < g; f++) b.call(c, e[f], d && d[f], a)
        };
    var Rb = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$"),
        Sb = function(a) {
            var b = a.match(Rb);
            a = b[1];
            var c = b[3];
            b = b[4];
            var d = "";
            a && (d += a + ":");
            c && (d = d + "//" + c, b && (d += ":" + b));
            return d
        },
        Tb = function(a, b) {
            if (a) {
                a = a.split("&");
                for (var c = 0; c < a.length; c++) {
                    var d = a[c].indexOf("="),
                        e = null;
                    if (0 <= d) {
                        var g = a[c].substring(0, d);
                        e = a[c].substring(d + 1)
                    } else g = a[c];
                    b(g, e ? decodeURIComponent(e.replace(/\+/g, " ")) : "")
                }
            }
        };
    var I = function(a) {
        this.P = this.ma = this.aa = "";
        this.j = null;
        this.M = this.N = "";
        this.G = this.nc = !1;
        if (a instanceof I) {
            this.G = a.G;
            Ub(this, a.aa);
            var b = a.ma;
            J(this);
            this.ma = b;
            b = a.P;
            J(this);
            this.P = b;
            Vb(this, a.j);
            b = a.N;
            J(this);
            this.N = b;
            Wb(this, a.I.clone());
            a = a.M;
            J(this);
            this.M = a
        } else a && (b = String(a).match(Rb)) ? (this.G = !1, Ub(this, b[1] || "", !0), a = b[2] || "", J(this), this.ma = Xb(a), a = b[3] || "", J(this), this.P = Xb(a, !0), Vb(this, b[4]), a = b[5] || "", J(this), this.N = Xb(a, !0), Wb(this, b[6] || "", !0), a = b[7] || "", J(this), this.M = Xb(a)) :
            (this.G = !1, this.I = new K(null, this.G))
    };
    I.prototype.toString = function() {
        var a = [],
            b = this.aa;
        b && a.push(Yb(b, Zb, !0), ":");
        var c = this.P;
        if (c || "file" == b) a.push("//"), (b = this.ma) && a.push(Yb(b, Zb, !0), "@"), a.push(encodeURIComponent(String(c)).replace(/%25([0-9a-fA-F]{2})/g, "%$1")), c = this.j, null != c && a.push(":", String(c));
        if (c = this.N) this.P && "/" != c.charAt(0) && a.push("/"), a.push(Yb(c, "/" == c.charAt(0) ? $b : ac, !0));
        (c = this.I.toString()) && a.push("?", c);
        (c = this.M) && a.push("#", Yb(c, bc));
        return a.join("")
    };
    I.prototype.resolve = function(a) {
        var b = this.clone(),
            c = !!a.aa;
        c ? Ub(b, a.aa) : c = !!a.ma;
        if (c) {
            var d = a.ma;
            J(b);
            b.ma = d
        } else c = !!a.P;
        c ? (d = a.P, J(b), b.P = d) : c = null != a.j;
        d = a.N;
        if (c) Vb(b, a.j);
        else if (c = !!a.N) {
            if ("/" != d.charAt(0))
                if (this.P && !this.N) d = "/" + d;
                else {
                    var e = b.N.lastIndexOf("/"); - 1 != e && (d = b.N.substr(0, e + 1) + d)
                }
            e = d;
            if (".." == e || "." == e) d = "";
            else if (-1 != e.indexOf("./") || -1 != e.indexOf("/.")) {
                d = 0 == e.lastIndexOf("/", 0);
                e = e.split("/");
                for (var g = [], f = 0; f < e.length;) {
                    var h = e[f++];
                    "." == h ? d && f == e.length && g.push("") :
                        ".." == h ? ((1 < g.length || 1 == g.length && "" != g[0]) && g.pop(), d && f == e.length && g.push("")) : (g.push(h), d = !0)
                }
                d = g.join("/")
            } else d = e
        }
        c ? (J(b), b.N = d) : c = "" !== a.I.toString();
        c ? Wb(b, a.I.clone()) : c = !!a.M;
        c && (a = a.M, J(b), b.M = a);
        return b
    };
    I.prototype.clone = function() {
        return new I(this)
    };
    var Ub = function(a, b, c) {
            J(a);
            a.aa = c ? Xb(b, !0) : b;
            a.aa && (a.aa = a.aa.replace(/:$/, ""))
        },
        Vb = function(a, b) {
            J(a);
            if (b) {
                b = Number(b);
                if (isNaN(b) || 0 > b) throw Error("Bad port number " + b);
                a.j = b
            } else a.j = null
        },
        Wb = function(a, b, c) {
            J(a);
            b instanceof K ? (a.I = b, a.I.xb(a.G)) : (c || (b = Yb(b, cc)), a.I = new K(b, a.G))
        };
    I.prototype.getQuery = function() {
        return this.I.toString()
    };
    var dc = function(a, b, c) {
        J(a);
        a.I.set(b, c)
    };
    I.prototype.removeParameter = function(a) {
        J(this);
        this.I.remove(a);
        return this
    };
    var J = function(a) {
        if (a.nc) throw Error("Tried to modify a read-only Uri");
    };
    I.prototype.xb = function(a) {
        this.G = a;
        this.I && this.I.xb(a)
    };
    var Xb = function(a, b) {
            return a ? b ? decodeURI(a.replace(/%25/g, "%2525")) : decodeURIComponent(a) : ""
        },
        Yb = function(a, b, c) {
            return "string" === typeof a ? (a = encodeURI(a).replace(b, ec), c && (a = a.replace(/%25([0-9a-fA-F]{2})/g, "%$1")), a) : null
        },
        ec = function(a) {
            a = a.charCodeAt(0);
            return "%" + (a >> 4 & 15).toString(16) + (a & 15).toString(16)
        },
        Zb = /[#\/\?@]/g,
        ac = /[#\?:]/g,
        $b = /[#\?]/g,
        cc = /[#\?@]/g,
        bc = /#/g,
        K = function(a, b) {
            this.A = this.h = null;
            this.D = a || null;
            this.G = !!b
        },
        L = function(a) {
            a.h || (a.h = new r.Map, a.A = 0, a.D && Tb(a.D, function(b, c) {
                a.add(decodeURIComponent(b.replace(/\+/g,
                    " ")), c)
            }))
        };
    K.prototype.add = function(a, b) {
        L(this);
        this.D = null;
        a = fc(this, a);
        var c = this.h.get(a);
        c || this.h.set(a, c = []);
        c.push(b);
        this.A = za(this.A) + 1;
        return this
    };
    K.prototype.remove = function(a) {
        L(this);
        a = fc(this, a);
        return this.h.has(a) ? (this.D = null, this.A = za(this.A) - this.h.get(a).length, this.h.delete(a)) : !1
    };
    K.prototype.clear = function() {
        this.h = this.D = null;
        this.A = 0
    };
    var gc = function(a, b) {
        L(a);
        b = fc(a, b);
        return a.h.has(b)
    };
    m = K.prototype;
    m.forEach = function(a, b) {
        L(this);
        this.h.forEach(function(c, d) {
            c.forEach(function(e) {
                a.call(b, e, d, this)
            }, this)
        }, this)
    };
    m.hb = function() {
        L(this);
        for (var a = t(Array, "from").call(Array, t(this.h, "values").call(this.h)), b = t(Array, "from").call(Array, t(this.h, "keys").call(this.h)), c = [], d = 0; d < b.length; d++)
            for (var e = a[d], g = 0; g < e.length; g++) c.push(b[d]);
        return c
    };
    m.ia = function(a) {
        L(this);
        var b = [];
        if ("string" === typeof a) gc(this, a) && (b = b.concat(this.h.get(fc(this, a))));
        else {
            a = t(Array, "from").call(Array, t(this.h, "values").call(this.h));
            for (var c = 0; c < a.length; c++) b = b.concat(a[c])
        }
        return b
    };
    m.set = function(a, b) {
        L(this);
        this.D = null;
        a = fc(this, a);
        gc(this, a) && (this.A = za(this.A) - this.h.get(a).length);
        this.h.set(a, [b]);
        this.A = za(this.A) + 1;
        return this
    };
    m.get = function(a, b) {
        if (!a) return b;
        a = this.ia(a);
        return 0 < a.length ? String(a[0]) : b
    };
    m.toString = function() {
        if (this.D) return this.D;
        if (!this.h) return "";
        for (var a = [], b = t(Array, "from").call(Array, t(this.h, "keys").call(this.h)), c = 0; c < b.length; c++) {
            var d = b[c],
                e = encodeURIComponent(String(d));
            d = this.ia(d);
            for (var g = 0; g < d.length; g++) {
                var f = e;
                "" !== d[g] && (f += "=" + encodeURIComponent(String(d[g])));
                a.push(f)
            }
        }
        return this.D = a.join("&")
    };
    m.clone = function() {
        var a = new K;
        a.D = this.D;
        this.h && (a.h = new r.Map(this.h), a.A = this.A);
        return a
    };
    var fc = function(a, b) {
        b = String(b);
        a.G && (b = b.toLowerCase());
        return b
    };
    K.prototype.xb = function(a) {
        a && !this.G && (L(this), this.D = null, this.h.forEach(function(b, c) {
            var d = c.toLowerCase();
            if (c != d && (this.remove(c), this.remove(d), 0 < b.length)) {
                this.D = null;
                c = this.h;
                var e = c.set;
                d = fc(this, d);
                var g = b.length;
                if (0 < g) {
                    for (var f = Array(g), h = 0; h < g; h++) f[h] = b[h];
                    g = f
                } else g = [];
                e.call(c, d, g);
                this.A = za(this.A) + b.length
            }
        }, this));
        this.G = a
    };
    K.prototype.extend = function(a) {
        for (var b = 0; b < arguments.length; b++) Qb(arguments[b], function(c, d) {
            this.add(d, c)
        }, this)
    };
    var hc = [],
        ic = [],
        jc = [],
        kc = window.location.hostname,
        lc = window.whitelistedDomainsHashedValueListForGpayButtonWithCardInfo || [],
        mc = window.denylistedDomainsHashedValueListForGpayButtonWithCardInfo || [],
        nc = window.denylistedMerchentIdsHashedValueListForGpayButtonWithCardInfo || [];

    function oc(a) {
        t(jc, "includes").call(jc, a.buttonRootNode || document) || (Ra("\n  .gpay-card-info-container {\n    padding: 0;\n    position: relative;\n    min-width: 240px;\n    height: 40px;\n    min-height: 40px;\n    border-radius: 4px;\n    box-shadow: rgba(60, 64, 67, 0.3) 0px 1px 1px 0px, rgba(60, 64, 67, 0.15) 0px 1px 3px 1px;\n    cursor: pointer;\n    border: 0px;\n  }\n\n  .gpay-card-info-container.black,\n  .gpay-card-info-animation-container.black {\n    background-color: #000;\n    box-shadow: none;\n  }\n\n  .gpay-card-info-container.white,\n  .gpay-card-info-animation-container.white {\n    background-color: #fff;\n  }\n\n  .gpay-card-info-container.black.active {\n    background-color: #5f6368;\n  }\n\n  .gpay-card-info-container.black.hover,\n  .gpay-card-info-animation-container.black.hover {\n    background-color: #3c4043;\n  }\n\n  .gpay-card-info-container.white.active {\n    background-color: #fff;\n  }\n\n  .gpay-card-info-container.white.focus {\n    box-shadow: #e8e8e8 0 1px 1px 0, #e8e8e8 0 1px 3px;\n  }\n\n  .gpay-card-info-container.white.hover,\n  .gpay-card-info-animation-container.white.hover {\n    background-color: #f8f8f8;\n  }\n\n  .gpay-card-info-iframe {\n    border: 0;\n    display: block;\n    height: 40px;\n    margin: auto;\n    max-width: 100%;\n    width: 240px;\n  }\n\n  .gpay-card-info-container-fill .gpay-card-info-iframe{\n    position: absolute;\n    top: 0;\n    height: 100%;\n    width: 100%;\n  }\n\n  .gpay-card-info-container-fill,\n    .gpay-card-info-container-fill > .gpay-card-info-container{\n    width: 100%;\n    height: inherit;\n  }\n\n  .gpay-card-info-container-fill .gpay-card-info-placeholder-container{\n    align-items: center;\n    justify-content: center;\n    width: 100%;\n    padding-top: 3px;\n    box-sizing: border-box;\n    overflow: hidden;\n  }\n\n  .gpay-card-info-container-fill .gpay-card-info-placeholder-svg-container{\n    position: relative;\n    width: 60%;\n    height: inherit;\n    max-height: 80%;\n    margin-right: -20%;\n  }\n\n  .gpay-card-info-container-fill .gpay-card-info-placeholder-svg-container > svg {\n    position: absolute;\n    left: 0;\n    height: 100%;\n    max-width: 100%;\n  }\n", a.buttonRootNode),
            Ra('\n  .gpay-card-info-animation-container {\n    display: flex;\n    width:100%;\n    position: absolute;\n    z-index: 100;\n    height: 40px;\n    border-radius: 4px;\n  }\n\n  .gpay-card-info-placeholder-container {\n    display: flex;\n    width: 240px;\n    height: 100%;\n    margin: auto;\n  }\n\n  .gpay-card-info-animated-progress-bar-container {\n    display: flex;\n    box-sizing: border-box;\n    position: absolute;\n    width: 100%;\n  }\n\n  .gpay-card-info-animated-progress-bar {\n    border-radius: 4px 4px 0px 0px;\n    animation-duration: 0.5s;\n    animation-fill-mode: forwards;\n    animation-iteration-count: 1;\n    animation-name: gpayProgressFill;\n    animation-timing-function: cubic-bezier(0.97, 0.33, 1, 1);\n    background: #caccce;\n    width: 100%;\n    height: 3px;\n    max-height: 3px;\n  }\n\n  .gpay-card-info-animated-progress-bar-indicator {\n    border-radius: 4px 4px 0px 0px;\n    max-width: 20px;\n    min-width: 20px;\n    height: 3px;\n    max-height: 3px;\n    background: linear-gradient(to right, #caccce 30%, #acaeaf 60%);\n    animation-delay: 0.5s;\n    animation-duration: 1.7s;\n    animation-fill-mode: forwards;\n    animation-iteration-count: infinite;\n    animation-name: gpayPlaceHolderShimmer;\n  }\n\n  .gpay-card-info-iframe-fade-in {\n    animation-fill-mode: forwards;\n    animation-duration: 0.6s;\n    animation-name: gpayIframeFadeIn;\n  }\n\n  .gpay-card-info-animation-container-fade-out {\n    animation-fill-mode: forwards;\n    animation-duration: 0.6s;\n    animation-name: gpayPlaceHolderFadeOut;\n  }\n\n  .gpay-card-info-animation-gpay-logo {\n    margin: 13px 7px 0px  39px;\n    background-origin: content-box;\n    background-position: center center;\n    background-repeat: no-repeat;\n    background-size: contain;\n    height: 17px;\n    max-height: 17px;\n    max-width: 41px;\n    min-width: 41px;\n  }\n\n  .gpay-card-info-animation-gpay-logo.black {\n    background-image: url("https://www.gstatic.com/instantbuy/svg/dark_gpay.svg");\n  }\n\n  .gpay-card-info-animation-gpay-logo.white {\n    background-image: url("https://www.gstatic.com/instantbuy/svg/light_gpay.svg");\n  }\n\n  @keyframes gpayPlaceHolderShimmer{\n    0% {\n      margin-left: 0px;\n    }\n    100% {\n      margin-left: calc(100% - 20px);\n    }\n  }\n\n  @keyframes gpayIframeFadeIn {\n    from {\n        opacity: 0;\n    }\n    to {\n        opacity: 1;\n    }\n  }\n\n  @keyframes gpayPlaceHolderFadeOut {\n    from {\n        opacity: 1;\n    }\n\n    to {\n        opacity: 0;\n    }\n  }\n\n  @keyframes gpayProgressFill {\n    from {\n      width: 0;\n    }\n    to {\n      width: 100%;\n    }\n  }\n\n  .gpay-card-info-container-fill .gpay-card-info-animation-container{\n    top: 0;\n    width: 100%;\n    height: 100%;\n  }\n\n  .gpay-card-info-container-fill .gpay-card-info-animation-gpay-logo{\n    background-position: right;\n    margin: 0 0 0 0;\n    max-width: none;\n    width: 25%;\n    height:inherit;\n    max-height: 50%;\n  }\n',
                a.buttonRootNode), jc.push(a.buttonRootNode || document));
        var b = pc(a),
            c = "white" == a.buttonColor ? "white" : "black",
            d = document.createElement("button");
        qc(d);
        d.setAttribute("class", (-1658203989 === Wa(kc) ? "gpay-button" : "") + " gpay-card-info-container " + b);
        var e = document.createElement("div");
        e.setAttribute("class", "gpay-card-info-animation-container " + c);
        b = document.createElement("div");
        b.setAttribute("class", "gpay-card-info-placeholder-container");
        var g = document.createElement("div");
        g.setAttribute("class", "gpay-card-info-animation-gpay-logo " +
            c);
        var f = Nb("white" == a.buttonColor ? Na : Oa);
        c = document.createElement("div");
        c.setAttribute("class", "gpay-card-info-animated-progress-bar-container");
        var h = document.createElement("div");
        h.setAttribute("class", "gpay-card-info-animated-progress-bar");
        var k = document.createElement("div");
        k.setAttribute("class", "gpay-card-info-animated-progress-bar-indicator");
        h.appendChild(k);
        b.appendChild(g);
        "fill" !== a.buttonSizeMode ? b.appendChild(f) : (g = Nb("white" == a.buttonColor ? Pa : Qa), f = document.createElement("div"), f.appendChild(g),
            f.setAttribute("class", "gpay-card-info-placeholder-svg-container"), b.appendChild(f));
        c.appendChild(h);
        e.appendChild(b);
        e.appendChild(c);
        rc(e);
        d.appendChild(e);
        var l = document.createElement("iframe");
        l.setAttribute("class", "gpay-card-info-iframe");
        l.setAttribute("scrolling", "no");
        b = new I("https://pay.google.com/gp/p/generate_gpay_btn_img");
        dc(b, "buttonColor", a.buttonColor);
        dc(b, "browserLocale", sc(a.buttonLocale));
        dc(b, "buttonSizeMode", a.buttonSizeMode);
        void 0 !== a.allowedPaymentMethods && dc(b, "allowedPaymentMethods",
            JSON.stringify(a.allowedPaymentMethods));
        l.setAttribute("src", b.toString());
        l.onload = function() {
            l.classList.add("gpay-card-info-iframe-fade-in");
            e.classList.add("gpay-card-info-animation-container-fade-out")
        };
        a.onClick && d.addEventListener("click", a.onClick);
        rc(d);
        d.appendChild(l);
        b = document.createElement("div");
        "fill" === a.buttonSizeMode && b.setAttribute("class", "gpay-card-info-container-fill");
        b.appendChild(d);
        return b
    }

    function rc(a) {
        ["mouseover", "mouseout"].map(function(b) {
            a.addEventListener(b, function(c) {
                a.classList.toggle("hover", "mouseover" == c.type);
                var d = document.querySelector(".gpay-card-info-animation-container");
                null !== d && d.classList.toggle("hover", "mouseover" == c.type)
            })
        });
        ["mousedown", "mouseup", "mouseout"].map(function(b) {
            a.addEventListener(b, function(c) {
                a.classList.toggle("active", "mousedown" == c.type)
            })
        });
        ["focus", "blur"].map(function(b) {
            a.addEventListener(b, function(c) {
                a.classList.toggle("focus", "focus" ==
                    c.type)
            })
        })
    }

    function qc(a) {
        a.setAttribute("type", "button");
        a.setAttribute("aria-label", "Google Pay")
    }

    function pc(a) {
        var b = "white";
        "white" !== a.buttonColor && (b = "black");
        var c = a.buttonType || "buy";
        "buy" === a.buttonType ? c = "buy long" : "plain" === a.buttonType && (c = "plain short");
        return b + " " + c + " " + sc(a.buttonLocale)
    }

    function sc(a, b) {
        var c = (navigator.language || navigator.rd || "en").substring(0, 2),
            d = (a || c).substring(0, 2);
        if (d in Ma.buy) return d;
        d !== c && (void 0 === b ? 0 : b) && E({
            fa: "createButton",
            errorMessage: 'Button locale "' + a + '" is not supported, falling back to browser locale.'
        });
        return c in Ma.buy ? c : "en"
    };
    var tc = function() {
        this.Ec = M.contentWindow
    };
    tc.prototype.postMessage = function(a, b) {
        this.Ec.postMessage(a, b)
    };
    /*

     SPDX-License-Identifier: Apache-2.0
    */
    function uc(a, b) {
        a.src = qb(b).toString()
    };
    var vc = {
            jd: 0,
            Rc: 1,
            $b: 2,
            ac: 3,
            bc: 4,
            Vc: 5
        },
        M = null,
        wc = null,
        N = null,
        xc = null,
        yc = Date.now(),
        O = null,
        zc = !1,
        Ac = [],
        Cc = function() {
            Bc({}, 11, ["canMakePaymentForPaymentHandlerResponse"], function() {})
        },
        Bc = function(a, b, c, d) {
            function e(g) {
                var f;
                a: {
                    for (f = 0; f < c.length; f++)
                        if (g.data[c[f]]) {
                            f = !0;
                            break a
                        }
                    f = !1
                }
                f && (d(g), window.removeEventListener("message", e))
            }
            window.addEventListener("message", e);
            a = t(Object, "assign").call(Object, {
                eventType: b
            }, a);
            P(a)
        },
        P = function(a) {
            if (zc && wc) {
                a = t(Object, "assign").call(Object, {
                    buyFlowActivityMode: O,
                    googleTransactionId: xc,
                    originTimeMs: yc
                }, a);
                if ("CANARY" == N) var b = "https://ibfe-canary.corp.google.com";
                else b = "https://pay", "SANDBOX" == N ? b += ".sandbox" : "PREPROD" == N && (b += "-preprod.sandbox"), b += ".google.com";
                wc.postMessage(a, b)
            } else Ac.push(a)
        },
        Dc = function() {
            zc = !0;
            Ac.forEach(function(a) {
                P(a)
            });
            Ac.length = 0
        };
    (function() {
        if (!M) {
            var a = window.gpayInitParams || {};
            N = a.environment || "PRODUCTION";
            M = document.createElement("iframe");
            uc(M, ub(D(("CANARY" == N ? "https://ibfe-canary.corp" : "https://pay") + ("PREPROD" == N ? "-preprod.sandbox" : "SANDBOX" == N ? ".sandbox" : "") + ".google.com/gp/p/ui/payframe?origin=%{windowOrigin}&mid=%{merchantId}"), {
                windowOrigin: window.location.origin,
                merchantId: a.merchantInfo && a.merchantInfo.merchantId || ""
            }));
            P({
                eventType: 15,
                clientLatencyStartMs: Date.now()
            });
            Cc();
            M.height = "0";
            M.width = "0";
            M.style.display =
                "none";
            M.style.visibility = "hidden";
            M.setAttribute("allowpaymentrequest", !0);
            M.onload = function() {
                wc = new tc;
                P({
                    eventType: 17,
                    clientLatencyStartMs: Date.now()
                });
                P({
                    eventType: 16,
                    clientLatencyStartMs: Date.now()
                });
                Dc()
            };
            document.body ? document.body.appendChild(M) : document.addEventListener("DOMContentLoaded", function() {
                document.body.appendChild(M)
            })
        }
    })();
    var Ec = function() {},
        Fc = function(a, b) {
            return new r.Promise(function(c, d) {
                setTimeout(function() {
                    d({
                        reason: "OTHER_ERROR",
                        intent: a,
                        message: "REQUEST_TIMEOUT"
                    })
                }, b)
            })
        },
        Gc = function(a, b) {
            return {
                error: {
                    reason: a.reason || "OTHER_ERROR",
                    intent: a.intent || b,
                    message: a.message
                }
            }
        },
        Hc = function(a, b, c) {
            E({
                fa: "loadPaymentData",
                errorMessage: "An error occurred in call back, please try to avoid this by setting structured error in callback response"
            });
            a && P({
                eventType: b,
                merchantCallbackInfo: {
                    callbackTrigger: c || 0
                }
            })
        };
    Ec.prototype.Qb = function(a, b) {
        null === b.error && (console.warn("Please remove null fields in callback returns."), delete b.error);
        return {
            modifiers: [{
                supportedMethods: ["https://google.com/pay"],
                data: b
            }]
        }
    };
    Ec.prototype.Wa = function(a, b) {
        return {
            type: a,
            data: b
        }
    };
    var Ic = function(a, b, c, d) {
            return r.Promise.resolve(r.Promise.race([Fc("PAYMENT_AUTHORIZATION", c), b.onPaymentAuthorized(a)])).then(function(e) {
                return d("paymentAuthorizationResponse", e)
            }, function(e) {
                Hc("REQUEST_TIMEOUT" === e.message, 27, 2);
                return d("paymentAuthorizationResponse", Gc(e, "PAYMENT_AUTHORIZATION"))
            })
        },
        Jc = function(a, b, c, d) {
            return r.Promise.resolve(r.Promise.race([Fc(a.callbackTrigger in Ea ? Ea[a.callbackTrigger] : "UNKNOWN_INTENT", c), b.onPaymentDataChanged(a)])).then(function(e) {
                return d("paymentDataCallbackResponse",
                    e)
            }, function(e) {
                Hc("REQUEST_TIMEOUT" === e.message, 26, vc[a.callbackTrigger]);
                return d("paymentDataCallbackResponse", Gc(e, a.callbackTrigger || "UNKNOWN_INTENT"))
            })
        };
    var Lc = function() {
        var a = window.document,
            b = this;
        this.Kb = a;
        this.R = a.createElement("gpay-graypane");
        Kc(this.R, {
            "z-index": 2147483647,
            display: "none",
            position: "fixed",
            top: 0,
            right: 0,
            bottom: 0,
            left: 0,
            "background-color": "rgba(32, 33, 36, .6)"
        });
        this.Za = null;
        this.R.addEventListener("click", function() {
            if (b.Za) try {
                b.Za.focus()
            } catch (c) {}
        })
    };
    Lc.prototype.show = function(a) {
        this.Za = a || null;
        this.Kb.body.appendChild(this.R);
        Kc(this.R, {
            display: "block",
            opacity: 0
        });
        return Mc(this.R, {
            opacity: 1
        })
    };
    var Nc = function(a) {
        a.Za = null;
        a.R.parentElement && Mc(a.R, {
            opacity: 0
        }).then(function() {
            Kc(a.R, {
                display: "none"
            });
            a.Kb.body.removeChild(a.R)
        })
    };

    function Kc(a, b) {
        for (var c in b) a.style.setProperty(c, b[c].toString(), "important")
    }

    function Mc(a, b) {
        var c = a.ownerDocument.defaultView,
            d = a.style.transition || "";
        return (new r.Promise(function(e) {
            c.setTimeout(function() {
                c.setTimeout(e, 300);
                Kc(a, t(Object, "assign").call(Object, {
                    transition: "transform 300ms ease-out, opacity 300ms ease-out"
                }, b))
            })
        })).then(function() {
            Kc(a, t(Object, "assign").call(Object, {
                transition: d
            }, b))
        })
    };
    var Oc = function(a) {
        this.s = a;
        this.ob = this.pb = this.B = this.ga = null;
        this.la = 3E4
    };
    m = Oc.prototype;
    m.tb = function(a) {
        this.B = a
    };
    m.Ea = function(a) {
        this.ga = a
    };
    m.F = function(a) {
        var b = Pc(a);
        return new r.Promise(function(c) {
            (void 0 != b.hasEnrolledInstrument ? b.hasEnrolledInstrument() : b.canMakePayment()).then(function(d) {
                window.sessionStorage.setItem("google.payments.api.storage.isreadytopay.result", d.toString());
                var e = {
                    result: d
                };
                2 <= a.apiVersion && a.existingPaymentMethodRequired && (e.paymentMethodPresent = d);
                c(e)
            }).catch(function() {
                window.sessionStorage.getItem("google.payments.api.storage.isreadytopay.result") ? c({
                        result: "true" == window.sessionStorage.getItem("google.payments.api.storage.isreadytopay.result")
                    }) :
                    c({
                        result: !1
                    })
            })
        })
    };
    m.O = function(a) {
        Pc(a, this.s, a.transactionInfo.currencyCode, a.transactionInfo.totalPrice)
    };
    m.U = function(a) {
        Qc(this, a)
    };
    var Pc = function(a, b, c, d) {
            var e = {};
            a && (e = JSON.parse(JSON.stringify(a)));
            e.apiVersion || (e.apiVersion = 1);
            e.swg && (e.allowedPaymentMethods = ["CARD"]);
            b && "TEST" == b && (e.environment = b);
            return new PaymentRequest([{
                supportedMethods: ["https://google.com/pay"],
                data: e
            }], {
                total: {
                    label: "Estimated Total Price",
                    amount: {
                        currency: c || "USD",
                        value: d || "0"
                    }
                }
            })
        },
        Qc = function(a, b) {
            b = Pc(b, a.s, b.transactionInfo && b.transactionInfo.currencyCode || void 0, b.transactionInfo && b.transactionInfo.totalPrice || void 0);
            b.onpaymentmethodchange =
                function(c) {
                    var d = new Ec;
                    d = c.methodDetails.callbackTrigger ? Jc(c.methodDetails, a.B, a.la, d.Qb) : Ic(c.methodDetails, a.B, a.la, d.Qb);
                    c.updateWith(d)
                };
            a.ga(b.show().then(function(c) {
                google.payments.api.LogInternally && console.log("payment response", c);
                c.complete("success");
                return c.details.statusCode ? (google.payments.api.LogInternally && console.log("status code", c.details.statusCode), {
                    error: c.details
                }) : c.details
            }).catch(function(c) {
                google.payments.api.LogInternally && console.log("payment response with err",
                    c);
                c.statusCode = "CANCELED";
                throw c;
            }))
        };
    var Rc = ["SHIPPING_ADDRESS", "SHIPPING_OPTION"];

    function Sc(a) {
        if (2 <= a.apiVersion) {
            var b = Tc(a);
            if (b && 1 == b.length && "CRYPTOGRAM_3DS" == b[0]) return !0
        }
        return 1 == a.allowedPaymentMethods.length && "TOKENIZED_CARD" == a.allowedPaymentMethods[0]
    }

    function Uc(a, b) {
        return 2 <= a.apiVersion && (a = Tc(a)) && t(a, "includes").call(a, b) ? !0 : !1
    }

    function Vc() {
        var a = window.location.hostname,
            b = a.length - 11;
        return 0 <= b && a.indexOf(".google.com", b) == b || void 0 === window.isSecureContext ? null : window.isSecureContext ? null : "Google Pay APIs should be called in secure context!"
    }

    function Wc(a) {
        if (a.environment && !(n = t(Object, "values").call(Object, Fa), t(n, "includes")).call(n, a.environment)) throw Error("Parameter environment in PaymentsClientOptions can optionally be set to PRODUCTION, otherwise it defaults to TEST.");
    }

    function Xc(a) {
        if (!a) return "isReadyToPayRequest must be set!";
        if (Yc(a)) return "UPI not supported";
        if (2 <= a.apiVersion) {
            if (!("apiVersionMinor" in a)) return "apiVersionMinor must be set!";
            if (!a.allowedPaymentMethods || !Array.isArray(a.allowedPaymentMethods) || 0 == a.allowedPaymentMethods.length) return "for v2 allowedPaymentMethods must be set to an array containing a list of accepted payment methods";
            for (var b = 0; b < a.allowedPaymentMethods.length; b++) {
                var c = a.allowedPaymentMethods[b];
                if ("CARD" == c.type) {
                    if (!c.parameters) return "Field parameters must be setup in each allowedPaymentMethod";
                    var d = c.parameters.allowedCardNetworks;
                    if (!d || !Array.isArray(d) || 0 == d.length) return "allowedCardNetworks must be setup in parameters for type CARD";
                    c = c.parameters.allowedAuthMethods;
                    if (!c || !Array.isArray(c) || 0 == c.length || !c.every(Zc)) return "allowedAuthMethods must be setup in parameters for type 'CARD'  and must contain 'CRYPTOGRAM_3DS' and/or 'PAN_ONLY'"
                }
            }
        } else if (!a.allowedPaymentMethods || !Array.isArray(a.allowedPaymentMethods) || 0 == a.allowedPaymentMethods.length || !a.allowedPaymentMethods.every($c)) return "allowedPaymentMethods must be set to an array containing 'CARD' and/or 'TOKENIZED_CARD'!";
        return null
    }

    function $c(a) {
        return (n = t(Object, "values").call(Object, Ga), t(n, "includes")).call(n, a)
    }

    function Zc(a) {
        return (n = t(Object, "values").call(Object, Ha), t(n, "includes")).call(n, a)
    }

    function ad(a) {
        if (!a) return "paymentDataRequest must be set!";
        if (Yc(a)) return "UPI not supported";
        if (a.swg) return (a = a.swg) ? a.skuId && a.publicationId ? null : "Both skuId and publicationId must be provided" : "Swg parameters must be provided";
        if (a.transactionInfo)
            if (a.transactionInfo.currencyCode) {
                if (!a.transactionInfo.totalPriceStatus || !(n = t(Object, "values").call(Object, Ia), t(n, "includes")).call(n, a.transactionInfo.totalPriceStatus)) return "totalPriceStatus in transactionInfo must be set to one of NOT_CURRENTLY_KNOWN, ESTIMATED or FINAL!";
                if ("NOT_CURRENTLY_KNOWN" !== a.transactionInfo.totalPriceStatus && !a.transactionInfo.totalPrice) return "totalPrice in transactionInfo must be set when totalPriceStatus is ESTIMATED or FINAL!"
            } else return "currencyCode in transactionInfo must be set!";
        else return "transactionInfo must be set!";
        var b = Yc(a);
        if (b) {
            if (!b.parameters) return "parameters must be set in allowedPaymentMethod!";
            b = b.parameters;
            if (b.payeeVpa)
                if (b.payeeName)
                    if (b.referenceUrl) {
                        if (!b.mcc) return "mcc in allowedPaymentMethod parameters must be set!";
                        if (!b.transactionReferenceId) return "transactionReferenceId in allowedPaymentMethod parameters must be set!"
                    } else return "referenceUrl in allowedPaymentMethod parameters must be set!";
            else return "payeeName in allowedPaymentMethod parameters must be set!";
            else return "payeeVpa in allowedPaymentMethod parameters must be set!";
            if ("INR" !== a.transactionInfo.currencyCode) return "currencyCode in transactionInfo must be set to INR!";
            if ("FINAL" !== a.transactionInfo.totalPriceStatus) return "totalPriceStatus in transactionInfo must be set to FINAL!";
            if (!a.transactionInfo.transactionNote) return "transactionNote in transactionInfo must be set!"
        }
        return null
    }

    function Yc(a) {
        return 2 > a.apiVersion || !a.allowedPaymentMethods ? null : bd(a, "UPI")
    }

    function cd(a, b) {
        if (a.callbackIntents && !b) return "paymentDataCallbacks must be set";
        if (t(a.callbackIntents, "includes").call(a.callbackIntents, "PAYMENT_AUTHORIZATION") !== !!b.onPaymentAuthorized) return "Both PAYMENT_AUTHORIZATION intent and onPaymentAuthorized must be set";
        var c = Rc.slice();
        google.payments.api.EnableOfferCallback && c.push("OFFER");
        google.payments.api.EnablePaymentMethodCallback && c.push("PAYMENT_METHOD");
        return !!c.filter(function(d) {
            return t(a.callbackIntents, "includes").call(a.callbackIntents,
                d)
        }).length !== !!b.onPaymentDataChanged ? "onPaymentDataChanged callback must be set if any of " + (c + " callback intent is set.") : null
    }

    function Tc(a) {
        return a.allowedPaymentMethods && (a = bd(a, "CARD")) && a.parameters ? a.parameters.allowedAuthMethods : null
    }

    function bd(a, b) {
        for (var c = 0; c < a.allowedPaymentMethods.length; c++) {
            var d = a.allowedPaymentMethods[c];
            if (d.type == b) return d
        }
        return null
    };
    var ed = function(a, b) {
            var c = dd.transition;
            if (!c) {
                var d = Lb();
                c = d;
                void 0 === a.style[d] && (d = (ib ? "Webkit" : hb ? "Moz" : gb ? "ms" : null) + Mb(d), void 0 !== a.style[d] && (c = d));
                dd.transition = c
            }
            c && (a.style[c] = b)
        },
        dd = {};
    var fd = function(a, b) {
        Array.isArray(b) || (b = [b]);
        A(0 < b.length, "At least one Css3Property should be specified.");
        b = b.map(function(c) {
            if ("string" === typeof c) return c;
            Ba(c, "Expected css3 property to be an object.");
            var d = c.tc + " " + c.duration + "s " + c.timing + " " + c.delay + "s";
            A(c.tc && "number" === typeof c.duration && c.timing && "number" === typeof c.delay, "Unexpected css3 property value: %s", d);
            return d
        });
        ed(a, b.join(","))
    };
    var gd = function() {
        this.Ta = this.Ta;
        this.Ya = this.Ya
    };
    gd.prototype.Ta = !1;
    gd.prototype.dispose = function() {
        this.Ta || (this.Ta = !0, this.wa())
    };
    gd.prototype.wa = function() {
        if (this.Ya)
            for (; this.Ya.length;) this.Ya.shift()()
    };
    var Q = function(a, b) {
        this.type = a;
        this.currentTarget = this.target = b;
        this.defaultPrevented = this.Ha = !1
    };
    Q.prototype.stopPropagation = function() {
        this.Ha = !0
    };
    Q.prototype.preventDefault = function() {
        this.defaultPrevented = !0
    };
    var hd = Object.freeze || function(a) {
        return a
    };
    var id = function() {
        if (!w.addEventListener || !Object.defineProperty) return !1;
        var a = !1,
            b = Object.defineProperty({}, "passive", {
                get: function() {
                    a = !0
                }
            });
        try {
            w.addEventListener("test", na, b), w.removeEventListener("test", na, b)
        } catch (c) {}
        return a
    }();
    var R = function(a, b) {
        Q.call(this, a ? a.type : "");
        this.relatedTarget = this.currentTarget = this.target = null;
        this.button = this.screenY = this.screenX = this.clientY = this.clientX = this.offsetY = this.offsetX = 0;
        this.key = "";
        this.charCode = this.keyCode = 0;
        this.metaKey = this.shiftKey = this.altKey = this.ctrlKey = !1;
        this.state = null;
        this.pointerId = 0;
        this.pointerType = "";
        this.xa = null;
        if (a) {
            var c = this.type = a.type,
                d = a.changedTouches && a.changedTouches.length ? a.changedTouches[0] : null;
            this.target = a.target || a.srcElement;
            this.currentTarget =
                b;
            if (b = a.relatedTarget) {
                if (hb) {
                    a: {
                        try {
                            fb(b.nodeName);
                            var e = !0;
                            break a
                        } catch (g) {}
                        e = !1
                    }
                    e || (b = null)
                }
            } else "mouseover" == c ? b = a.fromElement : "mouseout" == c && (b = a.toElement);
            this.relatedTarget = b;
            d ? (this.clientX = void 0 !== d.clientX ? d.clientX : d.pageX, this.clientY = void 0 !== d.clientY ? d.clientY : d.pageY, this.screenX = d.screenX || 0, this.screenY = d.screenY || 0) : (this.offsetX = ib || void 0 !== a.offsetX ? a.offsetX : a.layerX, this.offsetY = ib || void 0 !== a.offsetY ? a.offsetY : a.layerY, this.clientX = void 0 !== a.clientX ? a.clientX : a.pageX,
                this.clientY = void 0 !== a.clientY ? a.clientY : a.pageY, this.screenX = a.screenX || 0, this.screenY = a.screenY || 0);
            this.button = a.button;
            this.keyCode = a.keyCode || 0;
            this.key = a.key || "";
            this.charCode = a.charCode || ("keypress" == c ? a.keyCode : 0);
            this.ctrlKey = a.ctrlKey;
            this.altKey = a.altKey;
            this.shiftKey = a.shiftKey;
            this.metaKey = a.metaKey;
            this.pointerId = a.pointerId || 0;
            this.pointerType = "string" === typeof a.pointerType ? a.pointerType : jd[a.pointerType] || "";
            this.state = a.state;
            this.xa = a;
            a.defaultPrevented && R.Ka.preventDefault.call(this)
        }
    };
    ta(R, Q);
    var jd = hd({
        2: "touch",
        3: "pen",
        4: "mouse"
    });
    R.prototype.stopPropagation = function() {
        R.Ka.stopPropagation.call(this);
        this.xa.stopPropagation ? this.xa.stopPropagation() : this.xa.cancelBubble = !0
    };
    R.prototype.preventDefault = function() {
        R.Ka.preventDefault.call(this);
        var a = this.xa;
        a.preventDefault ? a.preventDefault() : a.returnValue = !1
    };
    var kd = "closure_listenable_" + (1E6 * Math.random() | 0);
    var ld = 0;
    var md = function(a, b, c, d, e) {
            this.listener = a;
            this.proxy = null;
            this.src = b;
            this.type = c;
            this.capture = !!d;
            this.Ua = e;
            this.key = ++ld;
            this.Ia = this.Ra = !1
        },
        nd = function(a) {
            a.Ia = !0;
            a.listener = null;
            a.proxy = null;
            a.src = null;
            a.Ua = null
        };
    var T = function(a) {
        this.src = a;
        this.v = {};
        this.Na = 0
    };
    T.prototype.add = function(a, b, c, d, e) {
        var g = a.toString();
        a = this.v[g];
        a || (a = this.v[g] = [], this.Na++);
        var f = od(a, b, d, e); - 1 < f ? (b = a[f], c || (b.Ra = !1)) : (b = new md(b, this.src, g, !!d, e), b.Ra = c, a.push(b));
        return b
    };
    T.prototype.remove = function(a, b, c, d) {
        a = a.toString();
        if (!(a in this.v)) return !1;
        var e = this.v[a];
        b = od(e, b, c, d);
        return -1 < b ? (nd(e[b]), A(null != e.length), Array.prototype.splice.call(e, b, 1), 0 == e.length && (delete this.v[a], this.Na--), !0) : !1
    };
    var pd = function(a, b) {
        var c = b.type;
        if (c in a.v) {
            var d = a.v[c],
                e = Xa(d, b),
                g;
            if (g = 0 <= e) A(null != d.length), Array.prototype.splice.call(d, e, 1);
            g && (nd(b), 0 == a.v[c].length && (delete a.v[c], a.Na--))
        }
    };
    T.prototype.ib = function(a, b, c, d) {
        a = this.v[a.toString()];
        var e = -1;
        a && (e = od(a, b, c, d));
        return -1 < e ? a[e] : null
    };
    T.prototype.hasListener = function(a, b) {
        var c = void 0 !== a,
            d = c ? a.toString() : "",
            e = void 0 !== b;
        return jb(this.v, function(g) {
            for (var f = 0; f < g.length; ++f)
                if (!(c && g[f].type != d || e && g[f].capture != b)) return !0;
            return !1
        })
    };
    var od = function(a, b, c, d) {
        for (var e = 0; e < a.length; ++e) {
            var g = a[e];
            if (!g.Ia && g.listener == b && g.capture == !!c && g.Ua == d) return e
        }
        return -1
    };
    var qd = "closure_lm_" + (1E6 * Math.random() | 0),
        rd = {},
        sd = 0,
        ud = function(a, b, c, d, e) {
            if (d && d.once) td(a, b, c, d, e);
            else if (Array.isArray(b))
                for (var g = 0; g < b.length; g++) ud(a, b[g], c, d, e);
            else c = vd(c), a && a[kd] ? (d = pa(d) ? !!d.capture : !!d, wd(a), a.K.add(String(b), c, !1, d, e)) : xd(a, b, c, !1, d, e)
        },
        xd = function(a, b, c, d, e, g) {
            if (!b) throw Error("Invalid event type");
            var f = pa(e) ? !!e.capture : !!e,
                h = yd(a);
            h || (a[qd] = h = new T(a));
            c = h.add(b, c, d, f, g);
            if (!c.proxy) {
                d = zd();
                c.proxy = d;
                d.src = a;
                d.listener = c;
                if (a.addEventListener) id || (e = f), void 0 ===
                    e && (e = !1), a.addEventListener(b.toString(), d, e);
                else if (a.attachEvent) a.attachEvent(Ad(b.toString()), d);
                else if (a.addListener && a.removeListener) A("change" === b, "MediaQueryList only has a change event"), a.addListener(d);
                else throw Error("addEventListener and attachEvent are unavailable.");
                sd++
            }
        },
        zd = function() {
            var a = Bd,
                b = function(c) {
                    return a.call(b.src, b.listener, c)
                };
            return b
        },
        td = function(a, b, c, d, e) {
            if (Array.isArray(b))
                for (var g = 0; g < b.length; g++) td(a, b[g], c, d, e);
            else c = vd(c), a && a[kd] ? a.K.add(String(b),
                c, !0, pa(d) ? !!d.capture : !!d, e) : xd(a, b, c, !0, d, e)
        },
        Cd = function(a, b, c, d, e) {
            if (Array.isArray(b))
                for (var g = 0; g < b.length; g++) Cd(a, b[g], c, d, e);
            else d = pa(d) ? !!d.capture : !!d, c = vd(c), a && a[kd] ? a.K.remove(String(b), c, d, e) : a && (a = yd(a)) && (b = a.ib(b, c, d, e)) && Dd(b)
        },
        Dd = function(a) {
            if ("number" !== typeof a && a && !a.Ia) {
                var b = a.src;
                if (b && b[kd]) pd(b.K, a);
                else {
                    var c = a.type,
                        d = a.proxy;
                    b.removeEventListener ? b.removeEventListener(c, d, a.capture) : b.detachEvent ? b.detachEvent(Ad(c), d) : b.addListener && b.removeListener && b.removeListener(d);
                    sd--;
                    (c = yd(b)) ? (pd(c, a), 0 == c.Na && (c.src = null, b[qd] = null)) : nd(a)
                }
            }
        },
        Ad = function(a) {
            return a in rd ? rd[a] : rd[a] = "on" + a
        },
        Bd = function(a, b) {
            if (a.Ia) a = !0;
            else {
                b = new R(b, this);
                var c = a.listener,
                    d = a.Ua || a.src;
                a.Ra && Dd(a);
                a = c.call(d, b)
            }
            return a
        },
        yd = function(a) {
            a = a[qd];
            return a instanceof T ? a : null
        },
        Ed = "__closure_events_fn_" + (1E9 * Math.random() >>> 0),
        vd = function(a) {
            A(a, "Listener can not be null.");
            if ("function" === typeof a) return a;
            A(a.handleEvent, "An object listener must have handleEvent method.");
            a[Ed] || (a[Ed] =
                function(b) {
                    return a.handleEvent(b)
                });
            return a[Ed]
        };
    var U = function() {
        gd.call(this);
        this.K = new T(this);
        this.dc = this;
        this.nb = null
    };
    ta(U, gd);
    U.prototype[kd] = !0;
    U.prototype.addEventListener = function(a, b, c, d) {
        ud(this, a, b, c, d)
    };
    U.prototype.removeEventListener = function(a, b, c, d) {
        Cd(this, a, b, c, d)
    };
    U.prototype.dispatchEvent = function(a) {
        wd(this);
        var b = this.nb;
        if (b) {
            var c = [];
            for (var d = 1; b; b = b.nb) c.push(b), A(1E3 > ++d, "infinite loop")
        }
        b = this.dc;
        d = a.type || a;
        if ("string" === typeof a) a = new Q(a, b);
        else if (a instanceof Q) a.target = a.target || b;
        else {
            var e = a;
            a = new Q(d, b);
            lb(a, e)
        }
        e = !0;
        if (c)
            for (var g = c.length - 1; !a.Ha && 0 <= g; g--) {
                var f = a.currentTarget = c[g];
                e = Fd(f, d, !0, a) && e
            }
        a.Ha || (f = a.currentTarget = b, e = Fd(f, d, !0, a) && e, a.Ha || (e = Fd(f, d, !1, a) && e));
        if (c)
            for (g = 0; !a.Ha && g < c.length; g++) f = a.currentTarget = c[g], e = Fd(f, d, !1, a) && e;
        return e
    };
    U.prototype.wa = function() {
        U.Ka.wa.call(this);
        if (this.K) {
            var a = this.K,
                b = 0,
                c;
            for (c in a.v) {
                for (var d = a.v[c], e = 0; e < d.length; e++) ++b, nd(d[e]);
                delete a.v[c];
                a.Na--
            }
        }
        this.nb = null
    };
    var Fd = function(a, b, c, d) {
        b = a.K.v[String(b)];
        if (!b) return !0;
        b = b.concat();
        for (var e = !0, g = 0; g < b.length; ++g) {
            var f = b[g];
            if (f && !f.Ia && f.capture == c) {
                var h = f.listener,
                    k = f.Ua || f.src;
                f.Ra && pd(a.K, f);
                e = !1 !== h.call(k, d) && e
            }
        }
        return e && !d.defaultPrevented
    };
    U.prototype.ib = function(a, b, c, d) {
        return this.K.ib(String(a), b, c, d)
    };
    U.prototype.hasListener = function(a, b) {
        return this.K.hasListener(void 0 !== a ? String(a) : void 0, b)
    };
    var wd = function(a) {
        A(a.K, "Event target is not initialized. Did you call the superclass (goog.events.EventTarget) constructor?")
    };
    var Gd = function(a, b) {
        U.call(this);
        this.Va = a || 1;
        this.Ma = b || w;
        this.Hb = sa(this.Dc, this);
        this.Ob = Date.now()
    };
    ta(Gd, U);
    m = Gd.prototype;
    m.enabled = !1;
    m.L = null;
    m.setInterval = function(a) {
        this.Va = a;
        this.L && this.enabled ? (this.stop(), this.start()) : this.L && this.stop()
    };
    m.Dc = function() {
        if (this.enabled) {
            var a = Date.now() - this.Ob;
            0 < a && a < .8 * this.Va ? this.L = this.Ma.setTimeout(this.Hb, this.Va - a) : (this.L && (this.Ma.clearTimeout(this.L), this.L = null), this.dispatchEvent("tick"), this.enabled && (this.stop(), this.start()))
        }
    };
    m.start = function() {
        this.enabled = !0;
        this.L || (this.L = this.Ma.setTimeout(this.Hb, this.Va), this.Ob = Date.now())
    };
    m.stop = function() {
        this.enabled = !1;
        this.L && (this.Ma.clearTimeout(this.L), this.L = null)
    };
    m.wa = function() {
        Gd.Ka.wa.call(this);
        this.stop();
        delete this.Ma
    };
    /*

     Copyright 2017 The Web Activities Authors. All Rights Reserved.

     Licensed under the Apache License, Version 2.0 (the "License");
     you may not use this file except in compliance with the License.
     You may obtain a copy of the License at

          http://www.apache.org/licenses/LICENSE-2.0

     Unless required by applicable law or agreed to in writing, software
     distributed under the License is distributed on an "AS-IS" BASIS,
     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     See the License for the specific language governing permissions and
     limitations under the License.
    */
    var Hd = function(a, b, c, d, e, g) {
        this.code = a;
        this.data = "ok" == a ? b : null;
        this.mode = c;
        this.origin = d;
        this.mb = e;
        this.zc = g;
        this.ok = "ok" == a;
        this.error = "failed" == a ? Error(String(b) || "") : null
    };

    function Id(a) {
        var b = a.indexOf("#");
        return -1 == b ? a : a.substring(0, b)
    }

    function Jd(a) {
        return a ? (/^[?#]/.test(a) ? a.slice(1) : a).split("&").reduce(function(b, c) {
            var d = c.split("=");
            c = decodeURIComponent(d[0] || "");
            d = decodeURIComponent(d[1] || "");
            c && (b[c] = d);
            return b
        }, {}) : {}
    }

    function Kd(a) {
        var b = {
            requestId: a.requestId,
            returnUrl: a.Xb,
            args: a.ec
        };
        void 0 !== a.origin && (b.origin = a.origin);
        void 0 !== a.mb && (b.originVerified = a.mb);
        return JSON.stringify(b)
    }

    function Ld(a, b, c) {
        if (b.ok) c(b);
        else {
            var d;
            if (!(d = b.error)) {
                d = null;
                if ("function" == typeof a.DOMException) {
                    a = a.DOMException;
                    try {
                        d = new a("AbortError", "AbortError")
                    } catch (e) {}
                }
                d || (d = Error("AbortError"), d.name = "AbortError", d.code = 20)
            }
            a = d;
            a.md = b;
            c(r.Promise.reject(a))
        }
    }

    function Md(a) {
        a = a.navigator;
        return /Trident|MSIE|IEMobile/i.test(a && a.userAgent)
    }

    function Nd(a) {
        setTimeout(function() {
            throw a;
        })
    }
    var V = function(a, b, c) {
        this.g = a;
        this.Ab = b;
        this.C = c;
        this.vc = !0;
        this.Bb = null;
        this.Cb = !1;
        this.Y = this.Xa = this.Z = this.j = null;
        this.Gb = this.mc.bind(this)
    };
    V.prototype.connect = function(a) {
        if (this.Z) throw Error("already connected");
        this.Z = a;
        this.g.addEventListener("message", this.Gb)
    };
    V.prototype.disconnect = function() {
        if (this.Z && (this.Z = null, this.j && (Od(this.j), this.j = null), this.g.removeEventListener("message", this.Gb), this.Y)) {
            for (var a in this.Y) {
                var b = this.Y[a];
                b.port1 && Od(b.port1);
                b.port2 && Od(b.port2)
            }
            this.Y = null
        }
    };
    V.prototype.isConnected = function() {
        return null != this.C
    };
    var Pd = function(a) {
            a.Z && !a.Bb && (a.Bb = "function" == typeof a.Ab ? a.Ab() : a.Ab);
            return a.Bb
        },
        Qd = function(a) {
            if (null == a.C) throw Error("not connected");
            return a.C
        },
        Td = function(a, b) {
            var c = null;
            a.Cb && "function" == typeof a.g.MessageChannel && (c = new a.g.MessageChannel);
            c ? (Rd(a, "start", b, [c.port2]), Sd(a, c.port1)) : Rd(a, "start", b)
        },
        Rd = function(a, b, c, d) {
            c = {
                sentinel: "__ACTIVITIES__",
                cmd: b,
                payload: c || null
            };
            if (a.j) a.j.postMessage(c, d || void 0);
            else {
                var e = Pd(a);
                if (!e) throw Error("not connected");
                a = "connect" == b ? null != a.C ?
                    a.C : "*" : Qd(a);
                e.postMessage(c, a, d || void 0)
            }
        };
    V.prototype.customMessage = function(a) {
        Rd(this, "msg", a)
    };
    var Ud = function(a, b) {
            a.Y || (a.Y = {});
            var c = a.Y[b];
            if (!c) {
                var d;
                c = new r.Promise(function(e) {
                    d = e
                });
                c = {
                    port1: null,
                    port2: null,
                    Wb: d,
                    promise: c
                };
                a.Y[b] = c
            }
            return c
        },
        Sd = function(a, b) {
            a.j && Od(a.j);
            a.j = b;
            a.j.onmessage = function(c) {
                var d = c.data,
                    e = d && d.cmd;
                d = d && d.payload || null;
                e && a.qa(e, d, c)
            }
        };
    V.prototype.mc = function(a) {
        if (!this.vc || Pd(this) == a.source) {
            var b = a.data;
            if (b && "__ACTIVITIES__" == b.sentinel) {
                var c = b.cmd;
                if (!this.j || "connect" == c || "start" == c) {
                    var d = a.origin;
                    b = b.payload || null;
                    null == this.C && "start" == c && (this.C = d);
                    null == this.C && a.source && Pd(this) == a.source && (this.C = d);
                    d == this.C && this.qa(c, b, a)
                }
            }
        }
    };
    V.prototype.qa = function(a, b, c) {
        "connect" == a ? (this.j && (Od(this.j), this.j = null), this.Cb = b && b.acceptsChannel || !1, this.Z(a, b)) : "start" == a ? ((c = c.ports && c.ports[0]) && Sd(this, c), this.Z(a, b)) : "msg" == a ? null != this.Xa && null != b && this.Xa(b) : "cnget" == a ? (b = b.name || "", a = Ud(this, b), a.port1 || (c = new this.g.MessageChannel, a.port1 = c.port1, a.port2 = c.port2, a.Wb(a.port1)), a.port2 && (Rd(this, "cnset", {
            name: b
        }, [a.port2]), a.port2 = null)) : "cnset" == a ? (a = c.ports[0], b = Ud(this, b.name), b.port1 = a, b.Wb(a)) : this.Z(a, b)
    };

    function Od(a) {
        try {
            a.close()
        } catch (b) {}
    }
    var Vd = function(a, b, c) {
        var d = this;
        this.Ba = a;
        this.bb = b;
        this.Pa = c || null;
        this.g = this.Ba.ownerDocument.defaultView;
        this.C = Sb(qb(b).toString());
        this.va = null;
        this.fb = new r.Promise(function(e) {
            d.va = e
        });
        this.$a = null;
        new r.Promise(function(e) {
            d.$a = e
        });
        this.J = null;
        this.ab = new r.Promise(function(e) {
            d.J = e
        });
        this.Vb = this.Rb = null;
        this.m = new V(this.g, function() {
            return d.Ba.contentWindow
        }, this.C)
    };
    m = Vd.prototype;
    m.connect = function() {
        var a = this.Ba;
        if ("isConnected" in a) a = a.isConnected;
        else {
            var b = a.ownerDocument && a.ownerDocument.documentElement;
            a = b && b.contains(a) || !1
        }
        if (!a) throw Error("iframe must be in DOM");
        this.m.connect(this.qa.bind(this));
        a = this.Ba;
        b = this.bb;
        a: {
            try {
                var c = a && a.ownerDocument,
                    d = c && (c.defaultView || c.parentWindow);
                d = d || w;
                if (d.Element && d.Location) {
                    var e = d;
                    break a
                }
            } catch (f) {}
            e = null
        }
        if (e && "undefined" != typeof e.HTMLIFrameElement && (!a || !(a instanceof e.HTMLIFrameElement) && (a instanceof e.Location ||
                a instanceof e.Element))) {
            if (pa(a)) try {
                var g = a.constructor.displayName || a.constructor.name || Object.prototype.toString.call(a)
            } catch (f) {
                g = "<object could not be stringified>"
            } else g = void 0 === a ? "undefined" : null === a ? "null" : typeof a;
            ya("Argument is not a %s (or a non-Element, non-Location mock); got: %s", "HTMLIFrameElement", g)
        }
        a.src = qb(b).toString();
        return this.fb
    };
    m.disconnect = function() {
        this.m.disconnect()
    };
    m.Oa = function() {
        return this.ab
    };
    m.jb = function() {
        return this.Ba.contentWindow || null
    };
    m.message = function(a) {
        this.m.customMessage(a)
    };
    m.onMessage = function(a) {
        this.m.Xa = a
    };
    m.qa = function(a, b) {
        "connect" == a ? (Td(this.m, this.Pa), this.va()) : "result" == a ? this.J && (a = b.code, b = new Hd(a, "failed" == a ? Error(b.data || "") : b.data, "iframe", Qd(this.m), !0, !0), Ld(this.g, b, this.J), this.J = null, Rd(this.m, "close"), this.disconnect()) : "ready" == a ? this.$a && (this.$a(), this.$a = null) : "resize" == a && (this.Vb = b.height, this.Rb && this.Rb(this.Vb))
    };
    var Wd = function(a, b, c, d, e, g) {
        var f = this,
            h = d && C(d);
        if (!h || "_blank" != h && "_top" != h && "_" == h[0]) throw Error('The only allowed targets are "_blank", "_top" and name targets');
        this.g = a;
        this.uc = b;
        this.bb = c;
        this.rc = d;
        this.Pa = e || null;
        this.ka = g || {};
        this.va = null;
        this.fb = new r.Promise(function(k) {
            f.va = k
        });
        this.J = null;
        this.ab = new r.Promise(function(k) {
            f.J = k
        });
        this.m = this.T = this.ba = null
    };
    m = Wd.prototype;
    m.open = function() {
        return Xd(this)
    };
    m.disconnect = function() {
        this.T && (this.T.stop(), this.T = null);
        this.m && (this.m.disconnect(), this.m = null);
        if (this.ba) {
            try {
                this.ba.close()
            } catch (a) {}
            this.ba = null
        }
        this.J = null
    };
    m.jb = function() {
        return this.ba
    };
    m.Oa = function() {
        return this.ab
    };
    m.message = function(a) {
        this.m.customMessage(a)
    };
    m.onMessage = function(a) {
        this.m.Xa = a
    };
    var Xd = function(a) {
            var b = Yd(a),
                c = a.bb;
            if (!a.ka.pd) {
                var d = Kd({
                    requestId: a.uc,
                    Xb: a.ka.Xb || Id(a.g.location.href),
                    ec: a.Pa
                });
                c = c + (-1 == c.indexOf("#") ? "#" : "&") + encodeURIComponent("__WA__") + "=" + encodeURIComponent(d)
            }
            d = a.rc;
            "_top" != C(d) && Md(a.g) && (d = D("_top"));
            try {
                var e = Kb(c, a.g, d, b)
            } catch (g) {}
            if (!e && "_top" != C(d) && !a.ka.od) {
                d = D("_top");
                try {
                    e = Kb(c, a.g, d)
                } catch (g) {}
            }
            e ? (a.ba = e, "_top" != C(d) && Zd(a)) : $d(a, Error("failed to open window"));
            return a.ab.catch(function() {})
        },
        Yd = function(a) {
            var b = a.g.screen,
                c = b.availWidth ||
                b.width,
                d = b.availHeight || b.height,
                e = a.g == a.g.top;
            var g = a.g.navigator;
            g = /Edge/i.test(g && g.userAgent);
            c = Math.max(c - (e && a.g.outerWidth > a.g.innerWidth ? Math.min(100, a.g.outerWidth - a.g.innerWidth) : g ? 100 : 0), .5 * c);
            var f = Math.max(d - (e && a.g.outerHeight > a.g.innerHeight ? Math.min(100, a.g.outerHeight - a.g.innerHeight) : g ? 100 : 0), .5 * d);
            d = Math.floor(Math.min(600, .9 * c));
            e = Math.floor(Math.min(600, .9 * f));
            a.ka.width && (d = Math.min(a.ka.width, c));
            a.ka.height && (e = Math.min(a.ka.height, f));
            a = Math.floor((b.width - d) / 2);
            b = Math.floor((b.height -
                e) / 2);
            c = {
                height: e,
                width: d,
                resizable: "yes",
                scrollbars: "yes"
            };
            g || (c.left = a, c.top = b);
            g = "";
            for (var h in c) g && (g += ","), g += h + "=" + c[h];
            return g
        },
        Zd = function(a) {
            a.T = new Gd(500);
            a.T.addEventListener("tick", function() {
                ae(a, !0)
            });
            a.T.start();
            a.m = new V(a.g, a.ba, null);
            a.m.connect(a.qa.bind(a))
        },
        ae = function(a, b) {
            if (!a.ba || a.ba.closed) a.T && (a.T.stop(), a.T = null), a.g.setTimeout(function() {
                try {
                    a.$("canceled", null)
                } catch (c) {
                    $d(a, c)
                }
            }, b ? 3E3 : 0)
        },
        $d = function(a, b) {
            a.J && a.J(r.Promise.reject(b));
            a.disconnect()
        };
    Wd.prototype.$ = function(a, b) {
        if (this.J) {
            var c = this.m.isConnected();
            a = new Hd(a, b, "popup", c ? Qd(this.m) : Sb(this.bb), c, c);
            Ld(this.g, a, this.J);
            this.J = null
        }
        this.m && Rd(this.m, "close");
        this.disconnect()
    };
    Wd.prototype.qa = function(a, b) {
        var c = this;
        "connect" == a ? (Td(this.m, this.Pa), this.va()) : "result" == a ? (a = b.code, this.$(a, "failed" == a ? Error(b.data || "") : b.data)) : "check" == a && this.g.setTimeout(function() {
            return ae(c)
        }, 200)
    };
    var be = function(a, b, c, d, e) {
        this.g = a;
        this.ic = b;
        this.ha = c;
        this.C = d;
        this.Cc = e
    };
    be.prototype.Oa = function() {
        var a = this,
            b = new Hd(this.ic, this.ha, "redirect", this.C, this.Cc, !1);
        return new r.Promise(function(c) {
            Ld(a.g, b, c)
        })
    };
    var ce = function() {
            var a = window,
                b = this;
            this.version = "1.23";
            this.g = a;
            this.M = a.location.hash;
            this.vb = {};
            this.wb = {};
            this.Tb = null;
            new r.Promise(function(c) {
                b.Tb = c
            })
        },
        de = function(a, b, c) {
            var d = new Vd(a, b, c);
            return d.connect().then(function() {
                return d
            })
        };
    ce.prototype.open = function(a, b, c, d, e) {
        return {
            qd: ee(this, a, b, c, d, e).jb()
        }
    };
    var fe = function(a, b, c, d, e) {
        var g = ee(a, "GPAY", b, c, d, e);
        return g.fb.then(function() {
            return g
        })
    };
    ce.prototype.Ea = function(a, b) {
        var c = this.vb[a];
        c || (c = [], this.vb[a] = c);
        c.push(b);
        c = this.wb[a];
        if (!c && this.M) {
            try {
                var d = this.g,
                    e = Jd(this.M).__WA_RES__;
                if (e) {
                    var g = JSON.parse(e);
                    if (g && g.requestId == a) {
                        var f = d.location.hash;
                        if (f) {
                            var h = encodeURIComponent("__WA_RES__") + "=";
                            e = -1;
                            do
                                if (e = f.indexOf(h, e), -1 != e) {
                                    var k = 0 < e ? f.substring(e - 1, e) : "";
                                    if ("" == k || "?" == k || "#" == k || "&" == k) {
                                        var l = f.indexOf("&", e + 1); - 1 == l && (l = f.length);
                                        f = f.substring(0, e) + f.substring(l + 1)
                                    } else e++
                                }
                            while (-1 != e && e < f.length)
                        }
                        var q = f;
                        q = q || "";
                        if (q !=
                            d.location.hash && d.history && d.history.replaceState) try {
                            d.history.replaceState(d.history.state, "", q)
                        } catch (S) {}
                        var x = g.code,
                            y = g.data,
                            G = g.origin,
                            ia = d.document.referrer && Sb(d.document.referrer);
                        c = new be(d, x, y, G, G == ia)
                    } else c = null
                } else c = null
            } catch (S) {
                Nd(S), this.Tb(S)
            }
            c && (this.wb[a] = c)
        }(a = c) && ge(a, b)
    };
    var ee = function(a, b, c, d, e, g) {
            var f = new Wd(a.g, b, c, d, e, g);
            f.open().then(function() {
                he(a, b, f)
            });
            return f
        },
        ge = function(a, b) {
            r.Promise.resolve().then(function() {
                b(a)
            })
        },
        he = function(a, b, c) {
            var d = a.vb[b];
            d && d.forEach(function(e) {
                ge(c, e)
            });
            a.wb[b] = c
        };
    var W = function(a, b, c, d) {
        this.s = a;
        this.cb = b || !1;
        this.Db = c || new ce;
        this.Mb = new Lc;
        this.Ga = this.ga = null;
        this.yb = !1;
        this.Jb = this.j = null;
        this.Ub = d || null;
        this.ob = this.pb = this.B = this.Ja = null;
        this.la = 3E4;
        this.cb && (Ra("\n.google-payments-dialog {\n    animation: none 0s ease 0s 1 normal none running;\n    background: none 0 0 / auto repeat scroll padding-box border-box #fff;\n    background-blend-mode: normal;\n    border: 0 none #333;\n    border-radius: 8px 8px 0 0;\n    border-collapse: separate;\n    bottom: 0;\n    box-shadow: #808080 0 3px 0 0, #808080 0 0 22px;\n    box-sizing: border-box;\n    letter-spacing: normal;\n    max-height: 100%;\n    overflow: visible;\n    position: fixed;\n    width: 100%;\n    z-index: 2147483647;\n    -webkit-appearance: none;\n    left: 0;\n}\n@media (min-width: 480px) {\n  .google-payments-dialog {\n    width: 480px !important;\n    left: -240px !important;\n    margin-left: calc(100vw - 100vw / 2) !important;\n  }\n}\n.google-payments-dialogContainer {\n  background-color: rgba(0,0,0,0.26);\n  bottom: 0;\n  height: 100%;\n  left: 0;\n  position: absolute;\n  right: 0;\n}\n.iframeContainer {\n  -webkit-overflow-scrolling: touch;\n}\n"),
            Ra("\n.google-payments-dialogCenter {\n  animation: none 0s ease 0s 1 normal none running;\n  background-blend-mode: normal;\n  background: none 0 0 / auto repeat scroll padding-box border-box #fff;\n  border-collapse: separate;\n  border-radius: 8px;\n  border: 0px none #333;\n  bottom: auto;\n  box-shadow: #808080 0 0 22px;\n  box-sizing: border-box;\n  left: -240px;\n  letter-spacing: normal;\n  margin-left: calc(100vw - 100vw / 2) !important;\n  max-height: 90%;\n  overflow: visible;\n  position: absolute;\n  top: 100%;\n  transform: scale(0.8);\n  width: 480px;\n  z-index: 2147483647;\n  -webkit-appearance: none;\n}\n@media (min-height: 667px) {\n  .google-payments-dialogCenter {\n    max-height: 600px;\n  }\n}\n.google-payments-activeContainer {\n  top: 50%;\n  transform: scale(1.0) translateY(-50%);\n}\n"))
    };
    W.prototype.Ea = function(a) {
        this.ga || (this.ga = a, this.Db.Ea("GPAY", this.qc.bind(this)))
    };
    W.prototype.qc = function(a) {
        var b = this;
        Nc(this.Mb);
        this.ga(a.Oa().then(function(c) {
            if ("TIN" != b.s && c.origin != ie(b)) throw Error("channel mismatch");
            var d = c.data;
            if (d.redirectEncryptedCallbackData) return O = 3, je(b, d.redirectEncryptedCallbackData).then(function(e) {
                var g = t(Object, "assign").call(Object, {}, d);
                delete g.redirectEncryptedCallbackData;
                return t(Object, "assign").call(Object, g, e)
            });
            if (!c.mb || !c.zc) throw Error("channel mismatch");
            return d
        }, function(c) {
            var d = c.message;
            c = c.message;
            try {
                c = JSON.parse(d.substring(7))
            } catch (e) {}
            c.statusCode &&
                -1 == ["DEVELOPER_ERROR", "MERCHANT_ACCOUNT_ERROR"].indexOf(c.statusCode) && (c = {
                    statusCode: "CANCELED"
                });
            "AbortError" == c && (c = {
                statusCode: "CANCELED"
            });
            return r.Promise.reject(c)
        }))
    };
    var je = function(a, b) {
        return new r.Promise(function(c, d) {
            var e = ke(a),
                g = new XMLHttpRequest;
            g.open("POST", e, !0);
            "withCredentials" in g && (g.withCredentials = !0);
            g.onreadystatechange = function() {
                if (!(2 > g.readyState))
                    if (100 > g.status || 599 < g.status) g.onreadystatechange = null, d(Error("Unknown HTTP status " + g.status));
                    else if (4 == g.readyState) try {
                    c(JSON.parse(g.responseText))
                } catch (f) {
                    d(f)
                }
            };
            g.onerror = function() {
                d(Error("Network failure"))
            };
            g.onabort = function() {
                d(Error("Request aborted"))
            };
            g.send(b)
        })
    };
    W.prototype.F = function(a) {
        var b = this;
        return new r.Promise(function(c, d) {
            if (Sc(a)) c({
                result: !1
            });
            else {
                var e = window.navigator.userAgent,
                    g = 0 < e.indexOf("OPA/") && 0 < e.indexOf("AppleWebKit"),
                    f = 0 < e.indexOf("FxiOS"),
                    h = 0 < e.indexOf("Instagram"),
                    k = 0 < e.indexOf("FB_IAB"),
                    l = 0 < e.indexOf("AndroidMapsWebView");
                if ((0 < e.indexOf("GSA/") && 0 < e.indexOf("Safari") || g || f || h || k || l) && !b.cb) c({
                    result: !1
                });
                else {
                    f = !1;
                    if (google.payments.api.ReadyToPayAdditionalBrowsers) {
                        if (0 < e.indexOf("UCMini")) {
                            c({
                                result: !1
                            });
                            return
                        }
                        f = 0 < e.indexOf("OPT") ||
                            0 < e.indexOf("UCBrowser")
                    }
                    var q = 0 < e.indexOf("Chrome") || 0 < e.indexOf("Firefox") || 0 < e.indexOf("Safari") || f || g;
                    q && 2 <= a.apiVersion && a.existingPaymentMethodRequired ? (a.environment = b.s, Bc(a, 6, ["isReadyToPayResponse", "isReadyToPayError"], function(x) {
                        var y = {
                            result: q
                        };
                        a.existingPaymentMethodRequired && (x.data.isReadyToPayError ? d({
                            statusCode: "DEVELOPER_ERROR",
                            statusMessage: "Ready to pay error. Cause : " + x.data.isReadyToPayError
                        }) : y.paymentMethodPresent = "READY_TO_PAY" == x.data.isReadyToPayResponse);
                        c(y)
                    })) : c({
                        result: q
                    })
                }
            }
        })
    };
    W.prototype.O = function(a) {
        if (this.cb) {
            this.ua(a);
            var b = le(this, a),
                c = me(this, b.container, b.iframe, a);
            this.Ga = {
                container: b.container,
                iframe: b.iframe,
                request: a,
                dataPromise: c
            }
        }
    };
    W.prototype.U = function(a) {
        var b = this;
        a.swg || a.apiVersion || (a.apiVersion = 1);
        if (a.forceRedirect && this.B) throw Error("Callback is not supported in redirect mode");
        a.environment = this.s;
        this.ua(a);
        if (this.cb) {
            O = 1;
            if (this.Ga) {
                var c = this.Ga;
                var d = this.Ga.dataPromise;
                this.Ga = null
            } else c = le(this, a), d = me(this, c.container, c.iframe, a);
            ne(this, c.container, c.iframe, a);
            history.pushState({}, "", window.location.href);
            var e = function(g) {
                g.preventDefault();
                g = c;
                g.container.parentNode && (b.Jb(r.Promise.reject({
                        errorCode: "CANCELED"
                    })),
                    oe(g.container, g.iframe), b.j && b.j.disconnect());
                window.removeEventListener("popstate", e)
            };
            window.addEventListener("popstate", e);
            a = new r.Promise(function(g) {
                b.Jb = g
            });
            this.ga(r.Promise.race([d, a]))
        } else return O = a.forceRedirect ? 3 : 2, fe(this.Db, "TIN" == this.s ? "/ui/pay" : ie(this) + "/gp/p/ui/pay", a.forceRedirect ? D("_top") : D("gp-js-popup"), a, pe(a)).then(function(g) {
            var f = new Ec;
            b.Mb.show(g && g.jb());
            g.onMessage(function(h) {
                "partialPaymentDataCallback" == h.type ? b.pb = Jc(h.data, b.B, b.la, f.Wa).then(function(k) {
                        return g.message(k)
                    }) :
                    "fullPaymentDataCallback" == h.type && (b.ob = Ic(h.data, b.B, b.la, f.Wa).then(function(k) {
                        g.message(k)
                    }))
            })
        })
    };
    var pe = function(a) {
        var b = {
            width: 600,
            height: 600
        };
        a.forceRedirect || a.swg || (b.disableRedirectFallback = !0);
        return b
    };
    W.prototype.tb = function(a) {
        this.B = a
    };
    var ie = function(a) {
            return "LOCAL" == a.s ? "" : "https://" + ("PREPROD" == a.s ? "pay-preprod.sandbox" : "SANDBOX" == a.s ? "pay.sandbox" : "CANARY" == a.s ? "ibfe-canary.corp" : "pay") + ".google.com"
        },
        ke = function(a) {
            var b = ie(a) + "/gp/p/apis/buyflow/process";
            a.Ub && (b += "?rk=" + encodeURIComponent(a.Ub));
            return b
        },
        qe = function(a, b) {
            var c = window.location.origin,
                d = D("https://pay.google.com/gp/p/ui/pay?origin=%{origin}&coordination_token=%{coordinationToken}");
            if ("CANARY" == a) d = D("https://ibfe-canary.corp.google.com/gp/p/ui/pay?origin=%{origin}&coordination_token=%{coordinationToken}");
            else if ("SANDBOX" == a || "PREPROD" == a) d = D("https://pay" + ("PREPROD" == a ? "-preprod" : "") + ".sandbox.google.com/gp/p/ui/pay?origin=%{origin}&coordination_token=%{coordinationToken}");
            return ub(d, {
                coordinationToken: void 0 === b ? "" : b,
                origin: c
            })
        },
        oe = function(a, b) {
            re(b, "all 250ms ease 0s");
            b.height = "0px";
            setTimeout(function() {
                a.parentNode && a.parentNode.removeChild(a)
            }, 250)
        },
        le = function(a, b) {
            b = b.i && b.i.renderContainerCenter ? "google-payments-dialogCenter" : "google-payments-dialog";
            var c = document.createElement("div");
            c.classList.add("google-payments-dialogContainer");
            var d = document.createElement("div");
            d.classList.add("iframeContainer");
            var e = document.createElement("iframe");
            e.classList.add(b);
            e.setAttribute("frameborder", "0");
            e.setAttribute("scrolling", "no");
            d.appendChild(e);
            c.appendChild(d);
            document.body.appendChild(c);
            b = {
                container: c,
                iframe: e
            };
            c = b.iframe;
            d = b.container;
            d.addEventListener("click", sa(a.hc, a, b));
            d.style.display = "none";
            c.style.display = "none";
            c.height = "0px";
            re(c, "all 250ms ease 0s");
            a.yb = !1;
            return b
        };
    W.prototype.hc = function(a) {
        a.container.parentNode && history.back()
    };
    var ne = function(a, b, c, d) {
            b.style.display = "block";
            c.style.display = "block";
            setTimeout(function() {
                c.height = "280px";
                d.i && d.i.renderContainerCenter && c.classList.add("google-payments-activeContainer");
                setTimeout(function() {
                    a.yb = !0;
                    a.Ja && (re(c, a.Ja.transition), c.height = a.Ja.height, a.Ja = null)
                }, 250)
            }, 1)
        },
        re = function(a, b) {
            fd(a, b);
            a.style.setProperty("-webkit-transition", b)
        },
        me = function(a, b, c, d) {
            d.swg || d.apiVersion || (d.apiVersion = 1);
            var e = "";
            d.i && d.i.coordinationToken && (e = d.i.coordinationToken);
            d.environment =
                a.s;
            var g;
            e = qe(a.s, e);
            return de(c, e, d).then(function(f) {
                a.j = f;
                var h = new Ec;
                f.onMessage(function(k) {
                    "partialPaymentDataCallback" == k.type ? a.pb = Jc(k.data, a.B, a.la, h.Wa).then(function(l) {
                        return f.message(l)
                    }) : "fullPaymentDataCallback" == k.type ? a.ob = Ic(k.data, a.B, a.la, h.Wa).then(function(l) {
                        return f.message(l)
                    }) : "resize" == k.type && (a.yb ? (g || (g = Date.now()), Date.now() < g + 250 ? re(c, k.transition + ", height 250ms") : re(c, k.transition), c.height = k.height) : a.Ja = {
                        height: k.height,
                        transition: k.transition
                    })
                });
                return f.Oa()
            }).then(function(f) {
                oe(b,
                    c);
                history.back();
                return f.data
            }, function(f) {
                oe(b, c);
                history.back();
                return r.Promise.reject(f)
            })
        };
    W.prototype.ua = function(a) {
        var b = {
            startTimeMs: Date.now()
        };
        a.i = a.i ? t(Object, "assign").call(Object, b, a.i) : b
    };
    var se = "actions.google.com amp-actions.sandbox.google.com amp-actions-staging.sandbox.google.com amp-actions-autopush.sandbox.google.com payments.developers.google.com payments.google.com".split(" "),
        Y = function(a, b, c, d) {
            this.lb = b;
            Wc(a);
            this.Pb = null;
            this.s = a.environment || "TEST";
            te || (te = -1 != se.indexOf(window.location.hostname) && a.i && a.i.googleTransactionId ? a.i.googleTransactionId : Ta(this.s));
            this.H = a;
            this.Ib = a.merchantInfo && a.merchantInfo.merchantId ? a.merchantInfo.merchantId : "";
            a.paymentDataCallback &&
                (a.paymentDataCallbacks = {
                    onPaymentDataChanged: a.paymentDataCallback
                });
            this.B = null;
            this.l = new ue(a, c);
            this.ea = new W(this.s, c, d, a.i && a.i.redirectKey);
            this.na = 5;
            this.X = null;
            b = this.l.mode;
            this.pa = 5 === b || 4 === b ? new Oc(this.s) : this.ea;
            a.paymentDataCallbacks && (this.B = a.paymentDataCallbacks, this.pa.tb(a.paymentDataCallbacks), this.ea.tb(a.paymentDataCallbacks));
            this.ea.Ea(this.Sb.bind(this));
            this.pa.Ea(this.Sb.bind(this));
            O = b;
            xc = te;
            P({
                eventType: 9,
                clientLatencyStartMs: Date.now(),
                buyFlowActivityReason: this.l.o,
                softwareInfo: X(this)
            });
            window.addEventListener("message", function(e) {
                -1 != se.indexOf(window.location.hostname) && "logPaymentData" === e.data.name && P(e.data.data)
            })
        },
        te, X = function(a) {
            return a.H.merchantInfo && a.H.merchantInfo.softwareInfo ? a.H.merchantInfo.softwareInfo : null
        };
    Y.prototype.F = function(a) {
        var b = this;
        if (a) {
            var c = {};
            this.H.environment && (c.environment = this.H.environment);
            this.H.merchantInfo && (c.merchantInfo = this.H.merchantInfo);
            this.H.i && (c.i = this.H.i);
            a = t(Object, "assign").call(Object, {}, c, a);
            this.Ib = a.merchantInfo && a.merchantInfo.merchantId ? a.merchantInfo.merchantId : ""
        }
        var d = Date.now(),
            e = [].concat(ja(this.l.o));
        P({
            eventType: 12,
            clientLatencyStartMs: d,
            buyFlowActivityReason: e,
            softwareInfo: X(this)
        });
        var g = Vc() || Xc(a);
        if (g) return new r.Promise(function(l, q) {
            E({
                fa: "isReadyToPay",
                errorMessage: g
            });
            P({
                eventType: 0,
                buyFlowActivityReason: e,
                error: 2,
                softwareInfo: X(b)
            });
            q({
                statusCode: "DEVELOPER_ERROR",
                statusMessage: g
            })
        });
        var f = [].concat(ja(this.l.o)),
            h = ve(this, a, f);
        if (a.activityModeRequired) {
            var k = null;
            return we.then(function(l) {
                k = l;
                return h
            }, function() {
                k = !1;
                return h
            }).then(function(l) {
                k || (f.push(40), 5 === b.l.mode && (b.l.mode = 2));
                l.activityMode = b.l.mode;
                xe(b, d, l, f, a);
                return l
            }).catch(function(l) {
                ye(b, l, f, a);
                throw l;
            })
        }
        return h.then(function(l) {
            xe(b, d, l, f, a);
            return l
        }).catch(function(l) {
            ye(b,
                l, f, a);
            throw l;
        })
    };
    var xe = function(a, b, c, d, e) {
            P({
                eventType: 0,
                clientLatencyStartMs: b,
                isReadyToPayApiResponse: c,
                buyFlowActivityReason: d,
                softwareInfo: X(a),
                isReadyToPayRequest: e
            })
        },
        ye = function(a, b, c, d) {
            b.statusCode ? (b = b.statusCode, b = "INTERNAL_ERROR" == b ? 1 : "DEVELOPER_ERROR" == b ? 2 : "MERCHANT_ACCOUNT_ERROR" == b ? 4 : "UNSUPPORTED_API_VERSION" == b ? 5 : "BUYER_CANCEL" == b ? 6 : 0) : b = 1;
            P({
                eventType: 0,
                buyFlowActivityReason: c,
                error: b,
                softwareInfo: X(a),
                isReadyToPayRequest: d
            })
        },
        ve = function(a, b, c) {
            if (google.payments.api.DisableNativeReadyToPayCheckForPaymentHandler ? 4 ===
                a.l.mode && !ze(b) : a.l.La && !ze(b)) {
                if (2 <= b.apiVersion) return Ae(a, b, c);
                var d = a.ea.F(b),
                    e = a.pa.F(b);
                if (Sc(b) && !a.l.ta) return c.push(6), e;
                c.push(7);
                return e.then(function() {
                    return d
                })
            }
            return a.ea.F(b)
        },
        Ae = function(a, b, c) {
            var d = r.Promise.resolve({
                result: !1
            });
            b.existingPaymentMethodRequired && (d = r.Promise.resolve({
                result: !1,
                paymentMethodPresent: !1
            }));
            var e = d;
            if (Uc(b, "CRYPTOGRAM_3DS")) {
                e = JSON.parse(JSON.stringify(b));
                for (var g = 0; g < e.allowedPaymentMethods.length; g++) "CARD" == e.allowedPaymentMethods[g].type &&
                    (e.allowedPaymentMethods[g].parameters.allowedAuthMethods = ["CRYPTOGRAM_3DS"]);
                c.push(8);
                e = a.pa.F(e)
            }
            var f = d;
            Uc(b, "PAN_ONLY") && (c.push(9), f = a.ea.F(b));
            return a.l.ta ? (c.push(99), e.then(function() {
                return f
            })) : e.then(function(h) {
                return 1 == (h && h.result) ? h : f
            })
        };
    m = Y.prototype;
    m.O = function(a) {
        var b = Vc() || ad(a);
        b ? E({
            fa: "prefetchPaymentData",
            errorMessage: b
        }) : (this.ua(a), this.l.La && !ze(a) ? this.pa.O(a) : this.ea.O(a))
    };
    m.Da = function() {};
    m.U = function(a) {
        var b = this,
            c = [].concat(ja(this.l.o)),
            d = function() {
                return P({
                    eventType: 5,
                    buyFlowActivityReason: c.length ? c : [99],
                    softwareInfo: X(b),
                    buttonInfo: b.X
                })
            },
            e = Vc() || ad(a);
        this.na = a && a.swg ? 6 : 5;
        O = this.l.mode;
        if (e) this.lb(new r.Promise(function(k, l) {
            P({
                eventType: 1,
                error: 2,
                buyFlowMode: b.na,
                softwareInfo: X(b),
                buttonInfo: b.X
            });
            E({
                fa: "loadPaymentData",
                errorMessage: e
            });
            l({
                statusCode: "DEVELOPER_ERROR",
                statusMessage: e
            })
        })), d();
        else {
            if (this.B || a.callbackIntents) {
                var g = cd(a, this.B);
                if (g) {
                    this.lb(new r.Promise(function(k,
                        l) {
                        P({
                            eventType: 1,
                            error: 2,
                            buyFlowMode: b.na,
                            softwareInfo: X(b),
                            buttonInfo: b.X
                        });
                        E({
                            fa: "loadPaymentData",
                            errorMessage: g
                        });
                        l({
                            statusCode: "DEVELOPER_ERROR",
                            statusMessage: g
                        })
                    }));
                    d();
                    return
                }
            }
            this.Pb = Date.now();
            var f = Be(this.l, a, c),
                h = 5 === f || 4 === f ? this.pa : this.ea;
            f !== this.l.mode && (O = f);
            this.ua(a);
            d();
            h.U(a)
        }
    };
    m.oa = function(a) {
        a = void 0 === a ? {} : a;
        var b = 0,
            c = 0;
        switch (a.buttonType) {
            case "short":
                b = 1;
                break;
            case "long":
                b = 2;
                break;
            case "plain":
                b = 3;
                break;
            case "buy":
                b = 4;
                break;
            case "donate":
                b = 5;
                break;
            case "book":
                b = 6;
                break;
            case "checkout":
                b = 7;
                break;
            case "order":
                b = 8;
                break;
            case "pay":
                b = 9;
                break;
            case "subscribe":
                b = 10
        }
        switch (a.buttonSizeMode) {
            case "static":
                c = 1;
                break;
            case "fill":
                c = 2
        }
        var d = void 0 === a.buttonRootNode ? 0 : 3;
        a.buttonRootNode instanceof ShadowRoot ? d = 1 : a.buttonRootNode instanceof HTMLDocument && (d = 2);
        this.X = {
            buttonType: b,
            buttonSizeMode: c,
            buttonRootNode: d
        };
        c = this.Ib;
        a = void 0 === a ? {} : a;
        (n = t(Object, "values").call(Object, Ja), t(n, "includes")).call(n, a.buttonType) || (a.buttonType = "long");
        (n = t(Object, "values").call(Object, La), t(n, "includes")).call(n, a.buttonSizeMode) || (a.buttonSizeMode = "static");
        b = a;
        c = c && t(nc, "includes").call(nc, Wa(c));
        d = t(lc, "includes").call(lc, Wa(kc));
        var e = t(mc, "includes").call(mc, Wa(kc));
        if (!(google.payments.api.EnableDynamicGpayButtonForTesting || google.payments.api.EnableDynamicGpayButton || d) || c || e ||
            "long" !== b.buttonType && "buy" !== b.buttonType) {
            var g = a;
            b = sc(g.buttonLocale, !0);
            c = g.buttonRootNode || document;
            t(hc, "includes").call(hc, c) || (Ra("\n.gpay-button {\n  background-origin: content-box;\n  background-position: center center;\n  background-repeat: no-repeat;\n  background-size: contain;\n  border: 0px;\n  border-radius: 4px;\n  box-shadow: rgba(60, 64, 67, 0.3) 0px 1px 1px 0px, rgba(60, 64, 67, 0.15) 0px 1px 3px 1px;\n  cursor: pointer;\n  height: 40px;\n  min-height: 40px;\n  padding: 12px 24px 10px;\n  width: 240px;\n}\n\n.gpay-button.black {\n  background-color: #000;\n  box-shadow: none;\n}\n\n.gpay-button.white {\n  background-color: #fff;\n}\n\n.gpay-button.short, .gpay-button.plain {\n  min-width: 90px;\n  width: 160px;\n}\n\n.gpay-button.black.short, .gpay-button.black.plain {\n  background-image: url(https://www.gstatic.com/instantbuy/svg/dark_gpay.svg);\n}\n\n.gpay-button.white.short, .gpay-button.white.plain {\n  background-image: url(https://www.gstatic.com/instantbuy/svg/light_gpay.svg);\n}\n\n.gpay-button.black.active {\n  background-color: #5f6368;\n}\n\n.gpay-button.black.hover {\n  background-color: #3c4043;\n}\n\n.gpay-button.white.active {\n  background-color: #fff;\n}\n\n.gpay-button.white.focus {\n  box-shadow: #e8e8e8 0 1px 1px 0, #e8e8e8 0 1px 3px;\n}\n\n.gpay-button.white.hover {\n  background-color: #f8f8f8;\n}\n\n.gpay-button-fill, .gpay-button-fill > .gpay-button.white, .gpay-button-fill > .gpay-button.black {\n  width: 100%;\n  height: inherit;\n}\n\n.gpay-button-fill > .gpay-button.white,\n  .gpay-button-fill > .gpay-button.black {\n    padding: 12px 15% 10px;\n}\n\n.gpay-button.donate, .gpay-button.book,\n.gpay-button.checkout,\n.gpay-button.subscribe, .gpay-button.pay,\n.gpay-button.order {\n    padding: 9px 24px;\n}\n\n.gpay-button-fill > .gpay-button.donate,\n.gpay-button-fill > .gpay-button.book,\n.gpay-button-fill > .gpay-button.checkout,\n.gpay-button-fill > .gpay-button.order,\n.gpay-button-fill > .gpay-button.pay,\n.gpay-button-fill > .gpay-button.subscribe {\n    padding: 9px 15%;\n}\n\n",
                c), hc.push(c), ic.push([]));
            d = hc.indexOf(c);
            e = b + "_" + g.buttonType;
            t(ic[d], "includes").call(ic[d], e) || (g = g.buttonType, Ra(g && "short" != g && "plain" != g ? "long" == g || "buy" == g ? "\n    .gpay-button.long." + b + ", .gpay-button.buy." + b + " {\n      min-width: " + Ma.buy[b] + "px;\n    }\n\n    .gpay-button.white.long." + b + ", .gpay-button.white.buy." + b + " {\n      background-image: url(https://www.gstatic.com/instantbuy/svg/light/" + b + ".svg);\n    }\n\n    .gpay-button.black.long." + b + ", .gpay-button.black.buy." + b + " {\n      background-image: url(https://www.gstatic.com/instantbuy/svg/dark/" +
                b + ".svg);\n    }" : "\n    .gpay-button.white." + g + "." + b + " {\n      background-image: url(https://www.gstatic.com/instantbuy/svg/light/" + g + "/" + b + ".svg);\n    }\n\n    .gpay-button.black." + g + "." + b + " {\n      background-image: url(https://www.gstatic.com/instantbuy/svg/dark/" + g + "/" + b + ".svg);\n    }\n\n    .gpay-button." + g + "." + b + " {\n      min-width: " + Ma[g][b] + "px;\n    }\n  " : "", c), ic[d].push(e));
            b = document.createElement("button");
            qc(b);
            (n = t(Object, "values").call(Object, Ka), t(n, "includes")).call(n, a.buttonColor) ||
                (a.buttonColor = "default");
            "default" == a.buttonColor && (a.buttonColor = "black");
            c = pc(a);
            b.setAttribute("class", "gpay-button " + c);
            rc(b);
            if (a.onClick) b.addEventListener("click", a.onClick);
            else throw Error("Parameter 'onClick' must be set.");
            c = document.createElement("div");
            "fill" === a.buttonSizeMode && c.setAttribute("class", "gpay-button-fill");
            c.appendChild(b);
            a = c
        } else a = oc(a);
        P({
            eventType: 2,
            clientLatencyStartMs: Date.now(),
            buyFlowActivityReason: this.l.o,
            softwareInfo: X(this),
            buttonInfo: this.X
        });
        return a
    };
    m.Sb = function(a) {
        var b = this;
        a = a.then(function(c) {
            google.payments.api.LogInternally && console.log("payment data", c);
            if (c.error) {
                var d = Error();
                d.statusCode = c.error.statusCode;
                d.statusMessage = c.error.statusMessage;
                E({
                    fa: "loadPaymentData",
                    errorMessage: d.statusMessage
                });
                throw d;
            }
            return c
        });
        a.then(function(c) {
            google.payments.api.LogInternally && console.log("payment data resolve to ", c);
            P({
                eventType: 1,
                clientLatencyStartMs: b.Pb,
                buyFlowMode: b.na,
                buyFlowActivityReason: b.l.o,
                softwareInfo: X(b),
                buttonInfo: b.X
            })
        }).catch(function(c) {
            google.payments.api.LogInternally &&
                console.log("payment data has error", c);
            c.errorCode ? P({
                eventType: 1,
                error: c.errorCode,
                buyFlowMode: b.na,
                buyFlowActivityReason: b.l.o,
                softwareInfo: X(b),
                buttonInfo: b.X
            }) : P({
                eventType: 1,
                error: 6,
                buyFlowMode: b.na,
                buyFlowActivityReason: b.l.o,
                softwareInfo: X(b),
                buttonInfo: b.X
            })
        });
        this.lb(a)
    };
    m.ua = function(a) {
        var b = {
            googleTransactionId: te,
            usingPayJs: !0
        };
        a.i = a.i ? t(Object, "assign").call(Object, b, a.i) : b;
        a.i.firstPartyMerchantIdentifier && delete a.i.firstPartyMerchantIdentifier;
        this.H.i && this.H.i.firstPartyMerchantIdentifier && (a.i.firstPartyMerchantIdentifier = this.H.i.firstPartyMerchantIdentifier)
    };
    Y.prototype.createButton = Y.prototype.oa;
    Y.prototype.loadPaymentData = Y.prototype.U;
    Y.prototype.notifyAvailableOffers = Y.prototype.Da;
    Y.prototype.prefetchPaymentData = Y.prototype.O;
    Y.prototype.isReadyToPay = Y.prototype.F;
    var we = null,
        Ce = null,
        ue = function(a, b) {
            b = void 0 === b ? !1 : b;
            this.eb = a;
            this.o = [];
            null != window.navigator.userAgent.match(/Android|iPhone|iPad|iPod|BlackBerry|IEMobile/i) ? (this.o.push(37), a = !1) : (a = window.navigator.userAgent.match(/Chrome\/([0-9]+)\./i), "PaymentRequest" in window && null != a && 70 <= Number(a[1]) && "Google Inc." == window.navigator.vendor ? (this.o.push(98), this.eb.paymentDataCallbacks && this.o.push(97), a = !0) : (this.o.push(36), a = !1));
            this.ta = a;
            this.La = De(this);
            this.mode = 2;
            b ? (this.o = [38], this.mode = 1) : this.La &&
                this.ta ? this.mode = 5 : this.La && (this.mode = 4);
            this.eb.paymentDataCallbacks && this.o.push(1)
        },
        ze = function(a) {
            return !0 === (a.i && a.i.disableNative)
        },
        Be = function(a, b, c) {
            return 2 === a.mode || 1 === a.mode ? a.mode : ze(b) ? (c.push(3), 2) : !Ce && (a.ta || google.payments.api.UseCanMakePaymentForFallbackOnMobile && a.La) ? (c.push(40), 2) : a.ta && b.swg ? (c.push(5), 2) : a.mode
        },
        De = function(a) {
            if (!window.PaymentRequest) return a.o.push(41), !1;
            var b = -1 !== window.navigator.userAgent.indexOf("OPT/"),
                c = -1 !== window.navigator.userAgent.indexOf("SamsungBrowser/");
            if (-1 !== window.navigator.userAgent.indexOf("OPR/") || b || c) return a.o.push(35), !1;
            if (a.ta) return !0;
            if (google.payments.api.DisablePaymentRequest && !google.payments.api.EnablePaymentRequest) return a.o.push(3), !1;
            b = window.navigator.userAgent.match(/Android/i);
            c = window.navigator.userAgent.match(/Chrome\/([0-9]+)\./i);
            if (!(null != b && "PaymentRequest" in window && "Google Inc." == window.navigator.vendor && null != c && 59 <= Number(c[1]))) return a.o.push(34), !1;
            if (!a.eb.paymentDataCallbacks) return !0;
            if (92 > Number(c[1])) return !1;
            a.o.push(96);
            return google.payments.api.EnableDynamicUpdateForClank ? !0 : (a.o.push(42), !1)
        };
    ma("google.payments.api.PaymentsAsyncClient", Y);
    Y.prototype.isReadyToPay = Y.prototype.F;
    Y.prototype.prefetchPaymentData = Y.prototype.O;
    Y.prototype.loadPaymentData = Y.prototype.U;
    Y.prototype.createButton = Y.prototype.oa;
    Y.prototype.notifyAvailableOffers = Y.prototype.Da;
    var Z = function(a, b) {
        a = void 0 === a ? {} : a;
        this.oc = Ua({}, window.gpayMerchantIdFromUrl ? {
            merchantInfo: {
                merchantId: window.gpayMerchantIdFromUrl
            }
        } : {}, window.gpayInitParams, a);
        this.Qa = new Y(this.oc, this.sc.bind(this), b);
        this.Fa = null
    };
    m = Z.prototype;
    m.sc = function(a) {
        this.Fa(a)
    };
    m.F = function(a) {
        return this.Qa.F(a)
    };
    m.O = function(a) {
        this.Qa.O(a)
    };
    m.Da = function() {};
    m.U = function(a) {
        var b = this;
        google.payments.api.EnablePwgTestExperiment && console.log("ZOMBIEMONKEYATEMYBRAIN");
        return (new r.Promise(function(c) {
            if (b.Fa) throw Error("This method can only be called one at a time.");
            b.Fa = c;
            b.Qa.U(a)
        })).then(function(c) {
            b.Fa = null;
            return c
        }, function(c) {
            b.Fa = null;
            throw c;
        })
    };
    m.oa = function(a) {
        a = void 0 === a ? {} : a;
        return this.Qa.oa(a)
    };
    Z.prototype.createButton = Z.prototype.oa;
    Z.prototype.loadPaymentData = Z.prototype.U;
    Z.prototype.notifyAvailableOffers = Z.prototype.Da;
    Z.prototype.prefetchPaymentData = Z.prototype.O;
    Z.prototype.isReadyToPay = Z.prototype.F;
    ma("google.payments.api.PaymentsClient", Z);
    Z.prototype.isReadyToPay = Z.prototype.F;
    Z.prototype.prefetchPaymentData = Z.prototype.O;
    Z.prototype.loadPaymentData = Z.prototype.U;
    Z.prototype.createButton = Z.prototype.oa;
    Z.prototype.notifyAvailableOffers = Z.prototype.Da;
    google.payments.api.UseCanMakePaymentResultFromPayjs && (we = (new PaymentRequest([{
        supportedMethods: ["https://google.com/pay"],
        data: {
            apiVersion: 2,
            apiVersionMinor: 0,
            allowedPaymentMethods: [{
                type: "CARD",
                parameters: {
                    allowedAuthMethods: ["PAN_ONLY", "CRYPTOGRAM_3DS"],
                    allowedCardNetworks: ["VISA", "MASTERCARD"]
                }
            }]
        }
    }], {
        total: {
            label: "Estimated Total Price",
            amount: {
                currency: "USD",
                value: "10"
            }
        }
    })).canMakePayment(), we.then(function(a) {
        return Ce = a
    }).catch(function() {
        return Ce = !1
    }));
}).call(this);