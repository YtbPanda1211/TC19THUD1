(("undefined" != typeof self ? self : this).webpackChunkshopee_pc = ("undefined" != typeof self ? self : this).webpackChunkshopee_pc || []).push([
    [9940], {
        5960: function(e, t, n) {
            "use strict";
            n.d(t, {
                fE: function() {
                    return I
                },
                PR: function() {
                    return W
                },
                ZP: function() {
                    return J
                }
            });
            var r = n(27378),
                o = n.n(r),
                a = n(60042),
                c = n.n(a),
                i = n(88289);

            function u() {
                return (u = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(this, arguments)
            }
            var s = function(e) {
                return o().createElement("svg", u({
                    viewBox: "0 0 25 68.1"
                }, e), o().createElement("path", {
                    fillRule: "evenodd",
                    strokeLinecap: "round",
                    strokeWidth: ".945",
                    d: "M12.1 18.4v49.7H25V0L0 13v11.9l12.1-6.5z"
                }))
            };

            function l() {
                return (l = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(this, arguments)
            }
            var m = function(e) {
                return o().createElement("svg", l({
                    viewBox: "0 0 42.3 67.703"
                }, e), o().createElement("path", {
                    fillRule: "evenodd",
                    strokeLinecap: "round",
                    strokeWidth: ".945",
                    d: "M21.6 56.403l12.5-18.3c5.081-7.491 7.492-12.684 8.063-17.877a22.986 22.986 0 0 0 .137-2.523A17.062 17.062 0 0 0 30.133 1.242 24.304 24.304 0 0 0 22.3.003a23.551 23.551 0 0 0-9.787 1.948C5.323 5.212 1.199 12.42 1.199 22.443a36.776 36.776 0 0 0 .001.26H13a70.067 70.067 0 0 1 .052-1.368c.118-2.398.351-3.497.948-5.032a7.181 7.181 0 0 1 5.187-4.431 9.74 9.74 0 0 1 2.313-.269c4.599 0 7.899 3.099 7.9 7.398a5.467 5.467 0 0 1 0 .002 11.162 11.162 0 0 1-.092 1.496c-.29 2.167-1.352 4.335-4.331 9.011a261.731 261.731 0 0 1-1.677 2.593L0 67.703h40.5v-11.3H21.6z"
                }))
            };

            function d() {
                return (d = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(this, arguments)
            }
            var p = function(e) {
                return o().createElement("svg", d({
                    viewBox: "0 0 43 67"
                }, e), o().createElement("path", {
                    fillRule: "evenodd",
                    strokeLinecap: "round",
                    strokeWidth: ".945",
                    d: "M22.5 11L7.3 31.3l7.2 6.1c1.9-1.2 3.8-1.7 6.1-1.7a10.732 10.732 0 0 1 5.741 1.573c2.816 1.762 4.559 4.87 4.559 8.627a10.175 10.175 0 0 1-2.626 6.924A10.165 10.165 0 0 1 20.7 56.1c-4.086 0-7.199-2.156-8.584-5.887A12.3 12.3 0 0 1 11.5 47.8L0 48.2c.595 4.955 1.386 7.553 3.347 10.52a24.795 24.795 0 0 0 .053.08 19.859 19.859 0 0 0 13.535 8.466A24.541 24.541 0 0 0 21 67.6c11.745 0 20.628-8.083 22.012-19.459A25.999 25.999 0 0 0 43.2 45a22.484 22.484 0 0 0-2.049-9.694c-2.825-5.949-8.41-9.794-15.751-10.406L43.9 0H3.3v11h19.2z"
                }))
            };

            function h() {
                return (h = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(this, arguments)
            }
            var f = function(e) {
                return o().createElement("svg", h({
                    viewBox: "0 0 42.9 66.9"
                }, e), o().createElement("path", {
                    fillRule: "evenodd",
                    strokeLinecap: "round",
                    strokeWidth: ".945",
                    d: "M24.5 53.2v13.7h12.3V53.2h6.1v-11h-6.1V0H23.4L0 42.5v10.7h24.5zm0-11h-14l14-24.8v24.8z"
                }))
            };

            function v() {
                return (v = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(this, arguments)
            }
            var y = function(e) {
                return o().createElement("svg", v({
                    viewBox: "0 0 42.8 67.6"
                }, e), o().createElement("path", {
                    fillRule: "evenodd",
                    strokeLinecap: "round",
                    strokeWidth: ".945",
                    d: "M15.2 11.6h22.3V0h-34v39.5h8.4a13.796 13.796 0 0 1 2.081-2.256A9.364 9.364 0 0 1 20.4 35c5.6 0 9.9 4.5 9.9 10.3 0 5.8-4.3 10.2-9.8 10.2a9.594 9.594 0 0 1-3.975-.775c-2.283-1.024-3.971-3.081-5.231-6.281a22.17 22.17 0 0 1-.094-.244L0 52.4a62.066 62.066 0 0 0 .565 1.425c1.46 3.548 2.682 5.38 4.659 7.484a37.124 37.124 0 0 0 .276.291 21.422 21.422 0 0 0 13.729 5.945 25.179 25.179 0 0 0 1.671.055 21.976 21.976 0 0 0 13.258-4.2c4.31-3.202 7.279-8.057 8.275-13.942A26.715 26.715 0 0 0 42.8 45c0-11.9-8.3-20.9-19.4-20.9a20.186 20.186 0 0 0-2.2.112c-1.856.203-3.576.691-5.716 1.57a41.606 41.606 0 0 0-.284.118V11.6z"
                }))
            };

            function _() {
                return (_ = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(this, arguments)
            }
            var E = function(e) {
                return o().createElement("svg", _({
                    viewBox: "0 0 43.402 67.6"
                }, e), o().createElement("path", {
                    fillRule: "evenodd",
                    strokeLinecap: "round",
                    strokeWidth: ".945",
                    d: "M38.501 0h-14.6l-16.6 26.2a87.112 87.112 0 0 0-2.841 4.806C1.956 35.606.636 39.352.184 43.098A25.786 25.786 0 0 0 .001 46.2c0 11.983 8.875 21.071 20.561 21.391a23.329 23.329 0 0 0 .639.009c12.3 0 22.2-9.9 22.2-22.2a20.356 20.356 0 0 0-5.04-13.557 17.916 17.916 0 0 0-13.46-6.143c-1.043 0-1.817.09-3.26.526a26.98 26.98 0 0 0-.24.074L38.501 0zm-7.326 44.352a9.309 9.309 0 0 0-9.274-8.052 10.442 10.442 0 0 0-.638.019A9.653 9.653 0 0 0 12.101 46a10.844 10.844 0 0 0 .031.817c.196 2.596 1.324 4.831 3.063 6.396a9.473 9.473 0 0 0 6.406 2.387c5.4 0 9.7-4.3 9.7-9.6a10.703 10.703 0 0 0-.126-1.648z"
                }))
            };

            function g() {
                return (g = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(this, arguments)
            }
            var w = function(e) {
                return o().createElement("svg", g({
                    viewBox: "0 0 39.5 66.3"
                }, e), o().createElement("path", {
                    fillRule: "evenodd",
                    strokeLinecap: "round",
                    strokeWidth: ".945",
                    d: "M21.6 11.6L0 66.3h13.3L39.5 0H.1v11.6h21.5z"
                }))
            };

            function b() {
                return (b = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(this, arguments)
            }
            var k = function(e) {
                return o().createElement("svg", b({
                    viewBox: "0 0 43.204 69.004"
                }, e), o().createElement("path", {
                    fillRule: "evenodd",
                    strokeLinecap: "round",
                    strokeWidth: ".945",
                    d: "M33.603 32.802a31.686 31.686 0 0 0 .79-.423c2.107-1.169 3.051-2.091 4.378-4.03a32.68 32.68 0 0 0 .032-.047c1.9-2.9 2.8-6.1 2.8-9.7 0-10.8-8.2-18.6-19.6-18.6-11.335 0-19.479 7.414-19.976 17.97a21.882 21.882 0 0 0-.024 1.03 17.926 17.926 0 0 0 1.016 6.155 13.457 13.457 0 0 0 6.884 7.645C4.606 35.049 1.434 38.971.389 44.62a24.628 24.628 0 0 0-.386 4.482c0 11.8 8.7 19.9 21.4 19.9a24.237 24.237 0 0 0 11.074-2.514c6.306-3.218 10.335-9.304 10.699-16.947a23.948 23.948 0 0 0 .027-1.139 20.81 20.81 0 0 0-.846-6.134c-1.294-4.206-4.073-7.299-8.337-9.278a20.642 20.642 0 0 0-.417-.188zm-11.9 6.1c4.9 0 9.1 4.2 9.1 9.3 0 5.1-4.1 9.2-9.2 9.2a9.644 9.644 0 0 1-5.269-1.484c-2.255-1.453-3.734-3.872-3.991-6.794a10.51 10.51 0 0 1-.04-.922 9.237 9.237 0 0 1 2.404-6.318c1.703-1.853 4.18-2.982 6.996-2.982zm.2-27.9c4.5 0 8.4 3.8 8.4 8.2 0 4.4-4 8.2-8.5 8.2-4.6 0-8.2-3.7-8.2-8.4a7.892 7.892 0 0 1 1.919-5.273c1.232-1.404 2.986-2.353 5.055-2.638a9.726 9.726 0 0 1 1.326-.089z"
                }))
            };

            function S() {
                return (S = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(this, arguments)
            }
            var N = function(e) {
                return o().createElement("svg", S({
                    viewBox: "0 0 43.503 67.701"
                }, e), o().createElement("path", {
                    fillRule: "evenodd",
                    strokeLinecap: "round",
                    strokeWidth: ".945",
                    d: "M5.501 67.701h14.4l16.4-26.1c4.512-7.165 6.676-12.531 7.115-17.896a25.743 25.743 0 0 0 .085-2.104c0-11.759-8.183-20.64-19.519-21.527a24.115 24.115 0 0 0-1.881-.073c-12.5 0-22.1 9.5-22.1 22 0 11.3 8.3 19.9 19.3 19.9.851 0 1.523-.089 2.777-.352a55.135 55.135 0 0 0 .223-.048l-16.8 26.2zm25.797-46.447a9.47 9.47 0 0 0-9.297-9.353 10.339 10.339 0 0 0-.503.013 9.524 9.524 0 0 0-9.197 9.487c0 5.4 4.1 9.6 9.4 9.6 2.785 0 5.25-1.09 6.985-2.886a9.421 9.421 0 0 0 2.615-6.614 10.005 10.005 0 0 0-.003-.247z",
                    vectorEffect: "non-scaling-stroke"
                }))
            };

            function O() {
                return (O = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(this, arguments)
            }
            var D = function(e) {
                return o().createElement("svg", O({
                    viewBox: "0 0 41.701 69.001"
                }, e), o().createElement("path", {
                    fillRule: "evenodd",
                    strokeLinecap: "round",
                    strokeWidth: ".945",
                    d: "M.001 23.201v21.3a86.087 86.087 0 0 0 .141 5.239c.24 3.911.8 6.807 1.788 9.131a13.986 13.986 0 0 0 3.071 4.53c3.183 3.183 8.009 5.116 13.716 5.52a32.308 32.308 0 0 0 2.284.08 27.934 27.934 0 0 0 6.391-.693c2.999-.704 5.593-1.942 7.767-3.697a17.608 17.608 0 0 0 1.042-.91 16.219 16.219 0 0 0 4.725-8.397c.365-1.533.594-3.225.702-5.11a47.264 47.264 0 0 0 .073-2.693v-25.9c0-4.153-.458-7.389-1.5-10.073a15.929 15.929 0 0 0-4.5-6.327A20.063 20.063 0 0 0 26.805.689a27.077 27.077 0 0 0-6.204-.688c-6.7 0-12.5 2.2-16.1 6.2C1.536 9.443.202 13.886.022 21.359a76.328 76.328 0 0 0-.021 1.842zm29.1-.6v23.2a49.403 49.403 0 0 1-.043 2.168c-.07 1.589-.23 2.783-.497 3.768a8.197 8.197 0 0 1-.86 2.064 7.193 7.193 0 0 1-3.81 2.919 8.858 8.858 0 0 1-2.89.481 8.941 8.941 0 0 1-5.066-1.538 6.167 6.167 0 0 1-1.634-1.662 8.307 8.307 0 0 1-.297-.421c-.937-1.425-1.103-2.85-1.103-7.679v-22.7c0-2.681.162-4.465.54-5.847a8.234 8.234 0 0 1 .86-2.053c1.2-2.1 3.7-3.3 6.7-3.3a9.192 9.192 0 0 1 3.315.591 7.04 7.04 0 0 1 2.785 1.909 6.754 6.754 0 0 1 1.558 2.985c.316 1.252.442 2.856.442 5.115z"
                }))
            };
            var C = (0, i.Z)(s, "zoom"),
                x = (0, i.Z)(m, "zoom"),
                T = (0, i.Z)(p, "zoom"),
                H = (0, i.Z)(f, "zoom"),
                j = (0, i.Z)(y, "zoom"),
                B = (0, i.Z)(E, "zoom"),
                L = (0, i.Z)(w, "zoom"),
                A = (0, i.Z)(k, "zoom"),
                M = (0, i.Z)(N, "zoom"),
                P = (0, i.Z)(D, "zoom"),
                R = function(e) {
                    var t = e.number,
                        n = function(e, t) {
                            if (null == e) return {};
                            var n, r, o = {},
                                a = Object.keys(e);
                            for (r = 0; r < a.length; r++) n = a[r], t.indexOf(n) >= 0 || (o[n] = e[n]);
                            return o
                        }(e, ["number"]);
                    switch (t) {
                        case 1:
                            return r.createElement(C, n);
                        case 2:
                            return r.createElement(x, n);
                        case 3:
                            return r.createElement(T, n);
                        case 4:
                            return r.createElement(H, n);
                        case 5:
                            return r.createElement(j, n);
                        case 6:
                            return r.createElement(B, n);
                        case 7:
                            return r.createElement(L, n);
                        case 8:
                            return r.createElement(A, n);
                        case 9:
                            return r.createElement(M, n);
                        case 0:
                            return r.createElement(P, n)
                    }
                },
                z = n(37626),
                Z = n(36023),
                W = {
                    COUNT_UP: -1,
                    COUNT_DOWN: 1
                },
                I = {
                    HOUR: 36e5,
                    MINUTE: 6e4,
                    SECOND: 1e3
                };

            function U(e, t) {
                return (U = Object.setPrototypeOf || function(e, t) {
                    return e.__proto__ = t, e
                })(e, t)
            }
            var V = {
                    SENARY: [0, 5, 4, 3, 2, 1, 0],
                    DECIMAL: [0, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0]
                },
                G = function(e) {
                    var t = e.colonState,
                        n = e.theme,
                        o = e.style;
                    return r.createElement("div", {
                        className: c()("shopee-countdown-timer__colon", "shopee-countdown-timer__colon--flashing-" + t, n && "shopee-countdown-timer__colon--" + n),
                        style: o || void 0
                    }, r.createElement("div", {
                        className: "colon-dot__wrapper"
                    }, r.createElement("span", {
                        className: "colon-dot"
                    })), r.createElement("div", {
                        className: "colon-dot__wrapper"
                    }, r.createElement("span", {
                        className: "colon-dot"
                    })))
                },
                Y = function(e) {
                    var t, n;

                    function o() {
                        for (var t, n = arguments.length, r = new Array(n), o = 0; o < n; o++) r[o] = arguments[o];
                        return (t = e.call.apply(e, [this].concat(r)) || this).countdownEndTimer = 0, t.state = {
                            isCountdownEnded: 1e3 * t.props.targetTimeInSeconds - (new Date).getTime() <= 0
                        }, t.onSafariVisibilityChange = function() {
                            t.setState({
                                isCountdownEnded: document.hidden || 1e3 * t.props.targetTimeInSeconds - (new Date).getTime() <= 0
                            })
                        }, t
                    }
                    n = e, (t = o).prototype = Object.create(n.prototype), t.prototype.constructor = t, U(t, n);
                    var a = o.prototype;
                    return a.componentDidMount = function() {
                        var e = this,
                            t = 1e3 * this.props.targetTimeInSeconds - (new Date).getTime();
                        t < 2147483647 && (this.countdownEndTimer = window.setTimeout((function() {
                            e.state.isCountdownEnded || (e.setState({
                                isCountdownEnded: !0
                            }), e.props.onCountdownEnded && e.props.onCountdownEnded())
                        }), t)), (0, Z.G6)() && document.addEventListener("visibilitychange", this.onSafariVisibilityChange, !1)
                    }, a.componentWillUnmount = function() {
                        clearTimeout(this.countdownEndTimer), (0, Z.G6)() && document.removeEventListener("visibilitychange", this.onSafariVisibilityChange, !1)
                    }, a.render = function() {
                        var e = this.props,
                            t = e.flipRate,
                            n = e.nonFlashing,
                            o = e.flipBoardStyle,
                            a = e.colonStyle,
                            i = e.numberStyle,
                            u = e.targetTimeInSeconds,
                            s = this.state.isCountdownEnded,
                            l = +new Date,
                            m = Math.max(0, (1e3 * u - l) * this.props.type),
                            d = (0, z.ki)(m),
                            p = d.hour,
                            h = d.minute,
                            f = d.second,
                            v = F(p, h, f),
                            y = v.hourHundDelay,
                            _ = v.hourDecaDelay,
                            E = v.hourHexaDelay,
                            g = v.minuteDecaDelay,
                            w = v.minuteHexaDelay,
                            b = v.secondDecaDelay,
                            k = v.secondHexaDelay,
                            S = n ? "on" : "off";
                        return r.createElement("div", {
                            className: c()("shopee-countdown-timer", this.props.classNames)
                        }, r.createElement("div", {
                            className: "shopee-countdown-timer__number",
                            style: o || void 0
                        }, p > 99 && r.createElement("div", {
                            className: c()("shopee-countdown-timer__number__hexa", s ? "" : "shopee-countdown-timer__number__hund--hour"),
                            style: {
                                animationDelay: y
                            },
                            key: y
                        }, V.DECIMAL.map((function(e, t) {
                            return r.createElement("div", {
                                className: c()("shopee-countdown-timer__number__item"),
                                key: t
                            }, r.createElement(R, {
                                number: e,
                                iconStyle: i || void 0
                            }))
                        }))), r.createElement("div", {
                            className: c()("shopee-countdown-timer__number__hexa", s ? "" : "shopee-countdown-timer__number__hexa--hour"),
                            style: {
                                animationDelay: E
                            },
                            key: E
                        }, V.DECIMAL.map((function(e, t) {
                            return r.createElement("div", {
                                className: c()("shopee-countdown-timer__number__item"),
                                key: t
                            }, r.createElement(R, {
                                number: e,
                                iconStyle: i || void 0
                            }))
                        }))), r.createElement("div", {
                            className: c()("shopee-countdown-timer__number__deca", s ? "" : "shopee-countdown-timer__number__deca--hour"),
                            style: {
                                animationDelay: _
                            },
                            key: _
                        }, V.DECIMAL.map((function(e, t) {
                            return r.createElement("div", {
                                className: c()("shopee-countdown-timer__number__item"),
                                key: t
                            }, r.createElement(R, {
                                number: e,
                                iconStyle: i || void 0
                            }))
                        })))), t <= I.MINUTE && [r.createElement(G, {
                            key: "colon-before-minute",
                            colonState: S,
                            theme: this.props.theme,
                            style: a
                        }), r.createElement("div", {
                            key: "digit-minute",
                            className: "shopee-countdown-timer__number",
                            style: o || void 0
                        }, r.createElement("div", {
                            className: c()("shopee-countdown-timer__number__hexa", s ? "" : "shopee-countdown-timer__number__hexa--minute"),
                            style: {
                                animationDelay: w
                            },
                            key: w
                        }, V.SENARY.map((function(e, t) {
                            return r.createElement("div", {
                                className: c()("shopee-countdown-timer__number__item"),
                                key: t
                            }, r.createElement(R, {
                                number: e,
                                iconStyle: i || void 0
                            }))
                        }))), r.createElement("div", {
                            className: c()("shopee-countdown-timer__number__deca", s ? "" : "shopee-countdown-timer__number__deca--minute"),
                            style: {
                                animationDelay: g
                            },
                            key: g
                        }, V.DECIMAL.map((function(e, t) {
                            return r.createElement("div", {
                                className: c()("shopee-countdown-timer__number__item"),
                                key: t
                            }, r.createElement(R, {
                                number: e,
                                iconStyle: i || void 0
                            }))
                        }))))], t <= I.SECOND && [r.createElement(G, {
                            key: "colon-before-second",
                            colonState: S,
                            theme: this.props.theme,
                            style: a
                        }), r.createElement("div", {
                            key: "digit-second",
                            className: "shopee-countdown-timer__number",
                            style: o || void 0
                        }, r.createElement("div", {
                            className: c()("shopee-countdown-timer__number__hexa", s ? "" : "shopee-countdown-timer__number__hexa--second"),
                            style: {
                                animationDelay: k
                            },
                            key: k
                        }, V.SENARY.map((function(e, t) {
                            return r.createElement("div", {
                                className: c()("shopee-countdown-timer__number__item"),
                                key: t
                            }, r.createElement(R, {
                                number: e,
                                iconStyle: i || void 0
                            }))
                        }))), r.createElement("div", {
                            className: c()("shopee-countdown-timer__number__deca", s ? "" : "shopee-countdown-timer__number__deca--second"),
                            style: {
                                animationDelay: b
                            },
                            key: b
                        }, V.DECIMAL.map((function(e, t) {
                            return r.createElement("div", {
                                className: c()("shopee-countdown-timer__number__item"),
                                key: t
                            }, r.createElement(R, {
                                number: e,
                                iconStyle: i || void 0
                            }))
                        }))))])
                    }, o
                }(r.PureComponent);
            Y.defaultProps = {
                type: W.COUNT_DOWN,
                flipRate: I.SECOND
            };
            var F = function(e, t, n) {
                    return {
                        secondDecaDelay: n % 10 - 9 + "s",
                        secondHexaDelay: n - 68 + "s",
                        minuteDecaDelay: t % 10 * 60 + n - 658 + "s",
                        minuteHexaDelay: 60 * t + n - 4198 + "s",
                        hourDecaDelay: e % 10 * 3600 + 60 * t + n - 39598 + "s",
                        hourHexaDelay: e % 100 * 3600 + 60 * t + n - 395998 + "s",
                        hourHundDelay: e % 1e3 * 3600 + 60 * t + n - 3959998 + "s"
                    }
                },
                J = Y
        },
        9315: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return i
                }
            });
            var r = n(27378),
                o = n(60710),
                a = n(312),
                c = function(e) {
                    var t = e.customHeader;
                    return r.createElement("img", {
                        src: (0, o.Jn)(t.image),
                        style: {
                            width: t.display_width ? (0, a.Z)(t.display_width) : "auto",
                            height: t.display_height ? (0, a.Z)(t.display_height) : "auto"
                        }
                    })
                },
                i = function(e) {
                    var t = e.headerText,
                        n = e.customHeader;
                    return n ? n.image ? r.createElement(c, {
                        customHeader: {
                            image: n.image,
                            display_width: n.display_width,
                            display_height: n.display_height
                        }
                    }) : r.createElement("span", {
                        style: {
                            color: n.color
                        }
                    }, t) : r.createElement(r.Fragment, null, t) || null
                }
        },
        41236: function(e, t, n) {
            "use strict";
            n.d(t, {
                f: function() {
                    return o
                },
                a: function() {
                    return a
                }
            });
            var r = n(92027);

            function o(e) {
                return function(t) {
                    if (!t) return {};
                    var n = {};
                    for (var r in e) {
                        var o = e[r],
                            a = "function" == typeof o ? o(t) : t[o];
                        n[r] = a
                    }
                    return n
                }
            }

            function a(e) {
                var t = {};
                for (var n in e) t[e[n]] = n;
                return function(e) {
                    return (0, r.Wc)(o(t)(e))
                }
            }
        },
        61309: function(e, t, n) {
            "use strict";
            n.d(t, {
                l1: function() {
                    return r
                },
                nt: function() {
                    return d
                },
                Ty: function() {
                    return h
                }
            });
            var r, o, a = n(27378),
                c = n(79308),
                i = n(97953),
                u = n(73180),
                s = n(8205);
            ! function(e) {
                e[e.homepageGroupbuySection = 0] = "homepageGroupbuySection", e[e.userPageMyGroupsSection = 1] = "userPageMyGroupsSection"
            }(r || (r = {}));
            var l = i.Xb.getLocale(),
                m = ((o = {})[r.homepageGroupbuySection] = ["SG"], o[r.userPageMyGroupsSection] = ["TW", "SG"], o);

            function d(e) {
                return function(e, t) {
                    if ("TW" === l && (e = !0), void 0 !== t) {
                        var n = m[t];
                        if (n) return e && n.includes(l)
                    }
                    return e
                }((0, c.useSelector)((function(e) {
                    return (0, u.Au)(e.featureToggles, s.MEi)
                })), e)
            }

            function p() {
                return (p = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(this, arguments)
            }
            var h = function(e, t) {
                var n = a.forwardRef((function(n, r) {
                        var o = d(t);
                        return a.createElement(e, p({}, n, {
                            enableGroupBuy: o,
                            ref: r
                        }))
                    })),
                    r = function(e) {
                        return e.displayName || e.name || "Component"
                    }(n);
                return n.displayName = "WithEnableGroupBuy(" + r + ")", n
            }
        },
        32666: function(e, t, n) {
            "use strict";
            n.d(t, {
                S: function() {
                    return v
                }
            });
            var r = n(27378),
                o = n.n(r),
                a = n(60042),
                c = n.n(a),
                i = n(98466),
                u = n(95802),
                s = n(4918),
                l = n(70510),
                m = n(9315),
                d = n(60710);

            function p(e, t) {
                if (null == e) return {};
                var n, r, o = {},
                    a = Object.keys(e);
                for (r = 0; r < a.length; r++) n = a[r], t.indexOf(n) >= 0 || (o[n] = e[n]);
                return o
            }

            function h() {
                return (h = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(this, arguments)
            }
            var f = function(e) {
                    var t = e.headerButton,
                        n = e.onHeaderButtonClick,
                        r = e.simpleVersion,
                        a = e.hasNoNavigation,
                        c = e.customButtonContent,
                        i = e.headerButtonStyle,
                        m = e.headerSectionButtonProps,
                        d = t.linkTo,
                        p = c || o().createElement(o().Fragment, null, t.text, " ", o().createElement(s.Z, null)),
                        f = r ? o().createElement(l.Rd, h({
                            targetType: "SeeAllButton",
                            style: i
                        }, m), p) : o().createElement(l.s7, h({
                            targetType: "SeeAllButton",
                            style: i
                        }, m), p);
                    return a ? o().createElement("div", {
                        className: "shopee-header-section__header-link",
                        onClick: function(e) {
                            n && n(e)
                        }
                    }, f) : o().createElement(u.Z, {
                        to: d,
                        className: "shopee-header-section__header-link",
                        onClick: function(e) {
                            n && n(e)
                        }
                    }, f)
                },
                v = (0, i.Z)((function(e) {
                    var t = e.headerText,
                        n = e.headerButton,
                        r = e.children,
                        a = e.simpleVersion,
                        i = e.classNames,
                        u = e.customButtonContent,
                        s = e.hasNoNavigation,
                        l = e.onHeaderButtonClick,
                        v = e.style,
                        y = void 0 === v ? {} : v,
                        _ = e.trackingRef,
                        E = e.headerStyle,
                        g = void 0 === E ? {} : E,
                        w = e.customHeader,
                        b = p(e, ["headerText", "headerButton", "children", "simpleVersion", "classNames", "customButtonContent", "hasNoNavigation", "onHeaderButtonClick", "style", "trackingRef", "headerStyle", "customHeader"]),
                        k = {
                            backgroundImage: w && w.background_image ? "url(" + (0, d.Jn)(w.background_image) + ")" : void 0
                        },
                        S = (g.seeAllColor, p(g, ["seeAllColor"]));
                    return o().createElement("div", {
                        className: c()("shopee-header-section", i, !!a && "shopee-header-section--simple"),
                        ref: _ || null,
                        style: y
                    }, o().createElement("div", {
                        className: "shopee-header-section__header",
                        style: k
                    }, o().createElement("div", {
                        className: "shopee-header-section__header__title",
                        style: S
                    }, o().createElement(m.Z, {
                        headerText: t,
                        customHeader: w
                    })), !!n && o().createElement(f, {
                        headerButton: n,
                        simpleVersion: !!a,
                        hasNoNavigation: !!s,
                        customButtonContent: u,
                        onHeaderButtonClick: l,
                        headerButtonStyle: g && g.seeAllColor ? {
                            color: g.seeAllColor
                        } : g && g.color ? {
                            color: g.color
                        } : {},
                        headerSectionButtonProps: h({}, b)
                    })), o().createElement("div", {
                        className: "shopee-header-section__content"
                    }, r))
                }), "HeaderSection", {
                    reportOnce: !0
                })
        },
        37626: function(e, t, n) {
            "use strict";
            n.d(t, {
                ki: function() {
                    return r
                },
                k6: function() {
                    return o
                },
                Eu: function() {
                    return a
                }
            });

            function r(e) {
                var t = Math.floor(e / 1e3),
                    n = Math.floor(t / 3600);
                return t %= 3600, {
                    hour: n || 0,
                    minute: Math.floor(t / 60) || 0,
                    second: t % 60 || 0
                }
            }

            function o(e, t) {
                var n = +new Date;
                return Math.max(0, (1e3 * e - n) * t)
            }

            function a(e) {
                return e < 10 ? "0" + e : String(e)
            }
        },
        11540: function(e, t, n) {
            "use strict";
            var r = n(27378),
                o = n.n(r),
                a = n(24723),
                c = n(97953).oc.t;
            t.Z = function(e) {
                var t = e.customTitle,
                    n = e.customDesc;
                return o().createElement("div", {
                    className: "card"
                }, o().createElement(a.bO, {
                    targetType: "WelcomePackagePopup",
                    customTitle: t || c("label_welcome_package_download"),
                    customDesc: n || c("label_welcome_package_get")
                }))
            }
        },
        53685: function(e, t, n) {
            "use strict";
            n.d(t, {
                V: function() {
                    return a
                }
            });
            var r = n(6976),
                o = n(61922);

            function a(e) {
                return void 0 === e && (e = !1),
                    function(t) {
                        t((0, o.a3)((0, r.Kd)(), (0, r.dU)(), (0, r.of)(), e))
                    }
            }
        },
        79110: function(e, t, n) {
            "use strict";
            n.d(t, {
                UJ: function() {
                    return l
                },
                jO: function() {
                    return m
                }
            });
            var r = n(69068),
                o = (n(76094), n(90508)),
                a = n(72609);

            function c(e, t) {
                return (0, a.jsonPost)(o.$3, {
                    username: e,
                    adult_consent: t
                })
            }
            n(92027);
            n(88483);
            var i = n(88929);

            function u(e, t, n, r, o, a, c) {
                try {
                    var i = e[a](c),
                        u = i.value
                } catch (e) {
                    return void n(e)
                }
                i.done ? t(u) : Promise.resolve(u).then(r, o)
            }

            function s(e) {
                return function() {
                    var t = this,
                        n = arguments;
                    return new Promise((function(r, o) {
                        var a = e.apply(t, n);

                        function c(e) {
                            u(a, r, o, c, i, "next", e)
                        }

                        function i(e) {
                            u(a, r, o, c, i, "throw", e)
                        }
                        c(void 0)
                    }))
                }
            }

            function l(e) {
                return function() {
                    var t = s(regeneratorRuntime.mark((function t(n, o) {
                        var a, u, s, l, m, d;
                        return regeneratorRuntime.wrap((function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return a = o().account, u = Math.floor(e / 1e3), "function" == typeof a.toJS && (a = a.toJS()), s = a.info ? a.info : a, l = s.username, n((0, r.a)(i.qY.REQUESTED)), t.next = 7, c(l, u);
                                case 7:
                                    m = t.sent, d = m.error, n(d ? (0, r.a)(i.qY.FAILED) : (0, r.a)(i.qY.SUCCESS, {
                                        adultConsent: u
                                    }));
                                case 10:
                                case "end":
                                    return t.stop()
                            }
                        }), t)
                    })));
                    return function(e, n) {
                        return t.apply(this, arguments)
                    }
                }()
            }

            function m() {
                return function() {
                    var e = s(regeneratorRuntime.mark((function e(t) {
                        var n, r;
                        return regeneratorRuntime.wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return t({
                                        type: i.HH.REQUESTED
                                    }), e.next = 3, (0, a.jsonPost)(o.og, {
                                        tos_accepted_time: !0
                                    });
                                case 3:
                                    n = e.sent, r = n.error, t(r ? {
                                        type: i.HH.FAILED
                                    } : {
                                        type: i.HH.SUCCESS
                                    });
                                case 6:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })));
                    return function(t) {
                        return e.apply(this, arguments)
                    }
                }()
            }
        }
    }
]);
//# sourceMappingURL=https://shopee.sg/assets/9940.fb6f7eb5afe3cd2f8f8e.js.map