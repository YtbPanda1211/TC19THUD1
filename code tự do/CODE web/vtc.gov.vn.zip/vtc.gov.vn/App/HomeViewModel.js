var HomeViewModel = function() {
    var self = this;
    self.convertToKoObject = function(data) {
        var newObj = ko.mapping.fromJS(data);
        return newObj;
    }

    self.convertToJson = function(item) {
        if (item == null || item == "") {
            return [];
        } else {
            return JSON.parse(item);
        }
    };

    self.checkMetadata = function(meta, es) {
        var returnValue = false;
        $.each(meta, function(idx, item) {
            if (item.Name() == es) {
                returnValue = true;
            }
        });
        return returnValue;
    }

    self.getMetadata = function(meta, es) {
        var returnValue = "";
        $.each(meta, function(idx, item) {
            if (item.Name() == es) {
                returnValue = item.Value();
            }
        });
        return returnValue;
    }

    self.subString = function(str, max) {
        if (str == null) {
            return "";
        }
        if (str.length > max) {
            str = str.substring(0, max) + " ...";
        }
        return str;
    }

    self.mode = ko.observable("");
    self.resultHome = ko.observableArray();
    self.fileConfig = ko.observable();
    self.menu = ko.observableArray();
    self.getFileConfig = function() {
        $.ajax({
            url: "/api/now/v1/config",
            type: "GET"
        }).done(function(data) {
            data.Components = self.convertToJson(data.Components);
            data.Components.sort(function(a, b) {
                return a.OrderID - b.OrderID
            });
            $.each(data.Components, function(idx, item) {
                item.videos = [];
                item.Components = self.convertToJson(item.Components);
                self.menu.push(self.convertToKoObject(item));
                self.getVideoHome(item);
            });
            self.fileConfig(self.convertToKoObject(data));
            //  var count = 0;
            // console.log()
            setInterval(function() {
                //   console.log(self.resultHome().length)
                // self.dataLive.removeAll();
                $.each(self.resultHome(), function(i, obj) {
                    if (obj.OrderID() == 1) {
                        $.each(obj.Media(), function(i, hot) {
                            hot.IsLive(false);
                            var sec = moment(hot.Schedule()) - moment();
                            // var sec = -1;
                            if (sec < 0) {
                                hot.IsLive(true);
                            }
                            hot.Countdown(sformat(sec / 1000));
                            //  console.log(hot.IsNotify())
                            if (hot.IsLive() == true && hot.IsNotify() == false) {
                                //  self.ShowNotification(hot);
                                hot.IsNotify(true)

                            }

                        })
                    }

                });
            }, 500);

            self.getLive(data);
        });
    }

    self.events = ko.observableArray();
    self.hot = ko.observable();
    self.liveChannel = ko.observableArray();
    self.news = ko.observable();
    self.documents = ko.observable();
    self.trending = ko.observable();
    self.child = ko.observable();
    self.musics = ko.observable();
    self.shows = ko.observable();
    self.sports = ko.observable();
    self.seriesmovie = ko.observable();
    self.movies = ko.observable();
    self.books = ko.observable();
    self.videoHome = ko.observableArray();
    self.musicToday = ko.observable();
    self.getVideoHome = function(item) {
        var url = "/api/now/v1/playlists/" + item.PrivateKey + "/videos/" + item.Count + "/0";
        $.ajax({
            url: url,
            type: 'GET',
        }).done(function(data) {
            data.OrderID = item.OrderID;
            $.each(data.Media, function(i, obj) {
                obj.IsNotify = false;
                obj.IsLive = false;
                obj.Countdown = "";
                obj.Image = self.convertToJson(obj.Image);
            });
            data.LayoutType = self.convertToJson(data.LayoutType);
            if (data.LayoutType.SubType == 1) {
                self.highlights.push(data.Media[0])
            }
            //  console.log(data.Media)
            if (data.LayoutType.Type == 2) {
                data.Media.sort(function(l, r) {
                    return l.Schedule > r.Schedule ? 1 : -1
                });
                // data.Media.unshift(self.highlights()[0])
                // console.log(data.Media)
                //$.each(self.listBanner(), function (i, banner) {
                //    $.each(data.Media, function (i, obj) {
                //        //    console.log('/dung-bo-lo/' + slugify(obj.Name) + '/' + obj.PrivateID + '.html')                      
                //        if (banner.Link() != null && banner.Link() != "") {
                //            if (banner.Link() == self.getMetadataObj(obj.Metadata, 'EndTimecode')) {
                //                //console.log(data)
                //                //  console.log('/dung-bo-lo/' + slugify(obj.Name) + '/' + obj.PrivateID + '.html')
                //                $.ajax({
                //                    url: "/api/now/v1/accounts/banner/" + obj.PrivateID,
                //                    type: 'GET',
                //                }).done(function (data) {
                //                    console.log(data)
                //                    banner.Link('/dung-bo-lo/' + slugify(obj.Name) + '/' + data + '.html');

                //                });

                //            }
                //        }

                //    });
                //});
            }
            if (data.LayoutType.SubType == 6) {
                var compone = self.convertToJson(data.Components)[0];
                var url = "/api/now/v1/playlists/" + compone.PrivateKey + "/videos/" + 1 + "/0";
                $.ajax({
                    url: url,
                    type: 'GET',
                }).done(function(dataMusic) {
                    if (dataMusic.Media.length > 0) {
                        dataMusic.Media[0].IsLive = false;
                        dataMusic.Media[0].Countdown = "";
                        dataMusic.Media[0].Image = self.convertToJson(dataMusic.Media[0].Image);
                        self.musicToday(self.convertToKoObject(dataMusic.Media[0]));
                        dataMusic.Media.shift();
                    }
                });
            }

            self.resultHome.push(self.convertToKoObject(data));



            self.setUpCarousel();
        });
    }
    //   self.dataLive = ko.observableArray();
    self.highlights = ko.observableArray();
    self.isDisplay = function(item) {
        if (self.musicToday() == null) {
            return true;
        } else if (self.musicToday().PrivateID() != item) {
            return true;
        } else {
            return false;
        }
    }

    self.listArr = ko.observableArray();
    self.isShow = function(item) {
        self.listArr(item)
        if (self.musicToday() != null) {
            $.each(self.listArr(), function(i, obj) {
                if (obj == null ? "" : obj.PrivateID() == self.musicToday().PrivateID()) {
                    return self.listArr.remove(obj);
                }
            });
        } else {
            return self.listArr();
        }
    }

    self.getMetadataObj = function(meta, es) {
        var returnValue = "";
        $.each(meta, function(idx, item) {
            if (item.Name == es) {
                returnValue = item.Value;
            }
        });
        return returnValue;
    }


    self.selectedNew = ko.observable();
    var indexNew = 0;
    self.autoNextNews = function() {
        setTimeout(
            function() {
                if (indexNew == self.news().videos().length) {
                    indexNew = 0;
                }
                self.selectedNew(self.news().videos()[indexNew]);
                indexNew = indexNew + 1;
                self.autoNextNews();
            }, 15000);
    }

    self.setUpCarousel = function() {
        $.each(self.fileConfig().Components(), function(i, obj) {
            if (obj.LayoutType.SubType() == 11) {
                var swiper = new Swiper('#swiper_' + obj.LayoutType.SubType(), {
                    freeMode: true,
                    slidesPerView: 4,
                    spaceBetween: 30,
                    slidesPerGroup: 3,
                    lazy: true,
                    navigation: {
                        nextEl: '.next_' + obj.LayoutType.SubType(),
                        prevEl: '.prev_' + obj.LayoutType.SubType(),
                    },
                    breakpoints: {
                        320: {
                            slidesPerView: 2.3,
                            spaceBetween: 30
                        },
                        480: {
                            slidesPerView: 2.3,
                            spaceBetween: 30
                        },
                        640: {
                            slidesPerView: 2.3,
                            spaceBetween: 30
                        },
                        1080: {
                            slidesPerView: 6,
                            spaceBetween: 30,
                        }
                    }
                });
            }
            if (obj.LayoutType.SubType() <= 2 || obj.LayoutType.SubType() == 4 || obj.LayoutType.SubType() == 5 || obj.LayoutType.SubType() > 6 && obj.LayoutType.SubType() < 11 || obj.LayoutType.SubType() == 13 || obj.LayoutType.SubType() == 14 || obj.LayoutType.SubType() == 17 || obj.LayoutType.SubType() == 20) {
                var swiper = new Swiper('#swiper_' + obj.LayoutType.SubType(), {
                    freeMode: true,
                    slidesPerView: 6,
                    spaceBetween: 30,
                    slidesPerGroup: 5,
                    lazy: true,
                    navigation: {
                        nextEl: '.next_' + obj.LayoutType.SubType(),
                        prevEl: '.prev_' + obj.LayoutType.SubType(),
                    },
                    breakpoints: {
                        320: {
                            slidesPerView: 2.3,
                            spaceBetween: 30
                        },
                        480: {
                            slidesPerView: 2.3,
                            spaceBetween: 30
                        },
                        640: {
                            slidesPerView: 2.3,
                            spaceBetween: 30
                        },
                        1080: {
                            slidesPerView: 6,
                            spaceBetween: 30,
                        }
                    }
                });
            }

            if (obj.LayoutType.Type() == 8 && obj.LayoutType.SubType() == 12) {
                var swiper = new Swiper('#swiper_' + obj.PrivateKey(), {
                    freeMode: true,
                    slidesPerView: 6,
                    spaceBetween: 30,
                    slidesPerGroup: 5,
                    lazy: true,
                    navigation: {
                        nextEl: '.next_' + obj.LayoutType.SubType(),
                        prevEl: '.prev_' + obj.LayoutType.SubType(),
                    },
                    breakpoints: {
                        320: {
                            slidesPerView: 2.3,
                            spaceBetween: 30
                        },
                        480: {
                            slidesPerView: 2.3,
                            spaceBetween: 30
                        },
                        640: {
                            slidesPerView: 2.3,
                            spaceBetween: 30
                        },
                        1080: {
                            slidesPerView: 6,
                            spaceBetween: 30,
                        }
                    }
                });
            }

            if (obj.LayoutType.SubType() == 3 || obj.LayoutType.SubType() == 6 || obj.LayoutType.SubType() == 12) {
                var swiper = new Swiper('#swiper_' + obj.LayoutType.SubType(), {
                    freeMode: true,
                    lazy: true,
                    navigation: {
                        nextEl: '.next_' + obj.LayoutType.SubType(),
                        prevEl: '.prev_' + obj.LayoutType.SubType(),
                    },
                });
            }
        });
    }

    function sformat(sec) {
        if (sec <= 0) {
            return "Đang phát";
        }
        var sec_num = parseInt(sec, 10)
        var hours = Math.floor(sec_num / 3600)
        var minutes = Math.floor(sec_num / 60) % 60
        var seconds = sec_num % 60

        return [hours, minutes, seconds]
            .map(v => v < 10 ? "0" + v : v)
            .filter((v, i) => v !== "00" || i > 0)
            .join(":")
    }


    self.getImage = function(item, type, width, height) {
        var url = "image/no_thumb.jpg";
        $.each(item.Image(), function(idx, img) {
            if (img.Type() == type) {
                var ext = img.Url().split('.').pop();;
                url = img.Url().substring(0, img.Url().length - 4) + "_" + width + "_" + height + '.' + ext;
            }
        });

        return "https://vcv60b6khlvod.vcdn.cloud/" + url;
    }
    self.getImagenew = function(item, type, width, height) {
        var url = "image/no_thumb.jpg";
        $.each(item, function(idx, img) {
            if (img.Type == type) {
                var ext = img.Url.split('.').pop();;
                url = img.Url.substring(0, img.Url.length - 4) + "_" + width + "_" + height + '.' + ext;
            }
        });

        return "https://vcv60b6khlvod.vcdn.cloud/" + url;
    }

    self.getBackground = function(item, type) {
        var url = "image/no_thumb.jpg";
        $.each(item.Image(), function(idx, img) {
            if (img.Type() == type) {
                url = img.Url().replaceAll("\\", "/");
            }
        });
        return "https://vcv60b6khlvod.vcdn.cloud/" + url;
    }


    self.level1 = ko.observableArray();
    self.goLevel1 = function(item) {
        self.level1(item.Components());
    }
    self.live = ko.observable();
    self.getLive = function() {
        $.ajax({
            url: "/api/now/v1/playlist/live/",
            type: 'GET',
        }).done(function(data) {
            data.Components = self.convertToJson(data.Components);
            $.each(data.Components, function(idx, img) {
                img.Components = self.convertToJson(img.Components);
            });
            self.live(self.convertToKoObject(data));
        });
    }

    self.gotoItem = function(item) {
        //  window.location.href = '/view/' + slugify(item.Name()) + '/' + item.PrivateID() + '.html';
    }

    self.gotoBookItem = function(item) {
        window.location.href = '/viewbook?id=' + item.PrivateID();
    }

    self.gotoPlaylist = function(item) {
        window.location.href = '/viewplaylist?id=' + item.PrivateID;
    }

    self.gotoMovieItem = function(item) {
        window.location.href = '/viewmovieitem?id=' + item.PrivateID();
    }

    self.gotoMovie = function(item) {
        window.location.href = '/viewmovie?id=' + item.PrivateID();
    }

    self.gotoTrending = function(item) {
        window.location.href = '/viewtrending?id=' + item.PrivateID();
    }

    var idMenu = "";
    self.MenuPlaylist = function(item) {
        $('.dropdown-content').bind('touchstart touchend', function(item) {
            window.location.href = '/viewplaylist?id=' + item.id();
        });
        if (navigator.userAgent.match(/Android/i) ||
            navigator.userAgent.match(/iPhone/i) ||
            navigator.userAgent.match(/iPod/i)
        ) {
            if (item.videos().length == 0) {
                window.location.href = '/viewplaylist?id=' + item.id();
            }
            if (idMenu == item.id()) {
                if (item.id() == 5704622644001) {
                    window.location.href = '/viewmovie?id=' + item.id();
                } else {
                    window.location.href = '/viewplaylist?id=' + item.id();
                }
            } else {
                idMenu = item.id();
            }
        } else {
            if (item.id() == 5704622644001) {
                window.location.href = '/viewmovie?id=' + item.id();
            } else {
                window.location.href = '/viewplaylist?id=' + item.id();
            }
        }
    }

    function slugify(str) {
        if (str != null) {
            str = str.replace(/^\s+|\s+$/g, ''); // trim
            str = str.toLowerCase();

            // remove accents, swap ñ for n, etc
            var from = "áàảãạăẵẳằắặâẫẩầấậđéẽèẻèêễếềểệíìỉĩịóòõỏọôỗồổốộơỡởờớợúũùủụưữửừứựýỹỷỳỵ·/_,:;";
            var to = "aaaaaaaaaaaaaaaaadeeeeeeeeeeeiiiiiooooooooooooooooouuuuuuuuuuuyyyyy------";
            for (var i = 0, l = from.length; i < l; i++) {
                str = str.replace(new RegExp(from.charAt(i), 'g'), to.charAt(i));
            }

            str = str.replace(/[^a-z0-9 -]/g, '') // remove invalid chars
                .replace(/\s+/g, '-') // collapse whitespace and replace by -
                .replace(/-+/g, '-'); // collapse dashes
        }
        return str;
    }

    self.findMenu = function(id) {
        $.each(self.listMenu(), function(idx, item) {
            if (item.id == id) {
                self.selectedMenu(item);
            }
        });
    }

    self.selectedMenu = ko.observable();
    self.enableDetails = function(id) {
        self.findMenu(id);
    }

    self.disableDetails = function(id) {
        self.selectedMenu(null);
    }

    self.slugifyLink = function(str) {
        if (str != null) {
            str = str.replace(/^\s+|\s+$/g, ''); // trim
            str = str.toLowerCase();

            // remove accents, swap ñ for n, etc
            var from = "áàảãạăẵẳằắặâẫẩầấậđéẽèẻèêễếềểệíìỉĩịóòõỏọôỗồổốộơỡởờớợúũùủụưữửừứựýỹỷỳỵ·/_,:;";
            var to = "aaaaaaaaaaaaaaaaadeeeeeeeeeeeiiiiiooooooooooooooooouuuuuuuuuuuyyyyy------";
            for (var i = 0, l = from.length; i < l; i++) {
                str = str.replace(new RegExp(from.charAt(i), 'g'), to.charAt(i));
            }

            str = str.replace(/[^a-z0-9 -]/g, '') // remove invalid chars
                .replace(/\s+/g, '-') // collapse whitespace and replace by -
                .replace(/-+/g, '-'); // collapse dashes

        }

        return str;
    }

    self.handleMouse = function() {
        $(".dropdown").on("mouseover", function(item) {
            console.log(item.currentTarget.offsetTop)
            $(".dropdown-content").css("position", "absolute");
            $(".dropdown-content").css("top", item.currentTarget.offsetTop);
            $(".level2").css("left", item.currentTarget.offsetLeft + 360);
            $(".level3").css("left", item.currentTarget.offsetLeft + 540);
            if (item.currentTarget.offsetLeft < screen.width) {
                $(".dropdown-content").css("left", item.currentTarget.offsetLeft);
                $(".level1").css("left", item.currentTarget.offsetLeft + 100);
                $(".level2").css("left", item.currentTarget.offsetLeft + 360);
                $(".level3").css("left", item.currentTarget.offsetLeft + 540);
            } else {
                $(".dropdown-content").css("left", screen.width - 180);
                $(".dropdown-level").css("left", screen.width - 180);
            }
        });

        $(".hover-content").on("mouseover", function(item) {
            console.log(item.currentTarget.offsetTop)
            $(".dropdown-level").css("position", "absolute");
            $(".dropdown-level").css("top", item.currentTarget.offsetTop + 28);
            $(".level1").css("left", item.currentTarget.offsetLeft + 100);
            $(".level2").css("left", item.currentTarget.offsetLeft + 360);
            $(".level3").css("left", item.currentTarget.offsetLeft + 540);
            if (item.currentTarget.offsetLeft < screen.width) {
                $(".dropdown-level").css("left", item.currentTarget.offsetLeft);
                $(".level1").css("left", item.currentTarget.offsetLeft + 100);
                $(".level2").css("left", item.currentTarget.offsetLeft + 360);
                $(".level3").css("left", item.currentTarget.offsetLeft + 540);
            } else {
                $(".dropdown-level").css("left", screen.width - 180);
            }
        });


        $('.dropdown').bind('touchstart touchend', function(item) {
            $(".dropdown-content").css("position", "absolute");
            $(".dropdown-content").css("top", item.currentTarget.offsetTop);
            if (item.currentTarget.offsetLeft < screen.width) {
                $(".dropdown-content").css("left", item.currentTarget.offsetLeft);
            } else {
                $(".dropdown-content").css("left", screen.width - 180);
            }
        });
    }

    self.level1 = ko.observableArray();
    self.goLevel1 = function(item) {
        self.level1(item.Components());
    }

    self.listBanner = ko.observableArray();
    self.getBanner = function() {
        $.ajax({
            url: "/api/now/v1/banner",
            type: "GET"
        }).success(function(data) {
            if (data != null) {
                data.Banner.sort(function(a, b) {
                    return a.orderID - b.orderID
                });
                $.each(data.Banner, function(idx, item) {
                    self.listBanner.push(self.convertToKoObject(item));
                });

                $.each(self.listBanner(), function(idx, item) {
                    if (item.Link() != null && item.Link() != "" && !item.Link().startsWith("http")) {
                        $.ajax({
                            url: "/api/now/v1/accounts/banner/" + item.Link(),
                            type: 'GET',
                        }).success(function(data) {
                            if (data != 500) {
                                item.Link('/dung-bo-lo/chi-tiet/' + data + '.html');
                            } else if (item.Link() != null) {
                                item.Link('/dung-bo-lo/chi-tiet/' + item.Link() + '.html');
                            } else {
                                item.Link('');
                            }
                        });
                    }
                });

                console.log(self.listBanner())
                $('#bar').flickity({
                    cellAlign: 'left',
                    contain: true,
                    prevNextButtons: true,
                    pageDots: true,
                    adaptiveHeight: true,
                    imagesLoaded: true,
                    autoPlay: 15000,
                    loop: true,
                    pageDots: false,
                    wrapAround: true,
                    cellSelector: '.item-banner'
                });

                $('.carousel-nav').flickity({
                    asNavFor: '#bar',
                    contain: true,
                    pageDots: false,
                    prevNextButtons: false
                });
            }
        }).error(function() {});
    }

    //Notification
    self.Notification = function(e) {
        var allownoti = document.getElementById('allownoti');
        allownoti.addEventListener('click', function(e) {
            //e.preventDefault();

            // Nếu trình duyệt không hỗ trợ thông báo
            if (!window.Notification) {
                console.log('Trình duyệt của bạn không hỗ trợ chức năng này.');
            }
            // Ngược lại trình duyệt có hỗ trợ thông báo
            else {
                // Gửi lời mời cho phép thông báo
                Notification.requestPermission(function(p) {
                    // Nếu không cho phép
                    if (p === 'denied') {
                        console.log('Bạn đã không cho phép thông báo trên trình duyệt.');
                    }
                    // Ngược lại cho phép
                    else {
                        console.log('Bạn đã cho phép thông báo trên trình duyệt, hãy bắt đầu thử Hiển thị thông báo.');
                    }
                });
            }
        });
        document.addEventListener('DOMContentLoaded', function() {
            if (!Notification) {
                console.log('Desktop notifications not available in your browser. Try Chromium.');
                return;
            }
            if (Notification.permission !== 'granted') {
                Notification.requestPermission();
            }
        });
    }

    self.ShowNotification = function(e) {

        var a = 'https://now.vtc.vn/dung-bo-lo/' + self.slugifyLink(e.Name()) + '/' + e.PrivateID() + '.html'
        console.log(a);
        var notify;
        //  e.preventDefault();
        //  Nếu chưa cho phép thông báo
        if (Notification.permission !== 'granted') {
            Notification.requestPermission();
        }
        // Ngược lại đã cho phép
        else {
            //    Tạo thông báo
            notify = new Notification(
                'Bạn có một thông báo mới từ VTC NOW', // Tiêu đề thông báo
                {
                    body: e.Name() + ' đang phát', // Nội dung thông báo
                    icon: self.getImage(e, 'Thumbnail', 320, 180), // Hình ảnh
                    tag: 'https://now.vtc.vn/dung-bo-lo/' + self.slugifyLink(e.Name()) + '/' + e.PrivateID() + '.html' // Đường dẫn 
                }
            );
            //   Thực hiện khi nhấp vào thông báo
            notify.onclick = function() {
                window.location.href = this.tag; // Di chuyển đến trang cho url = tag
            }
        }


    }

    self.CheckIsLive = function(e) {


    }

}

$(function() {
    var viewModelHome = new HomeViewModel();
    viewModelHome.getBanner();
    viewModelHome.getFileConfig();

    ko.applyBindings(viewModelHome);
});